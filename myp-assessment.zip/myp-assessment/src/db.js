/**
 * Persistence layer for the IB MYP Assessment & Analytics Platform.
 * Uses Node's built-in `node:sqlite` driver (no native compilation required).
 */
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
export const DB_PATH =
  process.env.MYP_DB_PATH || resolve(here, '..', 'data', 'myp.db');

let handle = null;

export function getDb() {
  if (handle) return handle;
  mkdirSync(dirname(DB_PATH), { recursive: true });
  handle = new DatabaseSync(DB_PATH);
  handle.exec('PRAGMA journal_mode = WAL;');
  handle.exec('PRAGMA foreign_keys = ON;');
  migrate(handle);
  return handle;
}

function migrate(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS questions (
      id                   VARCHAR(36) PRIMARY KEY,
      subject_group        VARCHAR(50) NOT NULL,
      target_criterion     VARCHAR(1)  NOT NULL
                           CHECK (target_criterion IN ('A','B','C','D')),
      myp_phase_level      INT         NOT NULL
                           CHECK (myp_phase_level BETWEEN 1 AND 5),
      question_text        TEXT        NOT NULL,
      command_term         VARCHAR(30) NOT NULL,
      options              JSON        NOT NULL,
      correct_option_index INT         NOT NULL
                           CHECK (correct_option_index BETWEEN 0 AND 3),
      rubric_rationale     TEXT        NOT NULL,
      created_at           TIMESTAMP   DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS key_terms (
      id                    VARCHAR(36) PRIMARY KEY,
      term                  VARCHAR(100) UNIQUE NOT NULL,
      subject_group         VARCHAR(50)  NOT NULL,
      criterion_association VARCHAR(1),
      category              VARCHAR(40)  NOT NULL DEFAULT 'Command Term',
      formal_definition     TEXT         NOT NULL,
      myp_context_example   TEXT         NOT NULL,
      related_terms         JSON
    );

    CREATE TABLE IF NOT EXISTS user_streaks (
      user_id                 VARCHAR(36) PRIMARY KEY,
      current_streak          INT       DEFAULT 0,
      longest_streak          INT       DEFAULT 0,
      last_activity_timestamp TIMESTAMP NOT NULL,
      timezone_offset         INT       DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS practice_sessions (
      id             VARCHAR(36) PRIMARY KEY,
      user_id        VARCHAR(36) NOT NULL,
      subject_group  VARCHAR(50),
      criterion      VARCHAR(1),
      questions_served   INT NOT NULL DEFAULT 0,
      correct_count  INT NOT NULL DEFAULT 0,
      started_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES user_streaks(user_id)
    );

    CREATE TABLE IF NOT EXISTS practice_attempts (
      id           VARCHAR(36) PRIMARY KEY,
      session_id   VARCHAR(36),
      user_id      VARCHAR(36) NOT NULL,
      question_id  VARCHAR(36) NOT NULL,
      chosen_index INT NOT NULL,
      is_correct   INT NOT NULL,
      phase_level  INT NOT NULL,
      attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (question_id) REFERENCES questions(id)
    );

    CREATE INDEX IF NOT EXISTS idx_q_filter
      ON questions(subject_group, target_criterion);
    CREATE INDEX IF NOT EXISTS idx_q_level ON questions(myp_phase_level);
    CREATE INDEX IF NOT EXISTS idx_t_term  ON key_terms(term);
    CREATE INDEX IF NOT EXISTS idx_t_group ON key_terms(subject_group);
    CREATE INDEX IF NOT EXISTS idx_a_user
      ON practice_attempts(user_id, attempted_at);
  `);
}

/** Removes every row from the question bank, glossary and ledger tables. */
export function truncateAll(db = getDb()) {
  db.exec(`
    DELETE FROM practice_attempts;
    DELETE FROM practice_sessions;
    DELETE FROM user_streaks;
    DELETE FROM key_terms;
    DELETE FROM questions;
  `);
}

export function closeDb() {
  if (handle) {
    handle.close();
    handle = null;
  }
}
