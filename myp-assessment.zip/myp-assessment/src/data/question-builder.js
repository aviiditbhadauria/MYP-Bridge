/**
 * Authoring helpers for the MYP criterion practice bank.
 *
 * Keeps the 300 authored items terse while guaranteeing that every row which
 * reaches SQLite satisfies the CHECK constraints declared in src/db.js.
 */

const SLUGS = new Map([
  ['Mathematics (Standard)', 'math-std'],
  ['Mathematics (Extended)', 'math-ext'],
  ['Sciences', 'sci'],
  ['Language & Literature', 'langlit'],
  ['Individuals & Societies', 'indsoc'],
  ['Language Acquisition', 'langacq'],
]);

const VALID_CRITERIA = new Set(['A', 'B', 'C', 'D']);

/** Canonical command terms, indexed by the criterion they are assessed under. */
export const COMMAND_TERMS = {
  A: [
    'State',
    'Define',
    'Describe',
    'Explain',
    'Outline',
    'Identify',
    'Give an example',
    'Give a definition',
  ],
  B: [
    'Analyse',
    'Compare',
    'Construct',
    'Design',
    'Develop',
    'Examine',
    'Formulate an inquiry question',
    'Identify and justify',
    'Pattern',
    'Prioritize',
    'Solve problem',
    'Organize',
  ],
  C: [
    'Analyse',
    'Apply',
    'Argue',
    'Assess',
    'Comment',
    'Critique',
    'Discuss',
    'Evaluate',
    'Expose',
    'Justify',
    'Reflect',
    'Summarize',
  ],
  D: [
    'Analyse',
    'Apply',
    'Calculate',
    'Construct',
    'Demonstrate',
    'Describe',
    'Determine',
    'Develop',
    'Discuss',
    'Evaluate',
    'Examine',
    'Explain',
    'Investigate',
    'Justify',
    'Predict',
    'Research',
    'Reflect',
    'Solve problem',
    'Use information',
  ],
};

/**
 * Builds one authored question object.
 * @param {object} spec
 * @param {string} spec.subject  Subject group id, must exist in SUBJECT_GROUPS.
 * @param {'A'|'B'|'C'|'D'} spec.criterion
 * @param {number} spec.level  MYP phase level 1-5.
 * @param {string} spec.command Command term (canonical or extended form).
 * @param {string} spec.text
 * @param {string[]} spec.options Exactly four distractors plus the answer.
 * @param {number} spec.correct Zero-based index into `options`.
 * @param {string} spec.rationale Why the answer is correct, written against the criterion.
 */
export function q(spec) {
  const {
    subject,
    criterion,
    level,
    command,
    text,
    options,
    correct,
    rationale,
  } = spec;

  const slug = SLUGS.get(subject);
  if (!slug) throw new Error(`Unknown subject group: ${subject}`);
  if (!VALID_CRITERIA.has(criterion)) {
    throw new Error(`Invalid criterion for "${text.slice(0, 40)}": ${criterion}`);
  }
  if (!Number.isInteger(level) || level < 1 || level > 5) {
    throw new Error(`Phase level out of range 1-5: ${level}`);
  }
  if (!Array.isArray(options) || options.length !== 4) {
    throw new Error(`Question "${text.slice(0, 40)}" must supply exactly 4 options.`);
  }
  if (!Number.isInteger(correct) || correct < 0 || correct > 3) {
    throw new Error(`correct index out of range for "${text.slice(0, 40)}"`);
  }
  if (!rationale || rationale.length < 40) {
    throw new Error(`Rubric rationale too thin for "${text.slice(0, 40)}"`);
  }
  if (new Set(options).size !== 4) {
    throw new Error(`Duplicate options in "${text.slice(0, 40)}"`);
  }
  if (command.length > 30) {
    throw new Error(`Command term exceeds VARCHAR(30): ${command}`);
  }

  return {
    subject_group: subject,
    target_criterion: criterion,
    myp_phase_level: level,
    command_term: command,
    question_text: text,
    options,
    correct_option_index: correct,
    rubric_rationale: rationale,
  };
}

/**
 * Attaches deterministic, stable, spec-shaped ids (`q-sci-a-042`) to a flat
 * list of authored questions for a single subject group.
 */
export function withIds(subject, items) {
  const slug = SLUGS.get(subject);
  if (!slug) throw new Error(`Unknown subject group: ${subject}`);
  const counters = { A: 0, B: 0, C: 0, D: 0 };
  return items.map((item) => {
    counters[item.target_criterion] += 1;
    return {
      id: `q-${slug}-${item.target_criterion.toLowerCase()}-${String(
        counters[item.target_criterion],
      ).padStart(3, '0')}`,
      ...item,
    };
  });
}

export const SUBJECT_IDS = [...SLUGS.keys()];
