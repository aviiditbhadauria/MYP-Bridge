/**
 * MYP framework glossary: criteria, concepts, global contexts, assessment
 * machinery and cross-board equivalency vocabulary.
 */
export default [
  {
    term: 'Conceptual Understanding',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'MYP Framework',
    formal_definition:
      'The enduring, transferable big ideas that students should take away from a subject, independent of specific content or context.',
    myp_context_example:
      'In Sciences the concept of change links reaction rates, adaptation and environmental responses, allowing a student to transfer reasoning across all three.',
    related_terms: ['Related Concepts', 'Context', 'Global Context'],
  },
  {
    term: 'Related Concepts',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'MYP Framework',
    formal_definition:
      'Discipline-specific ideas that, explored through a context, provide depth of understanding beyond the big ideas themselves.',
    myp_context_example:
      'In Sciences, form, function and transformation act as related concepts that give precision to the conceptual understanding of change.',
    related_terms: ['Conceptual Understanding', 'Context', 'Global Context'],
  },
  {
    term: 'Context',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'MYP Framework',
    formal_definition:
      'The real-world situation, setting or scenario through which a concept is explored and made meaningful.',
    myp_context_example:
      'Investigating water quality in the local river is a context that converts a general concept about systems into an applied inquiry with measurable outcomes.',
    related_terms: ['Global Context', 'Conceptual Understanding', 'Local Context'],
  },
  {
    term: 'Global Context',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'MYP Framework',
    formal_definition:
      'One of the seven overarching MYP contexts that frame inquiry and give learning a purpose connected to wider human experience.',
    myp_context_example:
      'Globalisation and Sustainability frames a study of food supply chains by connecting consumption decisions to environmental and economic consequences.',
    related_terms: ['Identities and Relationships', 'Globalisation and Sustainability', 'Context'],
  },
  {
    term: 'Identities and Relationships',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Global Context',
    formal_definition:
      'A global context examining who we are, how others see us and how relationships between people and groups shape identities.',
    myp_context_example:
      'Language & Literature uses this context to ask how representations of belonging in a novel are constructed and what they imply about who is permitted to belong.',
    related_terms: ['Global Context', 'Culture', 'Identity'],
  },
  {
    term: 'Personal and Cultural Expression',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Global Context',
    formal_definition:
      'A global context concerned with how we engage with and create meaning through artistic expression and personal response.',
    myp_context_example:
      'Language Acquisition explores this context when students interpret the same song across two cultures and report where meaning diverges.',
    related_terms: ['Global Context', 'Culture', 'Identity'],
  },
  {
    term: 'Orientation in Space and Time',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Global Context',
    formal_definition:
      'A global context concerned with where we are, how we situate ourselves in place, and how human experience is shaped by time and location.',
    myp_context_example:
      'Individuals & Societies uses this context when mapping the spread of an epidemic against historical trade routes to explain spatial patterns.',
    related_terms: ['Global Context', 'Consequences', 'Change'],
  },
  {
    term: 'Globalisation and Sustainability',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Global Context',
    formal_definition:
      'A global context examining the interconnectedness of human systems and the finite resources on which they depend.',
    myp_context_example:
      'Sciences investigates local water consumption against global supply data, showing how a local action sits within a planetary system.',
    related_terms: ['Global Context', 'Systems', 'Sustainability'],
  },
  {
    term: 'Development and Globalisation',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Global Context',
    formal_definition:
      'A global context examining human development, its uneven distribution, and the effects of economic and political interdependence.',
    myp_context_example:
      'Individuals & Societies explores this context when comparing regional growth rates with measures of inequality within the same period.',
    related_terms: ['Global Context', 'Globalisation', 'Equity'],
  },
  {
    term: 'Fairness and Development',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Global Context',
    formal_definition:
      'A global context examining what makes a situation fair, who gains from the current arrangement, and how development can be more equitable.',
    myp_context_example:
      'A proposal for a landfill near a low-income community is analysed through this context, which asks who bears the environmental burden and who holds decision-making power.',
    related_terms: ['Global Context', 'Equity', 'Power'],
  },
  {
    term: 'Human Ingenuity',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Global Context',
    formal_definition:
      'A global context examining the interplay between human creativity, innovation and the natural environment it shapes.',
    myp_context_example:
      'Sciences evaluates a new water purification device under this context, weighing what ingenuity has achieved against the energy and waste it produces.',
    related_terms: ['Global Context', 'Innovation', 'Consequences'],
  },
  {
    term: 'Criterion A',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Assessment Criterion',
    formal_definition:
      'Knowing and understanding, assessed in Sciences, Mathematics, Language Acquisition and Language and Literature as recall and comprehension of content and concepts.',
    myp_context_example:
      'A Criterion A response in Sciences must supply a mechanism, not merely name a phenomenon, so an explanation of catalyst action outscores a statement of it.',
    related_terms: ['Criterion B', 'Criterion C', 'Criterion D'],
  },
  {
    term: 'Criterion B',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Assessment Criterion',
    formal_definition:
      'Inquiring and designing, or investigating patterns in Languages, assessed through the planning and execution of an investigation or inquiry.',
    myp_context_example:
      'A Criterion B response must control variables and state an evidential threshold, otherwise it scores as description rather than investigation.',
    related_terms: ['Criterion A', 'Criterion C', 'Criterion D'],
  },
  {
    term: 'Criterion C',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Assessment Criterion',
    formal_definition:
      'Communicating, or thinking critically in Sciences, assessed through the interpretation, analysis and evaluation of information and ideas.',
    myp_context_example:
      'A Criterion C response that identifies a correlation coefficient must still state what the coefficient can and cannot support.',
    related_terms: ['Criterion A', 'Criterion B', 'Criterion D'],
  },
  {
    term: 'Criterion D',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Assessment Criterion',
    formal_definition:
      'Applying mathematics or science in real-world contexts, or reflecting on the impacts of science in Sciences, assessed through application and informed judgement.',
    myp_context_example:
      'A Criterion D response weighs political, economic, environmental, social, ethical and moral factors before reaching a recommendation.',
    related_terms: ['Criterion A', 'Criterion B', 'Criterion C', 'PEESEM'],
  },
  {
    term: 'PEESEM',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Assessment Criterion',
    formal_definition:
      'The six dimensions of impact analysis required in Criterion D: political, economic, environmental, social, ethical and moral.',
    myp_context_example:
      'Evaluating a power station proposal requires an observation for each PEESEM dimension, since addressing only economic and environmental factors falls short of the criterion.',
    related_terms: ['Criterion D', 'Evaluate', 'Stakeholder'],
  },
  {
    term: 'Command Term',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'MYP Framework',
    formal_definition:
      'A verb in an assessment task that specifies the cognitive operation required, drawn from a defined MYP command term list per criterion.',
    myp_context_example:
      'A task set to Evaluate demands appraisal of strengths and limitations, so a response that only describes the situation is assessed against the wrong demand.',
    related_terms: ['Criterion A', 'Criterion B', 'Criterion C', 'Criterion D'],
  },
  {
    term: 'MYP Phase',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'MYP Framework',
    formal_definition:
      'The developmental stage of a Language Acquisition course, defined by the language phase expectations for receptive and productive ability.',
    myp_context_example:
      'Language Acquisition Phases 1 to 6 are supported here, with Phase 6 targeting spontaneous interaction on familiar and some unfamiliar topics.',
    related_terms: ['Language Acquisition', 'Receptive skills', 'Productive skills'],
  },
  {
    term: 'Grade Boundary',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'The minimum raw or percentage score required to achieve a particular MYP grade, subject-specific and reviewed between examination sittings.',
    myp_context_example:
      'Mathematics Extended sets its Grade 7 boundary at 71 per cent where the Standard profile sets it at 76 per cent, so the subject selection changes the result.',
    related_terms: ['Equivalency Matrix', 'Subject Group', 'Achievement Level'],
  },
  {
    term: 'Equivalency Matrix',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'A subject-bound mapping of each MYP grade 1 to 8 onto the grade scales and percentage ranges used by other examination boards.',
    myp_context_example:
      'An MYP Grade 6 in Mathematics Standard corresponds to 64 to 75 per cent, which maps to IGCSE B, CBSE A2 and ICSE 78 to 87 per cent.',
    related_terms: ['Grade Boundary', 'IGCSE', 'CBSE', 'ICSE'],
  },
  {
    term: 'IGCSE',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Equivalency Board',
    formal_definition:
      'The International General Certificate of Secondary Education, graded A* through G with a U for ungraded results.',
    myp_context_example:
      'An MYP Grade 8 aligns to IGCSE A* at grade 9, while an MYP Grade 3 aligns to IGCSE F at grade 3.',
    related_terms: ['Equivalency Matrix', 'Grade Boundary'],
  },
  {
    term: 'CBSE',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Equivalency Board',
    formal_definition:
      'The Central Board of Secondary Education in India, which reports grades as A1, A2, B1, B2, C1, C2 and E with percentage bands.',
    myp_context_example:
      'An MYP Grade 5 in Sciences maps to CBSE B1, covering 61 to 70 per cent.',
    related_terms: ['Equivalency Matrix', 'ICSE'],
  },
  {
    term: 'ICSE',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Equivalency Board',
    formal_definition:
      'The Indian Certificate of Secondary Education, which reports percentage scores alongside a grade designation.',
    myp_context_example:
      'An MYP Grade 4 in Language and Literature corresponds to ICSE 55 to 67 per cent.',
    related_terms: ['Equivalency Matrix', 'CBSE'],
  },
  {
    term: 'State Board Equivalent',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Equivalency Board',
    formal_definition:
      'The percentage band reported by regional state boards, which use a graded scale with distractor categories rather than letter grades.',
    myp_context_example:
      'An MYP Grade 8 corresponds to 93 to 100 per cent in the state board scale, described as Top Distinction.',
    related_terms: ['Equivalency Matrix', 'State Board'],
  },
  {
    term: 'Achievement Level',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'The rating from 1 to 8 awarded against the MYP grade descriptors, where 7 to 8 indicate proficiency and 1 to 3 indicate limited proficiency.',
    myp_context_example:
      'A Grade 5 response is moderate in its understanding and applies concepts in familiar contexts with partial success, whereas a Grade 3 is minimal.',
    related_terms: ['Grade Boundary', 'Criterion Band', 'Equivalency Matrix'],
  },
  {
    term: 'Criterion Band',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'The descriptor band to which a criterion response is assigned, commonly paired A and B within each grade for grades 1 to 8.',
    myp_context_example:
      'A Grade 7 Criterion A response demonstrates a strong understanding of key concepts, while the paired B band extends this to application across contexts.',
    related_terms: ['Achievement Level', 'Grade Boundary', 'Rubric'],
  },
  {
    term: 'Rubric',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'A scoring guide that maps observable evidence to specific achievement bands for a criterion.',
    myp_context_example:
      'A rubric rationale for a Criterion A science question requires a cause-and-effect mechanism, so naming the phenomenon alone does not reach the higher band.',
    related_terms: ['Criterion Band', 'Achievement Level', 'Command Term'],
  },
  {
    term: 'eAssessment',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'Assessment of MYP ePortfolios or online tasks submitted through the IB digital platform in place of, or alongside, on-screen examinations.',
    myp_context_example:
      'Digital evidence of a Sciences investigation may include a data table and an annotated method, both assessed against Criterion B rather than only a written report.',
    related_terms: ['Criterion B', 'Rubric', 'Evidence'],
  },
  {
    term: 'ePortfolio',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'The digital store of evidence a student submits across subjects, organised so that each artefact is linked to a stated criterion and global context.',
    myp_context_example:
      'A Language and Literature ePortfolio entry states the criterion, the context and then presents the analysis, so the assessor can see the basis for each mark.',
    related_terms: ['eAssessment', 'Evidence', 'Global Context'],
  },
  {
    term: 'Subject Group',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'MYP Framework',
    formal_definition:
      'A grouping of MYP courses sharing assessment criteria and grade descriptors, such as Sciences or Individuals and Societies.',
    myp_context_example:
      'Choosing a subject group changes which grade boundaries apply, because Mathematics Extended applies a different profile from every Standard-profile subject.',
    related_terms: ['Grade Boundary', 'Equivalency Matrix', 'Criterion A'],
  },
  {
    term: 'Conceptual Understanding (Sciences)',
    subject_group: 'Sciences',
    criterion_association: null,
    category: 'Conceptual Understanding',
    formal_definition:
      'The seven enduring big ideas of MYP Sciences: change, transformation, systems, patterns, models, engagement and balance.',
    myp_context_example:
      'The concept of balance is invoked when evaluating whether a development proposal distributes environmental costs fairly across a population.',
    related_terms: ['Balance', 'Change', 'Systems', 'Transformation'],
  },
  {
    term: 'Conceptual Understanding (Individuals and Societies)',
    subject_group: 'Individuals & Societies',
    criterion_association: null,
    category: 'Conceptual Understanding',
    formal_definition:
      'The enduring big ideas of MYP Individuals and Societies, including identity, relationships, place and space, change, continuity and causation, perspectives and power.',
    myp_context_example:
      'The concept of power explains why a community with less political influence bears a disproportionate share of an environmental burden.',
    related_terms: ['Power', 'Perspectives', 'Place and Space', 'Causation'],
  },
  {
    term: 'Conceptual Understanding (Language and Literature)',
    subject_group: 'Language & Literature',
    criterion_association: null,
    category: 'Conceptual Understanding',
    formal_definition:
      'The enduring big ideas of MYP Language and Literature, centred on relationships between language, literature, culture and identity through texts.',
    myp_context_example:
      'Analysing how a writer constructs a threatening character links language to identity, since the techniques position the reader in relation to the character.',
    related_terms: ['Identity', 'Culture', 'Language', 'Style'],
  },
  {
    term: 'Conceptual Understanding (Mathematics)',
    subject_group: 'Mathematics (Standard)',
    criterion_association: null,
    category: 'Conceptual Understanding',
    formal_definition:
      'The enduring big ideas of MYP Mathematics, including patterns and relationships, spatial reasoning, logic and proof, number and quantity, uncertainty and data, and change.',
    myp_context_example:
      'The concept of uncertainty and data is invoked when discussing why a correlation coefficient reports strength of association but not direction or cause.',
    related_terms: ['Patterns', 'Logic', 'Uncertainty', 'Change'],
  },
  {
    term: 'Conceptual Understanding (Language Acquisition)',
    subject_group: 'Language Acquisition',
    criterion_association: null,
    category: 'Conceptual Understanding',
    formal_definition:
      'The enduring big ideas of MYP Language Acquisition, concerned with relationships between language, communication, cultures and communities.',
    myp_context_example:
      'Examining why a regional language should be compulsory connects language to community and power, since access to one language shapes participation.',
    related_terms: ['Communication', 'Culture', 'Language', 'Community'],
  },
  {
    term: 'Culture',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Related Concept',
    formal_definition:
      'The shared practices, beliefs, values and products that distinguish a group and shape how members interpret meaning.',
    myp_context_example:
      'Two audiences reading the same advertisement draw on different cultural conventions, so the persuasive effect is not contained in the words alone.',
    related_terms: ['Identity', 'Beliefs', 'Community', 'Perspectives'],
  },
  {
    term: 'Power',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Related Concept',
    formal_definition:
      'The ability of individuals or groups to influence outcomes, control resources or shape the terms on which decisions are made.',
    myp_context_example:
      'Who holds power in a siting decision determines whether a low-income community is consulted or merely informed about a landfill nearby.',
    related_terms: ['Fairness and Development', 'Consequences', 'Perspectives'],
  },
  {
    term: 'Consequences',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Related Concept',
    formal_definition:
      'The results of actions or events, considered in terms of both intended and unintended effects across time.',
    myp_context_example:
      'Evaluating an intervention asks not only what change was sought but what second-order effects followed, including those the designers did not anticipate.',
    related_terms: ['Change', 'Impact', 'PEESEM', 'Systems'],
  },
  {
    term: 'Systems',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Related Concept',
    formal_definition:
      'Interconnected elements forming a whole, in which change in one part produces change in other parts.',
    myp_context_example:
      'A food supply chain is treated as a system because altering one input, such as fertiliser use, propagates to water quality and labour conditions elsewhere.',
    related_terms: ['Networks', 'Change', 'Globalisation and Sustainability'],
  },
  {
    term: 'Transformation',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Related Concept',
    formal_definition:
      'The process by which something changes in form, nature or function while retaining continuity of identity.',
    myp_context_example:
      'Melting illustrates transformation: the substance remains water while its state changes, unlike combustion, where new substances form.',
    related_terms: ['Change', 'Patterns', 'Balance'],
  },
  {
    term: 'Patterns',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Related Concept',
    formal_definition:
      'Recurring regularities or relationships in data or phenomena, whose recognition supports generalisation and prediction.',
    myp_context_example:
      'A constant first difference of 4 in 3, 7, 11, 15 is a pattern that generalises to the rule 4n minus 1.',
    related_terms: ['Generalize', 'Change', 'Models'],
  },
  {
    term: 'Evidence',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'Information used to support or refute a claim, whose strength depends on its source, relevance, sufficiency and representativeness.',
    myp_context_example:
      'A single photograph evidences what someone chose to depict at one moment; it does not evidence the extent of conditions across a whole site.',
    related_terms: ['Research', 'Source', 'Reliability'],
  },
  {
    term: 'Validity',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Assessment',
    formal_definition:
      'The degree to which a method or source actually measures or evidences the thing claimed, rather than a proxy for it.',
    myp_context_example:
      'A scripted dialogue read aloud is reliable because every candidate performs the same text, yet invalid as a measure of interactive speaking ability.',
    related_terms: ['Reliability', 'Evidence', 'Measurement'],
  },
  {
    term: 'Stakeholder',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'Related Concept',
    formal_definition:
      'Any individual or group that affects, or is affected by, a decision or outcome.',
    myp_context_example:
      'In a siting decision, residents, developers, local government, environmental regulators and future communities are all stakeholders with unequal influence.',
    related_terms: ['Power', 'Consequences', 'PEESEM'],
  },
  {
    term: 'Opportunity Cost',
    subject_group: 'Individuals & Societies',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'The value of the next best alternative forgone when a choice is made.',
    myp_context_example:
      'Investing in high-speed rail has an opportunity cost equal to the local bus services that could otherwise have been funded from the same budget.',
    related_terms: ['Choice', 'Trade-off', 'Consequences'],
  },
  {
    term: 'Positive Externality',
    subject_group: 'Individuals & Societies',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'A benefit conferred on third parties who are not party to a transaction and are not charged for it.',
    myp_context_example:
      'A company installing lighting in a public park reduces crime for every user, a benefit not paid for by any of them.',
    related_terms: ['Negative Externality', 'PEESEM', 'Stakeholder'],
  },
  {
    term: 'Negative Externality',
    subject_group: 'Individuals & Societies',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'A cost imposed on third parties who are not party to a transaction and are not compensated for it.',
    myp_context_example:
      'A commuter\'s car imposes congestion on every other road user without those users receiving any corresponding benefit.',
    related_terms: ['Positive Externality', 'PEESEM', 'Consequences'],
  },
  {
    term: 'Representative Sample',
    subject_group: 'Individuals & Societies',
    criterion_association: null,
    category: 'Research',
    formal_definition:
      'A subset of a population whose characteristics reflect those of the whole closely enough for conclusions to generalise.',
    myp_context_example:
      'A survey conducted only outside one shopping centre excludes non-shoppers and is not representative, regardless of its size.',
    related_terms: ['Sample', 'Sampling Method', 'Bias'],
  },
  {
    term: 'Cause and Effect',
    subject_group: 'Individuals & Societies',
    criterion_association: null,
    category: 'Related Concept',
    formal_definition:
      'The analysis of why events occur and what follows from them, distinguishing long-term from short-term causes and intended from unintended effects.',
    myp_context_example:
      'A rise in employment after a factory opened does not by itself establish causation, since a wider economic recovery or relocation could produce the same pattern.',
    related_terms: ['Causation', 'Consequences', 'Change'],
  },
  {
    term: 'Demographic Transition',
    subject_group: 'Individuals & Societies',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'The model in which mortality falls before fertility as a population develops, producing an interim period of rapid growth.',
    myp_context_example:
      'Rapid early population growth is explained by mortality declining through improved sanitation and medicine while birth rates remain high.',
    related_terms: ['Population', 'Urbanisation', 'Development'],
  },
  {
    term: 'Depreciation',
    subject_group: 'Mathematics (Standard)',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'The reduction in the value of an asset over time, calculated by allocating its cost across its expected useful life.',
    myp_context_example:
      'Comparing a vehicle\'s purchase price with its resale value requires accounting for depreciation before any conclusion about value for money.',
    related_terms: ['Value', 'Rate of Change', 'Modelling'],
  },
  {
    term: 'Interest',
    subject_group: 'Mathematics (Standard)',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'The cost of borrowing money, or the return on lending it, expressed as a percentage of the outstanding principal per period.',
    myp_context_example:
      'For a loan repaid in one instalment, simple and compound interest give identical totals because no interest-on-interest interval arises.',
    related_terms: ['Principal', 'Compound Interest', 'Rate'],
  },
  {
    term: 'Scale Factor',
    subject_group: 'Mathematics (Standard)',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'The constant multiplier relating corresponding lengths of similar figures, with area scaling as its square and volume as its cube.',
    myp_context_example:
      'Two similar rectangles with sides in the ratio 3 to 5 have areas in the ratio 9 to 25, because both dimensions scale by 3/5.',
    related_terms: ['Similarity', 'Enlargement', 'Area'],
  },
  {
    term: 'Quadratic Equation',
    subject_group: 'Mathematics (Extended)',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'An equation of the form ax squared plus bx plus c equals zero, whose real roots are determined by the sign of its discriminant.',
    myp_context_example:
      'Completing the square shows that a discriminant greater than zero gives two distinct roots, zero gives one repeated root, and a negative value gives none.',
    related_terms: ['Discriminant', 'Factorisation', 'Quadratic Formula'],
  },
  {
    term: 'Tangent',
    subject_group: 'Mathematics (Extended)',
    criterion_association: null,
    category: 'Concept',
    formal_definition:
      'The trigonometric ratio of the side opposite an acute angle in a right-angled triangle divided by the adjacent side.',
    myp_context_example:
      'A student who takes tangent to be adjacent over opposite has confused it with its reciprocal, cotangent.',
    related_terms: ['Sine', 'Cosine', 'Right-angled Triangle'],
  },
  {
    term: 'Equilibrium',
    subject_group: 'Sciences',
    criterion_association: 'A',
    category: 'Concept',
    formal_definition:
      'The state of a reversible reaction in which forward and reverse rates are equal, so concentrations remain constant but not necessarily equal.',
    myp_context_example:
      'Increasing pressure shifts equilibrium toward the side with fewer gas particles because that lowers the pressure opposing the change.',
    related_terms: ['Reversible Reaction', 'Le Chatelier', 'Enthalpy'],
  },
  {
    term: 'Independent Variable',
    subject_group: 'Sciences',
    criterion_association: 'B',
    category: 'Concept',
    formal_definition:
      'The factor deliberately changed by the investigator, whose effect on the dependent variable is being tested.',
    myp_context_example:
      'In an investigation of dissolution rate, water temperature is the independent variable while mass of sugar and volume are controlled.',
    related_terms: ['Dependent Variable', 'Control Variable', 'Fair Test'],
  },
  {
    term: 'Dependent Variable',
    subject_group: 'Sciences',
    criterion_association: 'B',
    category: 'Concept',
    formal_definition:
      'The factor measured in an investigation, expected to change in response to the independent variable.',
    myp_context_example:
      'Time taken for sugar to dissolve is the dependent variable in an investigation of the effect of temperature.',
    related_terms: ['Independent Variable', 'Control Variable', 'Fair Test'],
  },
  {
    term: 'Control Variable',
    subject_group: 'Sciences',
    criterion_association: 'B',
    category: 'Concept',
    formal_definition:
      'Any factor held constant so that the effect of the independent variable can be attributed.',
    myp_context_example:
      'Comparing the rate at two temperatures is invalid unless water volume, sugar mass and stirring rate are all controlled.',
    related_terms: ['Independent Variable', 'Dependent Variable', 'Fair Test'],
  },
  {
    term: 'Fair Test',
    subject_group: 'Sciences',
    criterion_association: 'B',
    category: 'Concept',
    formal_definition:
      'A test in which only the independent variable differs between conditions and every other relevant factor is held constant.',
    myp_context_example:
      'A fair test of light intensity measures gas volume per minute at several lamp distances while temperature and carbon dioxide stay constant.',
    related_terms: ['Control Variable', 'Replication', 'Independent Variable'],
  },
  {
    term: 'Descriptive',
    subject_group: 'Language & Literature',
    criterion_association: 'C',
    category: 'Concept',
    formal_definition:
      'Language that reports observable qualities without interpreting their significance or effect on the reader.',
    myp_context_example:
      'A response that lists colours and textures without linking them to mood is descriptive rather than analytical.',
    related_terms: ['Analytical', 'Stylistic Device', 'Effect'],
  },
  {
    term: 'Analytical',
    subject_group: 'Language & Literature',
    criterion_association: 'C',
    category: 'Concept',
    formal_definition:
      'Language that interprets textual choices and connects them to purpose, effect and the position of the reader.',
    myp_context_example:
      'Explaining why a repeated motif functions as it does is analytical, whereas noting that it recurs is descriptive.',
    related_terms: ['Descriptive', 'Effect', 'Purpose'],
  },
  {
    term: 'Unreliable Narrator',
    subject_group: 'Language & Literature',
    criterion_association: 'C',
    category: 'Concept',
    formal_definition:
      'A narrator whose account cannot be taken at face value, signalled by contradiction, omission or limited knowledge.',
    myp_context_example:
      'Where a narrator\'s claim conflicts with what the narrative shows, the reader must read the gap as evasion or limited memory.',
    related_terms: ['Bias', 'First Person', 'Perspective'],
  },
  {
    term: 'Register',
    subject_group: 'Language & Literature',
    criterion_association: 'A',
    category: 'Concept',
    formal_definition:
      'The choice of vocabulary, sentence structure and formality considered appropriate to a context, purpose and audience.',
    myp_context_example:
      'Writing a formal register to a close friend creates interpersonal distance that may be read as respect or as unfriendliness.',
    related_terms: ['Audience', 'Purpose', 'Tone'],
  },
  {
    term: 'Receptive Skills',
    subject_group: 'Language Acquisition',
    criterion_association: 'A',
    category: 'Concept',
    formal_definition:
      'The ability to comprehend spoken or written input, comprising listening and reading.',
    myp_context_example:
      'A learner may recognise a word in a news report yet be unable to use it in speech, placing it in the receptive vocabulary alone.',
    related_terms: ['Productive Skills', 'Receptive Vocabulary', 'Productive Vocabulary'],
  },
  {
    term: 'Productive Skills',
    subject_group: 'Language Acquisition',
    criterion_association: 'A',
    category: 'Concept',
    formal_definition:
      'The ability to produce spoken or written language accurately and appropriately, comprising speaking and writing.',
    myp_context_example:
      'Measuring productive control requires an unscripted task, since scripted reading evidences memorised text rather than spontaneous use.',
    related_terms: ['Receptive Skills', 'Productive Vocabulary', 'Fluency'],
  },
  {
    term: 'Interference',
    subject_group: 'Language Acquisition',
    criterion_association: 'A',
    category: 'Concept',
    formal_definition:
      'The influence of patterns, sounds or structures in one language on the use or comprehension of another, which may be facilitative or disruptive.',
    myp_context_example:
      'A false friend produces a systematic error because form similarity between cognates inflates confidence in an incorrect meaning.',
    related_terms: ['Loanword', 'Transfer', 'Cognate'],
  },
  {
    term: 'Interdisciplinary Unit',
    subject_group: 'All Subjects',
    criterion_association: null,
    category: 'MYP Framework',
    formal_definition:
      'A planned unit drawing on two or more subject groups to investigate a shared concept, context or problem.',
    myp_context_example:
      'A unit on local water quality can pair Sciences measurement with Individuals and Societies stakeholder analysis and Language and Literature reporting for a public audience.',
    related_terms: ['Global Context', 'Conceptual Understanding', 'Subject Group'],
  },
];
