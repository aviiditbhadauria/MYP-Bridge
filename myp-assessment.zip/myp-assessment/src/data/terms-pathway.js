/**
 * Pathway and elective vocabulary.
 *
 * These terms support the Design, Physical and Health Education, Visual Arts,
 * Interdisciplinary Unit and Service as Action guides. Each entry exists because
 * a guide criterion links to it; validateGuides() fails the boot if any anchor
 * in a guide payload cannot be resolved here.
 */

const DESIGN_SKILL = 'Design Skill';
const DESIGN_CONCEPT = 'Design Concept';
const PATHWAY_CONCEPT = 'Pathway Concept';
const PHE_CONCEPT = 'PHE Concept';
const VA_CONCEPT = 'Visual Arts Concept';
const IDU_CONCEPT = 'IDU Concept';

export default [
  {
    term: 'Process',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'The ordered sequence of steps through which a task is carried out, where each step produces an output that becomes the input to the next.',
    myp_context_example:
      'A design student names the process as research, concept, specification, prototype, test and evaluate, and keeps the evidence of each step in the journal.',
    related_terms: ['Method', 'Technique', 'Design cycle'],
  },
  {
    term: 'Method',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'A systematic way of carrying out a task, chosen from available alternatives and applied in a way that will produce a valid result.',
    myp_context_example:
      'A student chooses a survey method rather than an interview method because the question requires data from the whole school rather than a few individuals.',
    related_terms: ['Process', 'Technique', 'Research methods'],
  },
  {
    term: 'Technique',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: DESIGN_SKILL,
    formal_definition:
      'A specific practical skill used to manipulate materials or media, learned through instruction and refined through deliberate practice.',
    myp_context_example:
      'A printmaking technique is selected because the required texture cannot be achieved with brush application alone.',
    related_terms: ['Process', 'Practice', 'Refine'],
  },
  {
    term: 'Refine',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: DESIGN_SKILL,
    formal_definition:
      'To make small, deliberate improvements to a product through repeated testing, in order to bring it closer to a defined standard.',
    myp_context_example:
      'Refining a handle over three iterations reduces its diameter until user testing shows the grip is comfortable for the intended client.',
    related_terms: ['Iteration', 'Evaluate', 'Prototype'],
  },
  {
    term: 'Prototype',
    subject_group: 'Design',
    criterion_association: 'C',
    category: DESIGN_CONCEPT,
    formal_definition:
      'A built or rendered model made at reduced fidelity for the purpose of testing a specific aspect of a design before committing to full production.',
    myp_context_example:
      'A card prototype is built to test whether the shelf pitch is usable, because that question can be answered without expensive fabrication.',
    related_terms: ['Iteration', 'Testing', 'Plan'],
  },
  {
    term: 'Brainstorm',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: DESIGN_SKILL,
    formal_definition:
      'A divergent thinking technique for generating a wide range of options rapidly and without premature judgement on their value.',
    myp_context_example:
      'During a timed brainstorm, quantity is deliberately prioritised over quality, since judging ideas early suppresses the more original ones.',
    related_terms: ['Formulate', 'Synthesis', 'Idea'],
  },
  {
    term: 'Feedback',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'Information provided in response to a piece of work or a process, intended to support improvement and given against stated criteria.',
    myp_context_example:
      'Feedback is only actionable when it is specific and criterion-referenced, which is why the design brief is circulated alongside the prototype.',
    related_terms: ['Evaluate', 'Peer feedback', 'Iteration'],
  },
  {
    term: 'Communicate',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'To convey information, ideas or meaning to another person in a form they can interpret and act on.',
    myp_context_example:
      'A technical drawing communicates a dimension more reliably than a verbal description, because it removes ambiguity about scale.',
    related_terms: ['Audience', 'Purpose', 'Publication'],
  },
  {
    term: 'Audience',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'The intended recipient of a communication, defined by what they already know, what they need and what they will do with the information.',
    myp_context_example:
      'The same research findings are presented differently to a school council and to a specialist audience, because their prior knowledge differs.',
    related_terms: ['Purpose', 'Communicate', 'Register'],
  },
  {
    term: 'Purpose',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'The intended outcome or function of a communication, which determines the information selected, the emphasis applied and the form chosen.',
    myp_context_example:
      'Labelling a specimen to inform versus labelling it to warn produces different wording even though the data recorded is identical.',
    related_terms: ['Audience', 'Communicate', 'Purpose'],
  },
  {
    term: 'Collaborate',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'To work jointly with others towards a shared outcome, coordinating contributions, resolving disagreement and accepting shared responsibility for the result.',
    myp_context_example:
      'In an interdisciplinary group, students must decide in advance who resolves a genuine conflict between the physics and the design requirements.',
    related_terms: ['Collaboration', 'Communication', 'Feedback'],
  },
  {
    term: 'Collaboration',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'The ongoing practice of working together, assessed on the quality of the joint effort rather than on individual contribution alone.',
    myp_context_example:
      'Collaboration is assessed on whether the group product could not have been produced by any single member.',
    related_terms: ['Collaborate', 'Communication', 'Self-management'],
  },
  {
    term: 'Self-management',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'The ability to organise time, resources and priorities independently in order to progress towards a goal without external prompting.',
    myp_context_example:
      'A student who sets personal milestones at the start of the two-year course and reviews them weekly demonstrates self-management.',
    related_terms: ['Transfer', 'Evaluate', 'Progress'],
  },
  {
    term: 'Transfer',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'The application of knowledge, skills and understanding learned in one context to a new and different context.',
    myp_context_example:
      'Transfer is demonstrated when a student applies a statistical method learned in Mathematics to a Design research question without instruction.',
    related_terms: ['Reflect', 'Learning outcome', 'Conceptual Understanding'],
  },
  {
    term: 'Critical perspective',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: PATHWAY_CONCEPT,
    formal_definition:
      'The ability to consider a situation from more than one standpoint, including viewpoints that conflict with the student own.',
    myp_context_example:
      'A Service as Action reflection demonstrates critical perspective when it weighs the partner organisation view against the student view of the same event.',
    related_terms: ['Reflect', 'Bias', 'Reliability'],
  },
  {
    term: 'Learning outcome',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: IDU_CONCEPT,
    formal_definition:
      'A specific, measurable statement of what a student will know, understand or be able to do as a result of a learning experience.',
    myp_context_example:
      'A learning outcome written before a project begins gives both student and teacher a shared basis for judging whether the project succeeded.',
    related_terms: ['Transfer', 'Assessment', 'Reflect'],
  },
  {
    term: 'Community',
    subject_group: 'Individuals and Societies',
    criterion_association: 'B',
    category: IDU_CONCEPT,
    formal_definition:
      'A group of people connected by a shared interest, place or identity, whose members have interests that may not coincide.',
    myp_context_example:
      'A school is a community, but the student body and the surrounding neighbourhood are not the same community and do not always want the same thing.',
    related_terms: ['Stakeholder', 'Service as Action', 'Inquiry'],
  },
  {
    term: 'Anatomy',
    subject_group: 'Physical and Health Education',
    criterion_association: 'A',
    category: PHE_CONCEPT,
    formal_definition:
      'The study of the structure of the human body and its parts, including the organisation of those parts into systems.',
    myp_context_example:
      'Identifying the specific muscles responsible for knee extension is an anatomy question, whereas explaining why they fatigue under load is a physiology question.',
    related_terms: ['Physiology', 'Fitness', 'Body systems'],
  },
  {
    term: 'Physiology',
    subject_group: 'Physical and Health Education',
    criterion_association: 'A',
    category: PHE_CONCEPT,
    formal_definition:
      'The study of how the human body functions, including the mechanisms by which systems respond to changes and to demands placed upon them.',
    myp_context_example:
      'Explaining the increase in heart rate during interval training requires physiology, since it concerns mechanism rather than structure.',
    related_terms: ['Anatomy', 'Fitness', 'Body systems'],
  },
  {
    term: 'Training',
    subject_group: 'Physical and Health Education',
    criterion_association: 'B',
    category: PHE_CONCEPT,
    formal_definition:
      'A planned and progressive sequence of activities designed to develop a specific fitness component or skill.',
    myp_context_example:
      'A training programme that increases load every session without a recovery week will produce adaptation up to a point and then injury.',
    related_terms: ['Goal setting', 'Plan', 'Periodization'],
  },
  {
    term: 'Goal setting',
    subject_group: 'Physical and Health Education',
    criterion_association: 'B',
    category: PHE_CONCEPT,
    formal_definition:
      'The process of establishing a specific, measurable, achievable, relevant and time-bound target that a plan is then built to reach.',
    myp_context_example:
      'A target of improving 1 km time from 6:30 to 5:45 within twelve weeks is specific and measurable, unlike a target of getting fitter.',
    related_terms: ['Training', 'Evaluate', 'Plan'],
  },
  {
    term: 'Safety',
    subject_group: 'Physical and Health Education',
    criterion_association: 'C',
    category: PHE_CONCEPT,
    formal_definition:
      'The practice of identifying and controlling risk in an activity so that participants are not exposed to avoidable harm.',
    myp_context_example:
      'Independence in applying safety practice is a Criterion C outcome, so a student who follows rules only when prompted has not yet met it.',
    related_terms: ['Risk assessment', 'Apply', 'Training'],
  },
  {
    term: 'Respond',
    subject_group: 'Visual Arts',
    criterion_association: 'D',
    category: VA_CONCEPT,
    formal_definition:
      'To interpret a work by explaining how its formal elements and content produce meaning, and what that meaning suggests.',
    myp_context_example:
      'A written response explains how the artist use of scale creates social distance, and considers what that distance signifies.',
    related_terms: ['Reflect', 'Audience', 'Context'],
  },
  {
    term: 'Influence',
    subject_group: 'Visual Arts',
    criterion_association: 'A',
    category: VA_CONCEPT,
    formal_definition:
      'The effect that one artist, movement, work or event has had on the practice of another, whether direct, indirect or through reproduction.',
    myp_context_example:
      'Tracing the influence of Japanese woodblock printing on a European artist demonstrates understanding of artistic lineage.',
    related_terms: ['Context', 'Style', 'Respond'],
  },
];
