/**
 * Subject-specific glossary, part 2: Language and Literature, Individuals and
 * Societies, Language Acquisition, and Design.
 *
 * Part 1 covers Mathematics and Sciences. Command terms live in
 * terms-commands.js and framework terms in terms-framework.js.
 */
export default [
  {
    term: 'Reader-response criticism',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'A critical approach holding that meaning is produced in the interaction between a text and its reader, so interpretation is shaped by the reader as much as the text.',
    myp_context_example:
      'Two readers of the same short story produce divergent yet defensible readings, and a student argues this is expected under a reader-response approach.',
    related_terms: ['Close reading', 'Textual evidence', 'Authorial intent'],
  },
  {
    term: 'Form and structure',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'The deliberate arrangement of a text, covering narrative perspective, narrative structure, pacing, paragraphing and how these shape the experience of reading.',
    myp_context_example:
      'The three-column narrative structure in a short story foregrounds cause, effect and consequence, which a student traces to support an analysis of pacing.',
    related_terms: ['Close reading', 'Perspective', 'Style'],
  },
  {
    term: 'Style',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'The characteristic way a writer uses language, including diction, syntax, tone and figurative devices, which contributes to meaning and effect.',
    myp_context_example:
      'A formal restrained diction in a courtroom speech creates a tone of institutional authority that contrasts sharply with the emotional dialogue of a witness.',
    related_terms: ['Diction', 'Syntax', 'Tone', 'Figurative language'],
  },
  {
    term: 'Comparative study',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Skill',
    formal_definition:
      'The analysis of two or more works drawn from different periods and genres, addressing both their connections and the differences between them.',
    myp_context_example:
      'Comparing a Sophocles tragedy with a modern play version reveals that the treatment of hubris persists while dramatic conventions change completely.',
    related_terms: ['Close reading', 'Perspective', 'Textual evidence'],
  },
  {
    term: 'Diction',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'The specific choice of words a writer makes, considered alongside the alternative words available, for their connotative as well as literal effect.',
    myp_context_example:
      'Choosing slender rather than thin changes the connotation of a physical description from insult to sympathy.',
    related_terms: ['Style', 'Syntax', 'Tone', 'Connotation'],
  },
  {
    term: 'Syntax',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'The arrangement of words, clauses and sentences, which controls the pace, emphasis and complexity of a text.',
    myp_context_example:
      'In a climax passage, a shift to very short simple sentences accelerates the reading pace and intensifies the reader anxiety.',
    related_terms: ['Diction', 'Style', 'Punctuation', 'Tone'],
  },
  {
    term: 'Figurative language',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'Language used in a non-literal way to create meaning, including simile, metaphor, personification, hyperbole, onomatopoeia, symbol and allusion.',
    myp_context_example:
      'A sustained metaphor of decay running through a poem reinforces the theme of a society in decline.',
    related_terms: ['Symbol', 'Imagery', 'Diction', 'Style'],
  },
  {
    term: 'Imagery',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'Language that appeals to the senses through description, enabling a reader to visualise, hear, smell, taste or feel a scene.',
    myp_context_example:
      'Auditory imagery of bells and wind contrasts with visual imagery of a still room to heighten a sense of unease.',
    related_terms: ['Figurative language', 'Diction', 'Sensory detail'],
  },
  {
    term: 'Symbol and motif',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'A symbol is a single concrete object carrying a broader idea; a motif is a recurring image, idea or pattern that accumulates meaning across a work.',
    myp_context_example:
      'A repeated image of a locked door functions as a motif, signalling every choice the protagonist is denied.',
    related_terms: ['Figurative language', 'Theme', 'Imagery'],
  },
  {
    term: 'Theme',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Concept',
    formal_definition:
      'A central idea or insight about life developed by a text, expressed as a statement about human nature rather than as a single word such as love or freedom.',
    myp_context_example:
      'A student states a theme as a full proposition about how individuals resist institutional pressure, then evidences it with two separate passages.',
    related_terms: ['Symbol and motif', 'Textual evidence', 'Tone'],
  },
  {
    term: 'Textual evidence',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Skill',
    formal_definition:
      'Accurate, relevant quotation from a text integrated into an analytical sentence and explained, rather than quoted in isolation.',
    myp_context_example:
      'Embedding a short quotation inside a sentence and then unpacking a single word of it is worth more than a block quotation left uncommented.',
    related_terms: ['Close reading', 'In-text citation', 'Theme'],
  },
  {
    term: 'In-text citation',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Skill',
    formal_definition:
      'A reference within the body of an essay indicating the source of a quotation or idea, including an author reference and line or page number where required.',
    myp_context_example:
      'An essay cites line numbers for poetry quotations so that a reader can verify every claim against the source text.',
    related_terms: ['Textual evidence', 'Reference list', 'Close reading'],
  },
  {
    term: 'Publication',
    subject_group: 'Language and Literature',
    criterion_association: 'C',
    category: 'L&L Concept',
    formal_definition:
      'The process of preparing a written work for readers through editing, proofing, layout, illustration and the use of a neutral register appropriate to the intended audience.',
    myp_context_example:
      'A magazine feature must avoid the emotive personal register of a diary while remaining more direct than an academic paper.',
    related_terms: ['Editing', 'Layout', 'Register', 'Style'],
  },
  {
    term: 'Punctuation',
    subject_group: 'Language and Literature',
    criterion_association: 'A',
    category: 'L&L Skill',
    formal_definition:
      'The system of marks that clarifies sentence boundaries, pauses, stress and grammatical relationships within a text.',
    myp_context_example:
      'A colon placed before an extended quotation, rather than a comma, correctly signals that an explanation follows.',
    related_terms: ['Syntax', 'Editing', 'Diction'],
  },
  {
    term: 'Reliable narration',
    subject_group: 'Language and Literature',
    criterion_association: 'D',
    category: 'L&L Concept',
    formal_definition:
      'Narration in which the account can be taken as accurate and unbiased, and where the narrator does not distort, omit or contradict the evidence.',
    myp_context_example:
      'Assessing reliability involves asking whether the narrator has access to events, whether the account is consistent, and whether the narrator has motive to mislead.',
    related_terms: ['Perspective', 'Narrative perspective', 'Bias'],
  },
  {
    term: 'Perspective',
    subject_group: 'Language and Literature',
    criterion_association: 'D',
    category: 'L&L Concept',
    formal_definition:
      'The particular position from which a story is told, including narrator type and point of view, which determines what the audience can and cannot know.',
    myp_context_example:
      'Shifting from first person to third person limited changes what the audience may know, even when the sequence of events is unchanged.',
    related_terms: ['Narrative perspective', 'Narrator', 'Reliable narration'],
  },
  {
    term: 'Bibliography',
    subject_group: 'Language and Literature',
    criterion_association: 'C',
    category: 'L&L Concept',
    formal_definition:
      'The alphabetised list of all sources consulted in the research process, including those not cited, in a consistent citation style.',
    myp_context_example:
      'A bibliography records every source consulted so that the research trail is transparent and verifiable.',
    related_terms: ['In-text citation', 'Reference list', 'Research'],
  },
  {
    term: 'Chronology',
    subject_group: 'Individuals and Societies',
    criterion_association: 'A',
    category: 'I&S Concept',
    formal_definition:
      'The sequence and dating of events across periods, used to establish cause and effect and to situate a development in its historical context.',
    myp_context_example:
      'Placing the abolition of a trade at the start of a timeline reveals that later economic shifts followed rather than preceded it.',
    related_terms: ['Primary source', 'Secondary source', 'Cause and effect'],
  },
  {
    term: 'Primary source',
    subject_group: 'Individuals and Societies',
    criterion_association: 'A',
    category: 'I&S Concept',
    formal_definition:
      'A record created at the time of the events by someone directly involved, offering unmediated access to a particular moment.',
    myp_context_example:
      'A ship manifest is a primary source for migration patterns, whereas a later government report analysing that migration is a secondary source.',
    related_terms: ['Secondary source', 'Reliability', 'Bias'],
  },
  {
    term: 'Secondary source',
    subject_group: 'Individuals and Societies',
    criterion_association: 'A',
    category: 'I&S Concept',
    formal_definition:
      'An account created after the events by an author who was not present, which interprets, analyses or synthesises primary evidence.',
    myp_context_example:
      'A secondary source may be more analytical than a primary source but must be checked for the assumptions of its author.',
    related_terms: ['Primary source', 'Reliability', 'Bias'],
  },
  {
    term: 'Reliability',
    subject_group: 'Individuals and Societies',
    criterion_association: 'C',
    category: 'I&S Skill',
    formal_definition:
      'The extent to which a source can be trusted as accurate and honest, judged by the author, the evidence used, the purpose and the audience.',
    myp_context_example:
      'A wartime propaganda poster is evaluated as a strong source for what the state wanted people to believe but a weak source for actual troop numbers.',
    related_terms: ['Bias', 'Perspective', 'Primary source', 'Purpose'],
  },
  {
    term: 'Bias',
    subject_group: 'Individuals and Societies',
    criterion_association: 'C',
    category: 'I&S Concept',
    formal_definition:
      'A systematic inclination towards a particular conclusion, arising from the position, interests or assumptions of the author, which distorts the presentation of evidence.',
    myp_context_example:
      'Recognising the bias in a source involves asking whose perspective is absent as much as whose is present.',
    related_terms: ['Reliability', 'Perspective', 'Source analysis'],
  },
  {
    term: 'Use and exchange of ideas',
    subject_group: 'Individuals and Societies',
    criterion_association: 'D',
    category: 'I&S Concept',
    formal_definition:
      'How concepts, beliefs and information travel between individuals, communities and institutions, and how they are reinterpreted on arrival.',
    myp_context_example:
      'Tracing how a political idea was adapted in translation shows that ideas change as they cross cultural and linguistic boundaries.',
    related_terms: ['Globalization', 'Cultural diffusion', 'Innovation'],
  },
  {
    term: 'Globalization',
    subject_group: 'Individuals and Societies',
    criterion_association: 'D',
    category: 'I&S Concept',
    formal_definition:
      'The increasing interconnection of the world through flows of people, goods, services, information and culture across national borders.',
    myp_context_example:
      'A supply chain spanning several countries illustrates economic globalization, while diaspora communities illustrate its cultural dimension.',
    related_terms: ['Use and exchange of ideas', 'Interdependence', 'Global context'],
  },
  {
    term: 'Interdependence',
    subject_group: 'Individuals and Societies',
    criterion_association: 'D',
    category: 'I&S Concept',
    formal_definition:
      'The mutual reliance of groups and states on one another, such that the decisions of one affect the options available to others.',
    myp_context_example:
      'Interdependence is used to argue why nations cooperate on transboundary issues that they cannot resolve alone.',
    related_terms: ['Globalization', 'Cooperation', 'Sustainability'],
  },
  {
    term: 'Sustainability',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'Meeting present needs without compromising the ability of future generations to meet their own needs, encompassing environmental, social and economic dimensions.',
    myp_context_example:
      'Assessing a development project requires weighing economic growth against environmental cost and long-term social impact.',
    related_terms: ['Interdependence', 'Global context', 'Environmental impact'],
  },
  {
    term: 'Equity',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'The fair and just distribution of resources, opportunities and access within a society, distinct from the equality of outcomes.',
    myp_context_example:
      'Providing every student with a device achieves equality, while providing additional support to reach the same standard achieves equity.',
    related_terms: ['Justice', 'Rights', 'Identity'],
  },
  {
    term: 'Identity',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'A sense of belonging to particular communities, constructed through shared characteristics such as language, religion, history and shared experiences.',
    myp_context_example:
      'A student explores how language both expresses and shapes a sense of national identity within a minority community.',
    related_terms: ['Culture', 'Equity', 'Rights', 'Belonging'],
  },
  {
    term: 'Governance',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'The systems and processes by which decisions are made and enforced in a community or state, and the question of who holds that authority.',
    myp_context_example:
      'Comparing governance structures explains why the same policy produces different outcomes in two jurisdictions.',
    related_terms: ['Rights', 'Equity', 'Interdependence'],
  },
  {
    term: 'Historical context',
    subject_group: 'Individuals and Societies',
    criterion_association: 'A',
    category: 'I&S Concept',
    formal_definition:
      'The political, social, economic, cultural and technological conditions surrounding an event, which are necessary to explain its significance and its limits.',
    myp_context_example:
      'Historical context explains why a reform that was progressive in one era can appear inadequate by contemporary standards.',
    related_terms: ['Chronology', 'Primary source', 'Perspective'],
  },
  {
    term: 'Research methods',
    subject_group: 'Individuals and Societies',
    criterion_association: 'C',
    category: 'I&S Skill',
    formal_definition:
      'The systematic techniques used to gather and interpret evidence about a question, including surveys, interviews, observation and archival research.',
    myp_context_example:
      'A survey designed with leading questions will produce data that reflects the wording of the instrument as much as the opinions held.',
    related_terms: ['Data', 'Survey', 'Primary source', 'Ethics'],
  },
  {
    term: 'Ethics of research',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'The principles governing responsible research, including informed consent, confidentiality, voluntary participation and minimising harm to participants.',
    myp_context_example:
      'Interviewing peers about a sensitive issue requires informed consent and anonymity, and withdrawing the right to skip any question.',
    related_terms: ['Research methods', 'Rights', 'Data'],
  },
  {
    term: 'Language register',
    subject_group: 'Language Acquisition',
    criterion_association: 'B',
    category: 'LA Concept',
    formal_definition:
      'The level of formality and the linguistic choices appropriate to a particular audience, setting and purpose, ranging from highly formal to highly informal.',
    myp_context_example:
      'Explaining a laboratory safety procedure requires an imperative register with modal verbs, whereas a message to a friend would use contractions and slang.',
    related_terms: ['Register', 'Formality', 'Audience', 'Context'],
  },
  {
    term: 'Formality',
    subject_group: 'Language Acquisition',
    criterion_association: 'B',
    category: 'LA Concept',
    formal_definition:
      'The degree to which language conforms to academic or professional conventions of grammar, vocabulary and sentence structure rather than conversational norms.',
    myp_context_example:
      'A formal written text avoids contractions, slang and rhetorical questions throughout.',
    related_terms: ['Register', 'Academic language', 'Informality'],
  },
  {
    term: 'Receptive skill',
    subject_group: 'Language Acquisition',
    criterion_association: 'C',
    category: 'LA Concept',
    formal_definition:
      'The ability to comprehend spoken or written language, comprising listening and reading.',
    myp_context_example:
      'Understanding a recorded interview is a receptive task, because the learner must decode meaning without producing language.',
    related_terms: ['Productive skill', 'Listening', 'Reading', 'Intercultural communication'],
  },
  {
    term: 'Productive skill',
    subject_group: 'Language Acquisition',
    criterion_association: 'D',
    category: 'LA Concept',
    formal_definition:
      'The ability to produce language in spoken or written form, comprising speaking and writing.',
    myp_context_example:
      'Presenting findings orally is a productive task requiring the learner to generate language under time pressure.',
    related_terms: ['Receptive skill', 'Speaking', 'Writing', 'Intercultural communication'],
  },
  {
    term: 'Linguistic features',
    subject_group: 'Language Acquisition',
    criterion_association: 'B',
    category: 'LA Concept',
    formal_definition:
      'The observable elements of language, including grammar, vocabulary, spelling, punctuation and sentence structures, which can be described independently of context.',
    myp_context_example:
      'Identifying the present perfect continuous in a transcript requires recognising the auxiliary plus ing form regardless of its meaning.',
    related_terms: ['Grammar', 'Vocabulary', 'Register', 'Syntax'],
  },
  {
    term: 'Grammatical accuracy',
    subject_group: 'Language Acquisition',
    criterion_association: 'D',
    category: 'LA Skill',
    formal_definition:
      'Correct and consistent use of grammatical structures appropriate to the target language and the task.',
    myp_context_example:
      'A text using the past simple consistently in narrative sections and the present perfect in discussion of results shows controlled grammatical accuracy.',
    related_terms: ['Grammatical range', 'Editing', 'Accuracy', 'Mechanics'],
  },
  {
    term: 'Grammatical range',
    subject_group: 'Language Acquisition',
    criterion_association: 'D',
    category: 'LA Concept',
    formal_definition:
      'The variety of structures and patterns a learner can use, from simple to complex, including subordinate clauses and varied clause ordering.',
    myp_context_example:
      'Using a relative clause and a conditional structure alongside simple sentences widens grammatical range.',
    related_terms: ['Grammatical accuracy', 'Complex sentence', 'Syntax'],
  },
  {
    term: 'Mechanics',
    subject_group: 'Language Acquisition',
    criterion_association: 'D',
    category: 'LA Concept',
    formal_definition:
      'The systems of spelling, punctuation and capitalisation conventions that operate independently of sentence-level grammar.',
    myp_context_example:
      'Applying the target language conventions for direct speech punctuation, which differ from those of the learner first language.',
    related_terms: ['Punctuation', 'Spelling', 'Editing', 'Grammatical accuracy'],
  },
  {
    term: 'Editing',
    subject_group: 'Language Acquisition',
    criterion_association: 'D',
    category: 'LA Skill',
    formal_definition:
      'The process of revising a draft for accuracy, fluency, register and content, in a defined order of priority.',
    myp_context_example:
      'A learner edits for meaning first and mechanics last, since correcting spelling in an argument that lacks a clear position is wasted effort.',
    related_terms: ['Grammatical accuracy', 'Drafting', 'Mechanics', 'Revision'],
  },
  {
    term: 'Drafting',
    subject_group: 'Language Acquisition',
    criterion_association: 'D',
    category: 'LA Skill',
    formal_definition:
      'Producing an initial version of a text, focusing on getting ideas down rather than on accuracy or polish.',
    myp_context_example:
      'In a timed writing task, drafting the whole message without stopping for corrections produces a more complete final text.',
    related_terms: ['Editing', 'Revision', 'Planning'],
  },
  {
    term: 'Intercultural communication',
    subject_group: 'Language Acquisition',
    criterion_association: 'C',
    category: 'LA Concept',
    formal_definition:
      'The process of exchanging meaning between people whose cultural backgrounds differ, requiring awareness of communicative norms as well as linguistic accuracy.',
    myp_context_example:
      'A formal greeting and title differ across cultures, and misreading that convention causes offence even when the language is accurate.',
    related_terms: ['Receptive skill', 'Productive skill', 'Register', 'Cultural awareness'],
  },
  {
    term: 'Repertoire',
    subject_group: 'Language Acquisition',
    criterion_association: 'A',
    category: 'LA Concept',
    formal_definition:
      'The whole range of linguistic resources a speaker commands, including accent, dialect, register, code-switching and multilingual ability.',
    myp_context_example:
      'A bilingual speaker drawing on two languages mid-conversation demonstrates repertoire rather than error.',
    related_terms: ['Code-switching', 'Dialect', 'Register', 'Identity'],
  },
  {
    term: 'Code-switching',
    subject_group: 'Language Acquisition',
    criterion_association: 'A',
    category: 'LA Concept',
    formal_definition:
      'The deliberate alternation between two or more languages or registers within a single conversation, often for emphasis, efficiency or audience effect.',
    myp_context_example:
      'Switching to a term of endearment in a first language within a second-language conversation signals warmth and intimacy.',
    related_terms: ['Repertoire', 'Dialect', 'Register'],
  },
  {
    term: 'Transcription',
    subject_group: 'Language Acquisition',
    criterion_association: 'C',
    category: 'LA Skill',
    formal_definition:
      'The process of writing down what was said in a recording or conversation accurately, including false starts, pauses and unclear stretches.',
    myp_context_example:
      'A transcript marks unintelligible passages explicitly rather than guessing, preserving accuracy of the record.',
    related_terms: ['Listening', 'Note-taking', 'Receptive skill'],
  },
  {
    term: 'Verbal and non-verbal communication',
    subject_group: 'Language Acquisition',
    criterion_association: 'C',
    category: 'LA Concept',
    formal_definition:
      'Verbal communication is conveyed through words, while non-verbal communication is conveyed through tone, gesture, posture, eye contact and facial expression.',
    myp_context_example:
      'Two speakers with identical words can convey opposite meanings entirely through tone and body language.',
    related_terms: ['Intercultural communication', 'Receptive skill', 'Register'],
  },
  {
    term: 'Innovation and change',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'The introduction and adoption of new ideas, technologies or practices within a society, and the resistance and adaptation that accompany them.',
    myp_context_example:
      'Innovation in agricultural practice spread unevenly because access to land, credit and education differed between regions.',
    related_terms: ['Cultural diffusion', 'Use and exchange of ideas', 'Globalization'],
  },
  {
    term: 'Cultural diffusion',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'The spread of cultural beliefs, practices and artefacts from one group to another through contact, trade, migration or media.',
    myp_context_example:
      'The adoption of a cuisine by a new community is a form of diffusion, and the adapted recipe reveals the process of reinterpretation.',
    related_terms: ['Innovation and change', 'Use and exchange of ideas', 'Culture'],
  },
  {
    term: 'Environmental impact',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'The effect that a human activity has on natural systems, measured across ecological, chemical and physical dimensions.',
    myp_context_example:
      'A development proposal is assessed for its effect on water quality, soil erosion and species habitat before approval.',
    related_terms: ['Sustainability', 'Interdependence', 'Stewardship'],
  },
  {
    term: 'Design cycle',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Concept',
    formal_definition:
      'A structured sequence of research, ideation, planning, construction, testing and evaluation through which a designed solution is developed and refined.',
    myp_context_example:
      'A student iterates through the design cycle, testing a prototype and using the failure to inform the next iteration rather than treating the first attempt as final.',
    related_terms: ['Iteration', 'Prototype', 'Evaluation', 'Planning'],
  },
  {
    term: 'Iteration',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Skill',
    formal_definition:
      'Repeated refinement of a design through repeated cycles of making, testing and evaluating based on feedback and test results.',
    myp_context_example:
      'Iteration is what separates a first attempt from a resolved solution, and the number of iterations is itself evidence of the design process.',
    related_terms: ['Design cycle', 'Prototype', 'Feedback', 'Evaluation'],
  },
  {
    term: 'User-centred design',
    subject_group: 'Design',
    criterion_association: 'C',
    category: 'Design Concept',
    formal_definition:
      'An approach in which the needs, capabilities and constraints of the intended user determine the design decisions.',
    myp_context_example:
      'A user-centred design process begins with interviews and observation, so that a solution addresses a real need rather than an assumed one.',
    related_terms: ['Design cycle', 'Stakeholder', 'Evaluation'],
  },
  {
    term: 'Plan',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Concept',
    formal_definition:
      'The documented specification of a design, including the design brief, criteria, sketches, diagrams, material choices and costings that guide construction.',
    myp_context_example:
      'A plan includes labelled dimensions and a materials list, so that another person could build the same object.',
    related_terms: ['Design brief', 'Annotation', 'Construction', 'Design cycle'],
  },
  {
    term: 'Design brief',
    subject_group: 'Design',
    criterion_association: 'C',
    category: 'Design Concept',
    formal_definition:
      'A written statement of the problem to be solved and the constraints the solution must satisfy, including the intended audience and context of use.',
    myp_context_example:
      'A well-formed design brief specifies the user, the need, the constraints and the criteria against which success will be judged.',
    related_terms: ['Plan', 'Criteria', 'Specification', 'User-centred design'],
  },
  {
    term: 'Annotation',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Skill',
    formal_definition:
      'A labelled explanatory note attached to a drawing or plan, indicating dimensions, materials, methods or the reasoning behind a decision.',
    myp_context_example:
      'Dimension lines and a cutting list in the annotation make the plan usable as a working document rather than a sketch.',
    related_terms: ['Plan', 'Orthographic projection', 'Specification'],
  },
  {
    term: 'Orthographic projection',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Concept',
    formal_definition:
      'A technical drawing convention using parallel views such as front, top and side elevations to show the true shape and size of an object.',
    myp_context_example:
      'Orthographic projection allows an object to be manufactured accurately by someone who never sees the physical model.',
    related_terms: ['Annotation', 'Plan', 'Dimensioning'],
  },
  {
    term: 'Material properties',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Concept',
    formal_definition:
      'The measurable characteristics of a material, such as strength, hardness, flexibility, density, thermal conductivity and finish, that determine its suitability.',
    myp_context_example:
      'Choosing aluminium over steel for a laptop body requires weighing stiffness against weight and thermal conductivity.',
    related_terms: ['Construction', 'Finishing', 'Testing', 'Sustainability'],
  },
  {
    term: 'Finishing',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Skill',
    formal_definition:
      'The final surface treatment applied to a product to improve appearance, durability or resistance, such as varnishing, painting or polishing.',
    myp_context_example:
      'A suitable finish protects the material from moisture as well as improving its appearance, so both must be justified.',
    related_terms: ['Material properties', 'Construction', 'Evaluation'],
  },
  {
    term: 'Construction',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Skill',
    formal_definition:
      'The practical process of building a prototype from the plan, selecting and joining materials using appropriate techniques and tools.',
    myp_context_example:
      'A student selects the joining technique to suit the materials, since an adhesive joint fails in a load that a screwed joint would hold.',
    related_terms: ['Plan', 'Material properties', 'Prototype'],
  },
];
