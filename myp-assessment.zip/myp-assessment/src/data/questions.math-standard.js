import { q, withIds } from './question-builder.js';

const SUBJECT = 'Mathematics (Standard)';

const items = [
  // ---------------- Criterion A: Knowing and understanding (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Define',
    text: 'Define the term "index" as it is used in the algebraic term 7x^3.',
    options: [
      'The power to which the base is raised, indicating how many times the base is multiplied by itself.',
      'The result of multiplying the base by three.',
      'The coefficient that precedes the variable within a single term.',
      'The value substituted for the variable when the expression is evaluated.',
    ],
    correct: 0,
    rationale:
      'In 7x^3 the base is x and the index is 3, so x^3 means x multiplied by itself three times. Option 2 confuses the index with the coefficient (7), and options 1 and 4 misdescribe the operation entirely. Criterion A requires precise recall of technical definitions.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Calculate',
    text: 'Determine the value of 3 + 4 x 2^2 using the correct order of operations.',
    options: ['19', '22', '28', '11'],
    correct: 0,
    rationale:
      'Exponentiation is performed before multiplication, so 2^2 = 4; then 4 x 4 = 16; then 3 + 16 = 19. Option 2 (28) results from multiplying before exponentiating, and option 1 (22) from ignoring the exponent entirely. Order of operations is foundational to Criterion A accuracy.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Define',
    text: 'Define the term "net" in the context of a two-dimensional pattern.',
    options: [
      'A two-dimensional representation of a three-dimensional object that folds along edges without gaps or overlaps to form that object.',
      'The total surface area of a solid including its hidden base.',
      'The visible outline of a cube drawn in two dimensions.',
      'A two-dimensional scale drawing produced using isometric projection.',
    ],
    correct: 0,
    rationale:
      'A net must be foldable into the solid with all faces present exactly once and no overlaps. Option 2 describes surface area, option 3 describes an isometric drawing, and option 4 describes a different projection altogether.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Identify',
    text: 'Identify the statement that correctly distinguishes similar figures from congruent figures.',
    options: [
      'Similar figures have proportional corresponding sides and equal corresponding angles but need not be the same size.',
      'Congruent figures have proportional corresponding sides but no requirement on corresponding angles.',
      'Both similar and congruent figures must have exactly equal areas.',
      'Congruent figures can only be related to each other by a single reflection.',
    ],
    correct: 0,
    rationale:
      'Congruence requires identical size and shape (all corresponding measures equal), whereas similarity requires only proportionality of sides and equality of angles. Option 3 is false because similar figures have different areas when scaled; options 2 and 4 misstate congruence.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Explain',
    text: 'A straight line is given by the equation y = 3x + 2. Explain what the coefficient of x, 3, represents geometrically.',
    options: [
      'The gradient of the line: for every 1 unit increase in x, y increases by 3 units.',
      'The y-intercept of the line, where it crosses the vertical axis.',
      'The number of units the line rises over its complete horizontal run.',
      'The angle the line makes with the vertical axis, measured in degrees.',
    ],
    correct: 0,
    rationale:
      'In y = mx + c the coefficient m is the gradient, giving the rate of change of y per unit of x; c = 2 is the intercept. Option 2 describes c, and options 3 and 4 conflate gradient with total rise or with an angle in the wrong orientation.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Describe',
    text: 'Describe the single transformation in which every point of a figure moves the same distance in the same direction, preserving both size and orientation.',
    options: [
      'A translation, since all points shift by one identical vector.',
      'A reflection, since points move to mirrored positions at equal distances.',
      'A rotation, since points sweep through an equal angle about a centre.',
      'An enlargement, since all distances from a centre scale by one factor.',
    ],
    correct: 0,
    rationale:
      'The defining property of a translation is a single constant vector applied to every point, which preserves size, shape and orientation. Option 2 changes orientation, option 3 changes orientation except at the centre, and option 4 changes size.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'Explain why the Pythagorean theorem may be applied to a right-angled triangle but not in general to an arbitrary triangle.',
    options: [
      'Because it states that the square of the hypotenuse equals the sum of the squares of the other two sides only when the angle between those sides is exactly 90 degrees.',
      'Because it applies to any triangle provided the longest side is opposite the largest angle.',
      'Because it requires the triangle to be isosceles rather than right-angled.',
      'Because it is derived from an area argument and so needs a pair of parallel sides.',
    ],
    correct: 0,
    rationale:
      'The 90 degree condition is essential and is what makes the converse (that the side opposite the right angle is the hypotenuse) valid. Option 2 is false since the largest angle may be obtuse; option 3 misstates the requirement; option 4 invents a parallel-side condition.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'State',
    text: 'State the domain of the function f(x) = 1/(x - 4).',
    options: [
      'All real numbers except x = 4.',
      'All real numbers strictly greater than 4.',
      'The single value x = 4 only.',
      'All real numbers less than or equal to 4.',
    ],
    correct: 0,
    rationale:
      'The denominator cannot be zero, so x = 4 is excluded while every other real value is permitted. Options 2 and 4 incorrectly impose an inequality, and option 3 inverts the restriction entirely.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Explain',
    text: 'Two parallel lines are cut by a transversal. One angle formed at the first intersection measures 70 degrees. Explain the measure of the angle in the corresponding position at the second intersection.',
    options: [
      'It measures 70 degrees, because corresponding angles between parallel lines are equal.',
      'It measures 110 degrees, because corresponding angles between parallel lines are supplementary.',
      'It measures 20 degrees, because the angle is half of the corresponding angle.',
      'It measures 90 degrees, because a transversal is perpendicular to any parallel pair.',
    ],
    correct: 0,
    rationale:
      'Corresponding angles are equal when the lines are parallel, and the supplementary relationship belongs to co-interior (allied) angles. Options 2 and 3 apply invalid relationships, and option 4 falsely assumes the transversal is perpendicular.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Define',
    text: 'Define "variance" for a numerical data set.',
    options: [
      'The average of the squared deviations of each data value from the mean.',
      'The average distance of each data value from the mean, ignoring the direction of the deviation.',
      'The square root of the average of the squared deviations from the mean.',
      'The difference between the largest and the smallest values in the data set.',
    ],
    correct: 0,
    rationale:
      'Variance is the mean of the squared deviations. Option 3 defines standard deviation, option 1 is a common MYP misconception that omits the averaging step, and option 4 defines the range rather than a measure of spread about the centre.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Outline',
    text: 'Outline the steps used to solve x^2 - 5x + 6 = 0 by factorisation.',
    options: [
      'Identify factor pairs whose product is the constant and whose sum is the coefficient, write them as bracket factors, then set each factor equal to zero to obtain the roots.',
      'Take the square root of both sides, then subtract the coefficient of x from the resulting value.',
      'Differentiate the expression, set the derivative equal to zero and solve for the stationary point.',
      'Divide through by x to obtain a linear equation, then rearrange and solve.',
    ],
    correct: 0,
    rationale:
      'Factorisation requires (x - 2)(x - 3) = 0, giving x = 2 and x = 3. Option 1 cannot be applied because the left side is not a perfect square, option 2 addresses an entirely different task, and option 3 would find a stationary point rather than roots.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Two similar rectangles have corresponding side lengths in the ratio 3:5. Explain the ratio of their areas.',
    options: [
      '9:25, because area scales with the square of the linear scale factor, so each dimension multiplied by 3/5 multiplies the area by (3/5)^2.',
      '3:5, because area scales by the same factor as the corresponding sides.',
      '6:10, because each rectangle has two proportional dimensions that must be added.',
      '15:25, because area scales by the sum of the scale factors of the two dimensions.',
    ],
    correct: 0,
    rationale:
      'Both dimensions scale by 3/5, so the area scales by their product, (3/5)(3/5) = 9/25. Options 1 and 3 wrongly assume area scales linearly, and option 2 incorrectly adds scale factors when dimensions must be multiplied.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Explain why the graph of y = a^x, where a > 1, can never take a negative y-value, whereas the graph of y = mx + c can.',
    options: [
      'Because a^x is strictly positive for every real x, being defined as the limit of positive approximations, while mx + c changes sign as x varies according to the sign of m.',
      'Because a^x grows more rapidly than any linear function over the whole domain.',
      'Because the domain of an exponential function excludes negative values of x.',
      'Because a linear function is only defined for positive values of x.',
    ],
    correct: 0,
    rationale:
      'Positivity of a^x follows from its definition, not from its rate of growth, which is why option 1 is invalid. Options 2 and 3 misstate the domain and confuse growth rate with sign.',
  }),

  // ---------------- Criterion B: Inquiring and designing (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 1,
    command: 'Pattern',
    text: 'A sequence begins 2, 6, 12, 20, 30. Identify the next term by extending the pattern.',
    options: ['42', '40', '36', '44'],
    correct: 0,
    rationale:
      'The differences are 4, 6, 8, 10, so the next difference is 12 and the next term is 30 + 12 = 42, matching the general term n(n + 1). Option 1 continues with a constant 10, which does not fit the growing second difference.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Pattern',
    text: 'A pattern produces the values 3, 7, 11, 15 for inputs n = 1, 2, 3, 4. Which rule generates this sequence?',
    options: [
      'value = 4n - 1',
      'value = 4n + 1',
      'value = n^2 + 2',
      'value = 3n',
    ],
    correct: 0,
    rationale:
      'A constant first difference of 4 with initial value 3 at n = 1 gives the rule 4n - 1, which reproduces every listed value. Option 1 is correct only from n = 2 onward, option 2 gives 5, 9, 13, 17, and option 3 gives 3, 6, 11, 18.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Compare',
    text: 'Compare the mean and the median of the data set 3, 5, 5, 7, 40.',
    options: [
      'The mean is higher than the median because the single extreme value raises the mean substantially while leaving the middle position untouched.',
      'The median is higher than the mean because the extreme value sits at the end of the sorted list.',
      'They are equal because the data set contains an odd number of values.',
      'The mean cannot be calculated because the data set contains an extreme value.',
    ],
    correct: 0,
    rationale:
      'The mean is 12 and the median is 5, so the mean is far higher because every value contributes its full magnitude. Option 2 reverses the direction of the effect, and options 3 and 4 misstate the properties of the mean.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Compare',
    text: 'Compare the effect on a circle of doubling its radius, for both the circumference and the area.',
    options: [
      'The circumference doubles while the area quadruples, because circumference is linear in the radius whereas area is quadratic.',
      'Both quantities double, because both formulae are linear in the radius.',
      'Both quantities quadruple, because both formulae contain the radius squared.',
      'The circumference quadruples while the area doubles.',
    ],
    correct: 0,
    rationale:
      'Circumference is 2 pi r, giving a factor of 2; area is pi r squared, giving a factor of 4. Options 2 and 3 apply the wrong exponent, and option 4 reverses the two factors.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question is best formulated for investigating whether a species of plant grows faster in warm or in cool conditions?',
    options: [
      'How does the temperature of the growing environment affect the rate of growth of this species, with light, water and soil held constant?',
      'Is it true that plants grow faster in warm conditions?',
      'What is the effect of temperature on plants?',
      'Which is better for plant growth, warm or cool conditions?',
    ],
    correct: 0,
    rationale:
      'A testable inquiry question names the manipulated variable, states how the outcome will be measured and identifies the variables held constant. The other options are closed, leading questions, or too vague to be investigated systematically.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Organize',
    text: 'Organise a valid method for collecting data to compare the reaction times of students who play a musical instrument with those who do not.',
    options: [
      'Recruit consenting volunteers, define reaction time as a measurable variable, use identical apparatus and protocol for both groups, repeat trials and record the mean for each participant.',
      'Ask each student to time themselves at home and report the result in a spreadsheet.',
      'Time the first ten students and the last ten students and compare the group totals.',
      'Ask students which group they believe is faster and count the responses given.',
    ],
    correct: 0,
    rationale:
      'Validity requires a consistent operational definition, standardised conditions, repetition and consent. Options 1 and 3 introduce uncontrolled measurement variation, and option 4 collects opinion rather than reaction time data.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Examine',
    text: 'Examine the claim that increasing the quantity of fertiliser applied to a crop always increases the yield.',
    options: [
      'The claim ignores diminishing returns: once another factor such as light or water becomes limiting, extra fertiliser produces no proportional gain and can run off and pollute watercourses.',
      'The claim is correct because fertiliser always supplies whichever nutrient is limiting growth.',
      'The claim is incorrect only because fertiliser is an expensive input for most farmers.',
      'The claim is correct for cereal crops but false for vegetable crops.',
    ],
    correct: 0,
    rationale:
      'Yield is constrained by the most limiting factor, so fertiliser response follows a saturating curve rather than an unbounded straight line. Options 2, 3 and 4 offer explanations with no scientific basis.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Prioritize',
    text: 'Four candidate factors affecting reaction time are proposed: number of practice trials, ambient noise level, time of day, and colour of the test paper. Prioritise which factor to investigate first and justify the choice.',
    options: [
      'Ambient noise level, because it can be varied independently and safely, is measurable, and has a plausible direct effect on sustained concentration.',
      'Colour of the test paper, because it is the only factor that changes during a test.',
      'Time of day, because it is invariably the most important factor in every investigation.',
      'Number of practice trials, because it cannot be controlled by the investigator.',
    ],
    correct: 0,
    rationale:
      'Prioritisation rests on testability, control and a plausible mechanism; option 0 satisfies all three. Option 3 is invalid because trial count is the clearest example of a variable that can be controlled.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Solve problem',
    text: 'A recipe serving 4 people requires 300 g of flour. Determine the mass of flour needed to serve 10 people, assuming ingredients scale proportionally.',
    options: [
      '750 g, since flour required is directly proportional to the number of people, giving 300 x (10/4).',
      '600 g, since 300 g is used and a further 10 g is added per extra person.',
      '3000 g, since 300 g is required for each of the 10 people.',
      '75 g, since the original quantity must be shared among the 10 servings.',
    ],
    correct: 0,
    rationale:
      'Direct proportion gives 300 x 2.5 = 750 g. Option 2 wrongly substitutes an additive rule, and option 3 misreads the original quantity as per person rather than per 4 people.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Develop',
    text: 'Develop a method for estimating the area of a pond using only a rigid stick and a numerical scale.',
    options: [
      'Set the stick vertically at the water edge, measure a land shadow of the same stick, derive a scale factor from the ratio of the two shadow lengths, then lay a scaled grid over the pond to estimate its area.',
      'Estimate the pond length and width with the stick, multiply the two figures and assume the pond is a perfect rectangle.',
      'Drop the stick into the pond, measure the resulting ripple ring and treat its diameter as the pond diameter.',
      'Walk around the perimeter counting paces, take the square root of the total and assume a circular pond.',
    ],
    correct: 0,
    rationale:
      'This method derives a consistent scale factor and then applies a grid, which handles irregular outlines. Option 1 assumes a rectangle, option 2 assumes a relationship between ripple and basin size, and option 3 assumes the pond is circular.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Examine',
    text: 'Grade boundaries are derived from the raw results of a single examination sitting. Examine the principal limitation of this approach.',
    options: [
      'A single sitting may contain an unusually strong or weak cohort or a change in assessment design, so boundaries derived from it may not generalise to subsequent cohorts.',
      'A single sitting cannot supply enough data points for any boundary to be calculated.',
      'The approach cannot be used because raw scores are recorded as text rather than numbers.',
      'The approach is invalid only because examination boards do not publish raw scores.',
    ],
    correct: 0,
    rationale:
      'Validity of a boundary depends on cohort comparability across years, which a single sitting cannot establish. Options 1, 2 and 3 each assert a mechanical or availability obstacle that does not exist.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Construct',
    text: 'A taxi fare is a fixed flagfall of $3 plus $1.50 per kilometre, with a further $2 surcharge applied to every journey. Construct the formula for the total cost C in terms of distance d.',
    options: ['C = 3 + 1.5d + 2', 'C = 3 + 1.5d - 2', 'C = (3 + 1.5)(d + 2)', 'C = 3d + 1.5 + 2'],
    correct: 0,
    rationale:
      'A constant flagfall and a constant surcharge are added to a rate times distance, so the expression must contain three additive parts with the distance multiplied only by the rate. Option 2 wrongly subtracts the surcharge.',
  }),

  // ---------------- Criterion C: Communicating and thinking critically (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 1,
    command: 'Summarize',
    text: 'Summarize what the single statement "the mean is 20" communicates, and what it fails to communicate, about a data set.',
    options: [
      'It communicates a single measure of centre but not the spread, the shape or any of the individual values.',
      'It communicates both the centre and the spread of the data set completely.',
      'It communicates that exactly half of the values lie above 20.',
      'It communicates that the largest value in the data set is 20.',
    ],
    correct: 0,
    rationale:
      'A mean is a summary of position alone; it conceals dispersion and distribution entirely. Options 1 and 3 misattribute properties of the median, and option 2 misdescribes the statistic.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Justify',
    text: 'A student observes that students who revise for more hours tend to score higher, and concludes that revision causes higher scores. Justify or challenge this conclusion.',
    options: [
      'Challenge it: an association does not establish causation, since prior attainment or motivation could influence both the hours revised and the score obtained.',
      'Accept it: the association is consistent, so revision must be the causal factor.',
      'Accept it: revision is the only variable that was measured across the whole class.',
      'Challenge it: revision has no measurable effect on mathematical attainment.',
    ],
    correct: 0,
    rationale:
      'Confounding variables and reverse causation both explain the association without requiring revision to be the cause. Options 1 and 2 treat association as proof, and option 3 is factually false.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Apply',
    text: 'A bag holds 3 red and 5 blue counters. One counter is drawn, replaced, then drawn again. Apply probability to determine the probability of obtaining two counters of different colours.',
    options: [
      '0.30, computed as (3/10 x 5/10) + (5/10 x 3/10) for the two possible orders.',
      '0.60, computed by doubling the probability of one order.',
      '0.50, since the second draw is equally likely to differ from the first.',
      '0.15, since only the order red then blue is possible.',
    ],
    correct: 0,
    rationale:
      'The mutually exclusive orders give 0.15 + 0.15 = 0.30. Option 2 arises from forgetting that the colour counts differ, and option 3 wrongly assumes equal likelihood when the bag is not balanced.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Argue',
    text: 'Argue a position on whether calculators should be permitted in MYP Mathematics examinations, and state one counterargument.',
    options: [
      'Permitting them extends what students can calculate rather than what they can reason; the counterargument is that without them, examiners cannot verify the arithmetic that later courses assume.',
      'They should always be banned, because they remove all value from a written examination.',
      'They should never be used, because they are beyond the capability of MYP students.',
      'They should always be used, because they guarantee accurate answers.',
    ],
    correct: 0,
    rationale:
      'A reasoned argument must advance a substantive claim and acknowledge the opposing case; only option 0 does both. Options 1 to 3 are assertions without reasoning and none addresses a counterargument.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate which single display best communicates the spread of a data set containing one extreme value.',
    options: [
      'Report the range together with the interquartile range, since the interquartile range resists extreme values while the range shows the full extent.',
      'Report the mean alone, since one number is the simplest for a reader to interpret.',
      'Report the mode alone, since it identifies the most frequently occurring value.',
      'Report the largest value alone, since it bounds the data set from above.',
    ],
    correct: 0,
    rationale:
      'Using a resistant statistic alongside a sensitive one exposes the influence of the extreme value. Options 1 to 3 each report a single statistic that conceals the very information being sought.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Critique',
    text: 'Critique the reasoning: "Since 0.7 x 0.7 = 0.49, and 0.49 is below 0.5, there is no association between the two variables."',
    options: [
      'The reasoning confuses a combined probability with the evidence for association, which depends on how far the observed proportion departs from expectation across many trials.',
      'The reasoning is sound, because 0.49 is smaller than 0.5.',
      'The reasoning is sound, because the two trials were independent.',
      'The reasoning is invalid only because the sample size was not stated.',
    ],
    correct: 0,
    rationale:
      'Multiplication of probabilities answers a different question from association between variables. Option 1 treats a numerical comparison as proof in both directions and option 3 misuses the definition of independence.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Assess',
    text: 'Assess the claim that a bar chart is always the best display for comparing results across four categories.',
    options: [
      'The claim is not justified: bar charts suit discrete categories but hide the distribution within each category and mislead if categories are unequal in size.',
      'The claim is justified, because a bar chart can represent any kind of data.',
      'The claim is justified, because bar charts share a common baseline.',
      'The claim is not justified only because bar charts take too long to construct by hand.',
    ],
    correct: 0,
    rationale:
      'Assessment requires weighing a real advantage against a real limitation. Option 1 accepts a genuine strength but identifies substantive weaknesses, whereas options 1 to 3 in the other cases offer only trivial objections.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Evaluate',
    text: 'A school announces that "84% of students passed" without stating how many students sat the examination. Evaluate the reliability of this claim.',
    options: [
      'The claim is weak, because without the cohort size the percentage cannot be interpreted: 84% of 20 is far less robust than 84% of 400.',
      'The claim is reliable, because a percentage is independent of the cohort size.',
      'The claim is unreliable only because the pass threshold was not stated.',
      'The claim is unreliable only because a high pass rate is educationally undesirable.',
    ],
    correct: 0,
    rationale:
      'A proportion without its denominator cannot convey evidential weight. Option 1 wrongly treats a percentage as sample-size independent, and option 3 substitutes a value judgement for an evidential one.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Apply',
    text: 'A recipe uses 5 cups of flour to make 12 muffins. Apply proportional reasoning to find the flour needed for 30 muffins, stating the assumption made.',
    options: [
      '18.75 cups, assuming the ratio continues to hold and no other ingredient becomes limiting.',
      '12.5 cups, assuming the ratio continues to hold and no other ingredient becomes limiting.',
      '25 cups, assuming each additional muffin requires half a cup of flour.',
      '36 cups, assuming the mixture volume doubles with each muffin.',
    ],
    correct: 1,
    rationale:
      'Direct proportion gives 5 x (30/12) = 150/12 = 12.5 cups, provided the ratio holds and no other ingredient becomes limiting. Option 0 miscomputes 150/12, option 2 assumes an additive rather than proportional rule, and option 3 introduces an unsupported doubling.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Reflect',
    text: 'Reflect on the principal limitation of reporting a student\'s mathematics achievement as a single grade from 1 to 8.',
    options: [
      'A single grade collapses distinct strengths and weaknesses across knowing, processing, applying and creating into one figure, so two students with the same grade can have very different profiles.',
      'A single grade is limited only because it is difficult to compute accurately.',
      'A single grade is not limited, because it is a fully objective measure of attainment.',
      'A single grade is limited only because students prefer qualitative feedback.',
    ],
    correct: 0,
    rationale:
      'Criterion C requires reflection on the consequences of assessment design for learning. Option 0 identifies a substantive loss of information, while the remaining options raise matters of preference rather than validity.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Critique',
    text: 'A textbook shows a scalene triangle with three medians drawn, and the caption refers to them simply as "the lines". Critique this description.',
    options: [
      'The description is imprecise because "the lines" is not mathematically specific; each median joins a vertex to the midpoint of the opposite side, and this must be stated.',
      'The description is acceptable, because the diagram itself shows exactly which segments are drawn.',
      'The description is acceptable, because all segments drawn inside a triangle are equivalent.',
      'The description is imprecise only because the diagram is not drawn to scale.',
    ],
    correct: 0,
    rationale:
      'Mathematical communication depends on unambiguous terminology, and an unlabelled diagram cannot substitute for it. Option 1 ignores that readers need the defining property, not merely the pixels shown.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Evaluate',
    text: 'A study relating hours of sleep to reaction time reports a correlation coefficient of -0.82. Evaluate what this evidence supports.',
    options: [
      'It supports a reliable inverse association but not direction or cause; sleep may improve reaction time, slow reactions may delay bedtime, or a confounding factor such as caffeine may drive both.',
      'It supports the conclusion that sleep causes faster reactions.',
      'It supports the conclusion that there is no relationship between sleep and reaction time.',
      'It indicates only that reaction time was measured incorrectly.',
    ],
    correct: 0,
    rationale:
      'The magnitude of correlation indicates strength of association only. Options 1 and 2 commit the causal inference error, and option 3 misreads the sign of the coefficient as absence of relationship.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Justify',
    text: 'Justify why the median is preferred to the mean when comparing house prices in a city where a small number of mansions distort the average.',
    options: [
      'Because the median depends only on the position of the central value once data are ordered, so one extreme value barely shifts it, whereas the mean incorporates every magnitude.',
      'Because the median is always numerically smaller than the mean for any data set.',
      'Because the median is the only measure that can be calculated for this data.',
      'Because the mean cannot be calculated once any value exceeds a certain amount.',
    ],
    correct: 0,
    rationale:
      'Resistance to outlying values is the defining advantage claimed for the median. Option 1 states a relation between measures that is not universally true, and option 3 confuses resistance with computability.',
  }),

  // ---------------- Criterion D: Real-world application and reflection (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 1,
    command: 'Calculate',
    text: 'A rectangular field measures 8 m by 5 m. Determine its area and its perimeter, giving each with its correct unit.',
    options: [
      'Area 40 m^2; perimeter 26 m',
      'Area 26 m^2; perimeter 40 m',
      'Area 40 m^2; perimeter 13 m',
      'Area 13 m^2; perimeter 40 m',
    ],
    correct: 0,
    rationale:
      'Area is 8 x 5 = 40 square metres and perimeter is 2(8 + 5) = 26 metres; the differing units are the discriminant. Option 1 applies the correct formulae but attaches the wrong units, a standard Criterion D error.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Determine',
    text: 'Two water tanks are available. Tank A measures 2 m by 1 m by 1 m and Tank B measures 1.5 m by 1.5 m by 1 m. Determine which tank holds more water.',
    options: [
      'Tank A, because it holds 2 m^3, which is greater than the 2.25 m^3 held by Tank B.',
      'Tank B, because it holds 2.25 m^3, which is greater than the 2 m^3 held by Tank A.',
      'Tank A, because it has the greater external surface area.',
      'Neither, because tanks with different dimensions cannot be compared.',
    ],
    correct: 1,
    rationale:
      'Capacity is volume, so A = 2 m^3 and B = 2.25 m^3, making B the larger. Option 0 uses the right method but misstates the comparison, and option 2 substitutes an irrelevant measurement.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Apply',
    text: 'A journey of 240 km is completed at an average speed of 80 km per hour. Apply the relationship between distance, speed and time to determine the duration of the journey.',
    options: [
      '3 hours, because duration is obtained by dividing distance by speed.',
      '19 200 hours, because speed multiplied by duration gives distance.',
      '0.33 hours, because duration is obtained by dividing speed by distance.',
      '6 hours, because the journey is assumed to be a return trip.',
    ],
    correct: 0,
    rationale:
      '240 divided by 80 gives 3 hours. Option 1 applies the relationship in the wrong direction, and option 3 introduces an unstated assumption about a return journey.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Determine',
    text: 'Tariff A charges $20 per month plus $0.10 per minute. Tariff B charges $0.15 per minute with no monthly fee. Determine the cheaper option for 250 minutes of use.',
    options: [
      'Tariff A, costing $45 compared with $37.50 on Tariff B.',
      'Tariff B, costing $37.50 compared with $45 on Tariff A.',
      'Both cost $45, so the choice has no financial consequence.',
      'Tariff B, costing $27.50 compared with $45 on Tariff A.',
    ],
    correct: 1,
    rationale:
      'Tariff A gives 20 + 25 = $45 while Tariff B gives 250 x 0.15 = $37.50, so B is cheaper by $7.50. Option 2 forgets the flagfall arithmetic and option 3 omits the per-minute cost.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Solve problem',
    text: 'Tickets cost $8 for adults and $5 for children. A total of 34 tickets were sold for $251. Solve for the number of children sold.',
    options: [
      '7 children and 27 adults, since 5c + 8(34 - c) = 251 simplifies to 272 - 3c = 251, giving c = 7.',
      '27 children and 7 adults, since 5c + 8(34 - c) = 251 simplifies to 272 - 3c = 251, giving c = 27.',
      '17 children and 17 adults, since the average ticket price is $7.38.',
      '14 children and 20 adults, since 5c + 8(34 - c) = 215 gives c = 14.',
    ],
    correct: 0,
    rationale:
      'Setting 5c + 8(34 - c) = 251 yields 3c = 21 and c = 7, verified by 7(5) + 27(8) = 251. Option 1 inverts the variable, option 2 substitutes a mean for two unknowns, and option 3 misapplies the total.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Use information',
    text: 'A map has a scale of 1:25 000. Determine the actual distance in kilometres between two points that are 8 cm apart on the map.',
    options: ['2 km', '0.32 km', '200 km', '20 km'],
    correct: 0,
    rationale:
      'Multiplying by 25 000 gives 200 000 cm, which is 2 km. Option 1 inverts the scale factor and option 2 fails to convert from centimetres to kilometres.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Analyse',
    text: 'Analyse why simple interest rather than compound interest is the correct model for a school loan repaid in a single instalment within one year, with no further borrowing possible.',
    options: [
      'Because interest accrues on a reducing balance only and interest-on-interest cannot arise within a single repayment period, so simple interest gives the identical total.',
      'Because simple interest always produces more interest than compound interest.',
      'Because compound interest cannot be calculated for periods shorter than one year.',
      'Because simple interest does not require the principal to be known in advance.',
    ],
    correct: 0,
    rationale:
      'Without a second compounding interval the two models coincide, so using the compound formula would overstate the debt. Option 1 reverses the direction of the effect and option 2 misstates a basic property of the two models.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Apply',
    text: 'A population of 20 000 contains 5 000 people aged over 65 and 3 000 children under 15. Apply the dependency ratio to determine the number of dependants per 100 working-age people.',
    options: [
      '66.7, since there are 8 000 dependants and 12 000 working-age people, giving 8 000/12 000 x 100.',
      '40, since there are 8 000 dependants in a population of 20 000, giving 8 000/20 000 x 100.',
      '25, since only those aged over 65 are counted as dependants.',
      '150, since 20 000 people divided by 8 000 dependants gives 2.5, which is then multiplied by 100.',
    ],
    correct: 0,
    rationale:
      'Working-age population is 20 000 - 8 000 = 12 000, so the ratio is 8 000/12 000 x 100 = 66.7. Option 2 uses the wrong denominator and option 3 excludes the child dependants.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Investigate',
    text: 'Investigate which fields on a bank statement provide the strongest evidence for identifying recurring expenditure.',
    options: [
      'The transaction description together with the date and amount, because recurrence is established when similar amounts under the same description appear across consecutive statements.',
      'The account number, because it identifies the account being analysed.',
      'The statement closing balance, because it accumulates all income and expenditure.',
      'The cash machine location code, because it identifies where withdrawals were made.',
    ],
    correct: 0,
    rationale:
      'Recurrence is a temporal and descriptive pattern, so the description, date and amount must be read together. Options 1 to 3 identify fields that are constant across the statement or unrelated to repetition.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the claim that a linear model is always adequate for describing how a child\'s height changes over time.',
    options: [
      'The claim is not justified, because growth is not linear: rapid early increase, a plateau at adolescence and later slowdown cause a linear model to diverge over time.',
      'The claim is justified, because height always increases at a constant rate.',
      'The claim is justified, because linear models are the simplest to interpret.',
      'The claim is not justified only because height is measured in centimetres rather than metres.',
    ],
    correct: 0,
    rationale:
      'A model is adequate only within the range over which it was fitted, and human growth is sigmoidal. Option 1 asserts a constant rate that is directly contradicted by growth data.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Investigate',
    text: 'A village must choose between a wind turbine and solar panels to supply community electricity. Investigate which factor is decisive for this specific location.',
    options: [
      'The consistency and timing of the local resource, comparing reliable sunlight hours against mean wind speed and its diurnal profile, since intermittency determines whether storage or backup is required.',
      'The colour of the turbine blades, because appearance determines community acceptance.',
      'The weight of the turbine, because heavier equipment resists high winds.',
      'The name of the manufacturer, because the brand determines conversion efficiency.',
    ],
    correct: 0,
    rationale:
      'Resource intermittency dominates system design because it sets the required storage and backup capacity, which drives cost. Options 1 to 3 substitute aesthetic, structural or brand considerations for the engineering variable that governs feasibility.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Reflect',
    text: 'Reflect on the consequences of choosing revenue rather than profit as the metric for deciding which of two local businesses is performing better.',
    options: [
      'The metric can reverse the conclusion, since a high-revenue business may carry higher costs and lower profit, so the choice encodes a value judgment while appearing objective.',
      'The choice of metric has no effect, because all financial metrics rank businesses identically.',
      'The choice of metric affects only the presentation of the report, not its conclusions.',
      'Revenue is always the most objective metric available for business analysis.',
    ],
    correct: 0,
    rationale:
      'Metric selection determines which performance dimension is made visible and which is hidden, so it is never neutral. Option 1 wrongly assumes every metric gives the same ranking.',
  }),
];

export default withIds(SUBJECT, items);
