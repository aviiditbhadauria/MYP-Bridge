import part1 from './questions.langacq-part1.js';
import part2 from './questions.langacq-part2.js';

export default [...part1, ...part2];
