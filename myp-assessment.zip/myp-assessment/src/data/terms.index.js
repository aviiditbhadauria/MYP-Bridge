/**
 * Combined glossary index.
 *
 * Concatenates the command-term, framework and subject-specific files and
 * asserts the invariants the seed script and API rely on: unique terms, one
 * definition per term, and a valid criterion association.
 */
import commands from './terms-commands.js';
import framework from './terms-framework.js';
import subjectPart1 from './terms-subject-part1.js';
import subjectPart2 from './terms-subject-part2.js';
import classroom from './terms-classroom.js';
import pathway from './terms-pathway.js';

const VALID_CRITERIA = new Set(['A', 'B', 'C', 'D', 'E', 'F']);

/**
 * Framework-wide vocabulary spans every criterion, so `criterion_association`
 * is legitimately null on those entries. A non-null value must be a real
 * criterion letter.
 */
const VALID_CATEGORIES = new Set([
  // Framework and assessment vocabulary
  'MYP Framework',
  'Global Context',
  'Assessment Criterion',
  'Assessment',
  'Equivalency Board',
  'Conceptual Understanding',
  'Related Concept',
  'Concept',
  'Research',
  // Command terms
  'Command Term',
  // Subject vocabulary
  'Mathematics Concept',
  'Mathematics Skill',
  'Sciences Concept',
  'Sciences Skill',
  'L&L Concept',
  'L&L Skill',
  'I&S Concept',
  'I&S Skill',
  'LA Concept',
  'LA Skill',
  'Design Concept',
  'Design Skill',
  'PHE Concept',
  'Visual Arts Concept',
  'IDU Concept',
  'Pathway Concept',
]);

export const keyTerms = [
  ...commands,
  ...framework,
  ...subjectPart1,
  ...subjectPart2,
  ...classroom,
  ...pathway,
];

/** Throws on any malformed entry so bad data never reaches the database. */
export function validateTerms(terms = keyTerms) {
  const seen = new Set();
  const errors = [];

  terms.forEach((entry, index) => {
    const label = entry?.term ?? `index ${index}`;
    const required = [
      'term',
      'subject_group',
      'category',
      'formal_definition',
      'myp_context_example',
    ];
    for (const field of required) {
      if (typeof entry?.[field] !== 'string' || entry[field].trim() === '') {
        errors.push(`${label}: missing or empty "${field}"`);
      }
    }
    if (
      entry?.criterion_association !== null &&
      !VALID_CRITERIA.has(entry?.criterion_association)
    ) {
      errors.push(`${label}: invalid criterion "${entry?.criterion_association}"`);
    }
    if (typeof entry.term === 'string') {
      const key = entry.term.trim().toLowerCase();
      if (seen.has(key)) errors.push(`${label}: duplicate term`);
      seen.add(key);
    }
    if (entry.criterion_association && !VALID_CRITERIA.has(entry.criterion_association)) {
      errors.push(`${label}: invalid criterion "${entry.criterion_association}"`);
    }
    if (entry.category && !VALID_CATEGORIES.has(entry.category)) {
      errors.push(`${label}: invalid category "${entry.category}"`);
    }
    if (entry.related_terms && !Array.isArray(entry.related_terms)) {
      errors.push(`${label}: related_terms must be an array`);
    }
  });

  if (errors.length) {
    throw new Error(`Glossary validation failed:\n  - ${errors.join('\n  - ')}`);
  }
  return terms.length;
}

export const TERM_CATEGORIES = [...VALID_CATEGORIES];

export default keyTerms;
