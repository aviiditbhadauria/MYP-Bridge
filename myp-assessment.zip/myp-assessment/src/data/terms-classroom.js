/**
 * Classroom-discussion vocabulary.
 *
 * These are the terms a teacher is likely to name mid-dialogue. They exist so
 * that every interactive tag in the Subject Guides classroom panel resolves to
 * a real glossary entry rather than dead-linking.
 */
export default [
  {
    term: 'Inquire',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'To ask for information or initiate a systematic investigation, framed by a question that directs the enquiry.',
    myp_context_example:
      'Before building the ramp model, the design group inquires into how a wheelchair user navigates a step-free route through the school.',
    related_terms: ['Analyse', 'Investigate', 'Synthesize'],
  },
  {
    /*
     * The command term is spelled "Analyse" in the canonical glossary, and the
     * search layer already folds the American "Analyze" onto it. Adding a second
     * American-spelled entry would duplicate one concept across two rows and
     * change what a plain "Analyze" query ranks first, so guide anchors and
     * dialogue spans reference "Analyse" instead.
     */
    term: 'Synthesize',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'To combine distinct elements, ideas or disciplinary perspectives into a coherent whole that is greater than its parts.',
    myp_context_example:
      'The interdisciplinary unit synthesizes a physics input on load with a design constraint on cost to arrive at a buildable ramp.',
    related_terms: ['Analyse', 'Evaluate', 'Formulate'],
  },
  {
    term: 'Formulate',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'To express relevant ideas or plans systematically and precisely, in a form that others can act on.',
    myp_context_example:
      'The team formulates a design specification stating dimension, material and load rating so that another group could build it.',
    related_terms: ['Synthesize', 'Plan', 'Evaluate'],
  },
  {
    term: 'Aesthetic',
    subject_group: 'Design',
    criterion_association: 'A',
    category: 'Design Concept',
    formal_definition:
      'Pertaining to the visual, sensory and artistic qualities of a design or artwork, and to the judgements made about them.',
    myp_context_example:
      'A student defends an aesthetic decision by naming the colour relationship and explaining its effect on the viewer.',
    related_terms: ['Style', 'Visual identity', 'Design intent'],
  },
  {
    term: 'Ergonomics',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Concept',
    formal_definition:
      'The study of designing environments, products and systems to optimize human well-being, safety and performance.',
    myp_context_example:
      'Seat height is set using ergonomic data so that the user can work without strain, rather than by visual preference alone.',
    related_terms: ['Feasibility', 'Client', 'User-centred design'],
  },
  {
    term: 'Client',
    subject_group: 'Design',
    criterion_association: 'C',
    category: 'Design Concept',
    formal_definition:
      'The primary stakeholder or user group for whom a design solution is developed and to whom it must answer.',
    myp_context_example:
      'Identifying the client as first-year students rather than facilities staff redirected the whole accessibility project.',
    related_terms: ['User-centred design', 'Stakeholder', 'Feasibility'],
  },
  {
    term: 'Feasibility',
    subject_group: 'Design',
    criterion_association: 'B',
    category: 'Design Concept',
    formal_definition:
      'The practical capability of a solution to be successfully executed within the given constraints of time, cost, tools and skills.',
    myp_context_example:
      'A concept is ruled out on feasibility grounds once the group confirms the school workshop cannot machine the required joint.',
    related_terms: ['Ergonomics', 'Constraint', 'Client'],
  },
  {
    term: 'Service as Action',
    subject_group: 'Individuals and Societies',
    criterion_association: 'F',
    category: 'I&S Concept',
    formal_definition:
      'Experiential learning in which students apply knowledge developed in the classroom to purposeful, meaningful service in the wider community.',
    myp_context_example:
      'Building and installing an accessible ramp for the school library counts as Service as Action because it addresses a need identified by community members.',
    related_terms: ['Inquiry', 'Reflection', 'Community action', 'Global Context'],
  },
];