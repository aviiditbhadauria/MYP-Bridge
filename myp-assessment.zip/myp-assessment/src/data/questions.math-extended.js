import { q, withIds } from './question-builder.js';

const SUBJECT = 'Mathematics (Extended)';

const items = [
  // ---------------- Criterion A: Knowing and understanding (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Define',
    text: 'Define "logarithm" in the equation log base 2 of 8 = 3.',
    options: [
      'The exponent to which the base must be raised to give the stated value, so log base 2 of 8 = 3 because 2 raised to 3 equals 8.',
      'The result of dividing the value by the base, so 8 divided by 2 equals 4.',
      'The natural logarithm of the base, so the natural logarithm of 2 is approximately 0.69.',
      'The number of decimal places in the value, so 8 has one decimal place.',
    ],
    correct: 0,
    rationale:
      'A logarithm is an inverse exponent, so its defining property is that the base raised to the logarithm returns the argument. Option 1 confuses it with division, which only coincides for base 10.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Calculate',
    text: 'Determine the value of 3 + 4 x 2^2 using the correct order of operations.',
    options: ['19', '22', '28', '11'],
    correct: 0,
    rationale:
      'Exponentiation precedes multiplication, so 2^2 = 4, then 4 x 4 = 16, then 3 + 16 = 19. Option 2 multiplies before exponentiating and option 1 ignores the exponent, both of which Criterion A requires students to avoid.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Define',
    text: 'Define the term "net" in the context of a two-dimensional pattern.',
    options: [
      'A two-dimensional representation of a three-dimensional object that folds along edges without gaps or overlaps to form that object.',
      'The total surface area of a solid including its hidden base.',
      'The visible outline of a cube drawn in two dimensions.',
      'A two-dimensional scale drawing produced using isometric projection.',
    ],
    correct: 0,
    rationale:
      'A net must be foldable into the solid with every face present exactly once and no overlaps. Option 2 defines surface area and option 4 defines a different type of technical drawing.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Explain',
    text: 'A straight line is given by the equation y = 3x + 2. Explain what the coefficient of x, 3, represents geometrically.',
    options: [
      'The gradient of the line: for every 1 unit increase in x, y increases by 3 units.',
      'The y-intercept of the line, where it crosses the vertical axis.',
      'The number of units the line rises over its complete horizontal run.',
      'The angle the line makes with the vertical axis, measured in degrees.',
    ],
    correct: 0,
    rationale:
      'In y = mx + c, m is the gradient and c is the intercept. Option 1 describes c, and option 3 confuses gradient with total rise rather than rate of change.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'For 0 < x < 90 degrees, explain how tan x relates to the sides of a right-angled triangle that has x as one of its acute angles.',
    options: [
      'tan x equals the length of the side opposite x divided by the length of the side adjacent to x.',
      'tan x equals the length of the side adjacent to x divided by the length of the side opposite x.',
      'tan x equals the hypotenuse divided by the side opposite x.',
      'tan x equals the square of the hypotenuse divided by the sum of the squares of the other sides.',
    ],
    correct: 0,
    rationale:
      'Tangent is opposite over adjacent, while the reciprocal is cotangent. Option 1 reverses the ratio, which is the classic Criterion A error at this level.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Describe',
    text: 'Describe the transformation in which every point of a figure is rotated about a fixed centre through 90 degrees anticlockwise.',
    options: [
      'A rotation of 90 degrees anticlockwise about the given centre.',
      'A reflection in a line passing through the centre.',
      'A translation by the vector from the centre to any point.',
      'An enlargement centred on the given centre.',
    ],
    correct: 0,
    rationale:
      'Rotation is defined by a fixed centre, an angle and a direction, all three of which are specified. Option 3 is the only other transformation that is defined by reference to the centre.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'State',
    text: 'State the range of the function f(x) = 2x + 7.',
    options: [
      'All real numbers, since a non-zero linear function attains every real output.',
      'All real numbers greater than or equal to 7.',
      'Only the value 7.',
      'All real numbers less than 7.',
    ],
    correct: 0,
    rationale:
      'A non-zero gradient means the function is onto the reals, so its range is unrestricted. Option 2 describes the range of an exponential or logarithmic function with a vertical asymptote.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Explain',
    text: 'Explain why the discriminant of the quadratic x^2 - 4x + k determines whether it has two distinct real roots.',
    options: [
      'Because completing the square gives (x - 2)^2 = 4 - k, and a real square exists only when 4 - k is at least zero; it is strictly positive for two distinct roots.',
      'Because the discriminant equals the sum of the roots, which is always positive.',
      'Because the discriminant equals the gradient of the parabola, which is fixed at 1.',
      'Because a negative discriminant moves the roots into the complex plane regardless of the constant term.',
    ],
    correct: 0,
    rationale:
      'Completing the square makes the condition explicit: discriminant greater than zero, equal to zero or negative gives two distinct roots, one repeated root or no real roots respectively. Option 3 is a misidentification of what the discriminant measures.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Define',
    text: 'Define "variance" for a numerical data set.',
    options: [
      'The average of the squared deviations of each data value from the mean.',
      'The average distance of each data value from the mean, ignoring the direction of the deviation.',
      'The square root of the average of the squared deviations from the mean.',
      'The difference between the largest and the smallest values in the data set.',
    ],
    correct: 0,
    rationale:
      'Variance is the mean of the squared deviations. Option 2 defines standard deviation, and option 3 defines the range, neither of which is invariant in the way variance is.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Outline',
    text: 'Outline the steps used to solve x^2 - 5x + 6 = 0 by factorisation.',
    options: [
      'Identify factor pairs whose product is the constant and whose sum is the coefficient, write them as bracket factors, then set each factor equal to zero to obtain the roots.',
      'Take the square root of both sides, then subtract the coefficient of x from the resulting value.',
      'Differentiate the expression, set the derivative equal to zero and solve for the stationary point.',
      'Divide through by x to obtain a linear equation, then rearrange and solve.',
    ],
    correct: 0,
    rationale:
      'The quadratic factors as (x - 2)(x - 3), giving x = 2 and x = 3. Option 2 cannot be applied because the left side is not a perfect square, and option 3 finds a stationary point rather than roots.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Two similar solids have corresponding linear dimensions in the ratio 3:4. Explain the ratio of their volumes.',
    options: [
      '27:64, because volume scales with the cube of the linear scale factor, giving (3/4)^3.',
      '3:4, because volume scales by the same factor as the corresponding sides.',
      '9:16, because volume scales with the square of the linear scale factor.',
      '12:16, because volume scales by the sum of the scale factors of the three dimensions.',
    ],
    correct: 0,
    rationale:
      'All three dimensions scale by 3/4, so the volume scales by their product, 27/64. Option 2 wrongly applies the surface-area exponent and option 3 applies the square rather than the cube.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Explain why the base of an exponential function cannot be 1 or less if it is to describe exponential growth.',
    options: [
      'Because a base of 1 gives the constant function y = 1 and a base below 1 gives decay rather than growth, so neither produces an increasing exponential curve.',
      'Because a base of 1 makes the exponent undefined.',
      'Because any base below 1 produces negative values of y.',
      'Because bases must be whole numbers for the exponentiation to be defined.',
    ],
    correct: 0,
    rationale:
      'Growth requires a base strictly greater than 1, since the multiplier is the base. Option 2 wrongly claims the exponent is undefined, and option 3 confuses a base below 1 with a negative output.',
  }),

  // ---------------- Criterion B: Inquiring and designing (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 1,
    command: 'Pattern',
    text: 'A sequence begins 1, 4, 9, 16. Identify the next term by extending the pattern.',
    options: ['25', '20', '24', '32'],
    correct: 0,
    rationale:
      'The terms are consecutive square numbers, so the fifth term is 5 squared, which is 25. Option 1 continues with an additive rule of 4 that broke at the second term.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Pattern',
    text: 'A pattern produces the values 2, 5, 10, 17 for inputs n = 1, 2, 3, 4. Which rule generates this sequence?',
    options: ['value = n^2 + 1', 'value = 3n + 1', 'value = n^2 + n', 'value = 2n'],
    correct: 0,
    rationale:
      'Substituting each n into n^2 + 1 gives 2, 5, 10, 17, matching every term. Option 1 matches only the first value, and option 2 gives a constant difference where the data show an increasing one.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Compare',
    text: 'Compare the mean and the median of the data set 3, 5, 5, 7, 40.',
    options: [
      'The mean is higher than the median because the single extreme value raises the mean substantially while leaving the middle position untouched.',
      'The median is higher than the mean because the extreme value sits at the end of the sorted list.',
      'They are equal because the data set contains an odd number of values.',
      'The mean cannot be calculated because the data set contains an extreme value.',
    ],
    correct: 0,
    rationale:
      'The mean is 12 while the median is 5, so the extreme value dominates a mean built from every magnitude. Option 2 reverses the direction of the effect.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Compare',
    text: 'Compare the graphs of y = x^2 and y = 2x^2 across the interval from x = -3 to x = 3.',
    options: [
      'Both have a minimum at the origin, but y = 2x^2 rises twice as steeply, so it is steeper and diverges further from the origin.',
      'Both graphs are identical in shape and differ only in their vertical position.',
      'y = x^2 rises more steeply, since a smaller coefficient produces a steeper curve.',
      'Only y = x^2 has a minimum, since y = 2x^2 is a linear function.',
    ],
    correct: 0,
    rationale:
      'Scaling the coefficient of x squared scales the whole function vertically by a constant factor, so both remain parabolas with vertex at the origin but the second is steeper. Option 3 inverts the effect of the coefficient.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question is best formulated for investigating whether a species of plant grows faster in warm or in cool conditions?',
    options: [
      'How does the temperature of the growing environment affect the rate of growth of this species, with light, water and soil held constant?',
      'Is it true that plants grow faster in warm conditions?',
      'What is the effect of temperature on plants?',
      'Which is better for plant growth, warm or cool conditions?',
    ],
    correct: 0,
    rationale:
      'A testable inquiry question names the manipulated variable, states how the outcome is measured and identifies controlled variables. The remaining options are closed, leading or too vague to investigate systematically.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Organize',
    text: 'Organise a valid method for collecting data to compare the reaction times of students who play a musical instrument with those who do not.',
    options: [
      'Recruit consenting volunteers, define reaction time as a measurable variable, use identical apparatus and protocol for both groups, repeat trials and record the mean for each participant.',
      'Ask each student to time themselves at home and report the result in a spreadsheet.',
      'Time the first ten students and the last ten students and compare the group totals.',
      'Ask students which group they believe is faster and count the responses given.',
    ],
    correct: 0,
    rationale:
      'Validity requires a consistent operational definition, standardised conditions, repetition and consent. Option 2 collects subjective self-report data rather than measured reaction times.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Examine',
    text: 'Examine the claim that increasing the quantity of fertiliser applied to a crop always increases the yield.',
    options: [
      'The claim ignores diminishing returns: once another factor such as light or water becomes limiting, extra fertiliser produces no proportional gain and can run off and pollute watercourses.',
      'The claim is correct because fertiliser always supplies whichever nutrient is limiting growth.',
      'The claim is incorrect only because fertiliser is an expensive input for most farmers.',
      'The claim is correct for cereal crops but false for vegetable crops.',
    ],
    correct: 0,
    rationale:
      'Yield is constrained by the most limiting factor, so response to fertiliser is a saturating function rather than an unbounded one. Options 1 to 3 offer explanations with no mechanism behind them.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Prioritize',
    text: 'Four candidate factors affecting reaction time are proposed: number of practice trials, ambient noise level, time of day, and colour of the test paper. Prioritise which factor to investigate first and justify the choice.',
    options: [
      'Ambient noise level, because it can be varied independently and safely, is measurable, and has a plausible direct effect on sustained concentration.',
      'Colour of the test paper, because it is the only factor that changes during a test.',
      'Time of day, because it is invariably the most important factor in every investigation.',
      'Number of practice trials, because it cannot be controlled by the investigator.',
    ],
    correct: 0,
    rationale:
      'Prioritisation rests on testability, control and a plausible mechanism, all of which option 0 satisfies. Option 3 is invalid because trial count is one of the easiest variables to control.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Solve problem',
    text: 'A recipe serving 4 people requires 300 g of flour. Determine the mass of flour needed to serve 10 people, assuming ingredients scale proportionally.',
    options: [
      '750 g, since flour required is directly proportional to the number of people, giving 300 x (10/4).',
      '600 g, since 300 g is used and a further 10 g is added per extra person.',
      '3000 g, since 300 g is required for each of the 10 people.',
      '75 g, since the original quantity must be shared among the 10 servings.',
    ],
    correct: 0,
    rationale:
      'Direct proportion gives 300 x 2.5 = 750 g. Option 1 substitutes an additive rule, and option 2 misreads the original quantity as applying per person rather than per four people.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Develop',
    text: 'Develop a method for estimating the area of a pond using only a rigid stick and a numerical scale.',
    options: [
      'Set the stick vertically at the water edge, measure a land shadow of the same stick, derive a scale factor from the ratio of the two shadow lengths, then lay a scaled grid over the pond to estimate its area.',
      'Estimate the pond length and width with the stick, multiply the two figures and assume the pond is a perfect rectangle.',
      'Drop the stick into the pond, measure the resulting ripple ring and treat its diameter as the pond diameter.',
      'Walk around the perimeter counting paces, take the square root of the total and assume a circular pond.',
    ],
    correct: 0,
    rationale:
      'This method derives a consistent scale factor and then applies a grid, which handles irregular outlines. Option 1 assumes a rectangular basin and option 2 assumes a relationship between ripple size and basin size that does not exist.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Examine',
    text: 'Grade boundaries are derived from the raw results of a single examination sitting. Examine the principal limitation of this approach.',
    options: [
      'A single sitting may contain an unusually strong or weak cohort or a change in assessment design, so boundaries derived from it may not generalise to subsequent cohorts.',
      'A single sitting cannot supply enough data points for any boundary to be calculated.',
      'The approach cannot be used because raw scores are recorded as text rather than numbers.',
      'The approach is invalid only because examination boards do not publish raw scores.',
    ],
    correct: 0,
    rationale:
      'Validity of a boundary depends on cohort comparability across years, which a single sitting cannot establish. Options 1 to 3 each assert a mechanical or availability obstacle that does not exist.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Construct',
    text: 'A taxi fare is a fixed flagfall of $3 plus $1.50 per kilometre, with a further $2 surcharge applied to every journey. Construct the formula for the total cost C in terms of distance d.',
    options: ['C = 3 + 1.5d + 2', 'C = 3 + 1.5d - 2', 'C = (3 + 1.5)(d + 2)', 'C = 3d + 1.5 + 2'],
    correct: 0,
    rationale:
      'A constant flagfall and a constant surcharge are both added to a rate times distance, so three additive parts are required with distance multiplied only by the rate. Option 1 wrongly subtracts the surcharge.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Analyse',
    text: 'Analyse how a student should decide between solving a quadratic by factorisation, completing the square and applying the quadratic formula.',
    options: [
      'Factorisation is fastest when the numbers are whole and factorable, completing the square is needed to convert to vertex or discriminant form, and the formula applies universally but obscures structure, so the choice is one of efficiency versus clarity.',
      'The quadratic formula should always be used, because it is the only method that always works.',
      'Factorisation should always be used, because it is the only method that produces exact values.',
      'Completing the square should always be used, because it is the only method that reveals the discriminant.',
    ],
    correct: 0,
    rationale:
      'Method selection must weigh structural fit, arithmetic feasibility and what the answer must display. Option 1 is wrong because all three methods are universally valid, and option 2 wrongly restricts factorisation to cases where it works.',
  }),

  // ---------------- Criterion C: Communicating and thinking critically (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 1,
    command: 'Summarize',
    text: 'Summarize what the single statement "the mean is 20" communicates, and what it fails to communicate, about a data set.',
    options: [
      'It communicates a single measure of centre but not the spread, the shape or any of the individual values.',
      'It communicates both the centre and the spread of the data set completely.',
      'It communicates that exactly half of the values lie above 20.',
      'It communicates that the largest value in the data set is 20.',
    ],
    correct: 0,
    rationale:
      'A mean summarises position alone and conceals dispersion and distribution entirely. Options 1 and 2 misattribute properties of the median.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Justify',
    text: 'A student observes that students who revise for more hours tend to score higher, and concludes that revision causes higher scores. Justify or challenge this conclusion.',
    options: [
      'Challenge it: an association does not establish causation, since prior attainment or motivation could influence both the hours revised and the score obtained.',
      'Accept it: the association is consistent, so revision must be the causal factor.',
      'Accept it: revision is the only variable that was measured across the whole class.',
      'Challenge it: revision has no measurable effect on mathematical attainment.',
    ],
    correct: 0,
    rationale:
      'Confounding variables and reverse causation both explain the association without requiring revision to be the cause. Option 1 treats association as proof in both directions.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Apply',
    text: 'A bag holds 3 red and 5 blue counters. One counter is drawn, replaced, then drawn again. Apply probability to determine the probability of obtaining two counters of different colours.',
    options: [
      '0.30, computed as (3/10 x 5/10) + (5/10 x 3/10) for the two possible orders.',
      '0.60, computed by doubling the probability of one order.',
      '0.50, since the second draw is equally likely to differ from the first.',
      '0.15, since only the order red then blue is possible.',
    ],
    correct: 0,
    rationale:
      'The two mutually exclusive orders each give 0.15, so the total is 0.30. Option 3 wrongly assumes a balanced bag, and option 2 forgets that the colour counts differ.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Argue',
    text: 'Argue a position on whether graphical calculators should be permitted in MYP Mathematics examinations, and state one counterargument.',
    options: [
      'Permitting them extends what students can calculate rather than what they can reason; the counterargument is that without them, examiners cannot verify the arithmetic that later courses assume.',
      'They should always be banned, because they remove all value from a written examination.',
      'They should never be used, because they are beyond the capability of MYP students.',
      'They should always be used, because they guarantee accurate answers.',
    ],
    correct: 0,
    rationale:
      'A reasoned argument must advance a substantive claim and acknowledge the opposing case, which only option 0 does. The remaining options are unsupported assertions.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate which single display best communicates the spread of a data set containing one extreme value.',
    options: [
      'Report the range together with the interquartile range, since the interquartile range resists extreme values while the range shows the full extent.',
      'Report the mean alone, since one number is the simplest for a reader to interpret.',
      'Report the mode alone, since it identifies the most frequently occurring value.',
      'Report the largest value alone, since it bounds the data set from above.',
    ],
    correct: 0,
    rationale:
      'Pairing a resistant statistic with a sensitive one exposes the influence of the extreme value, which any single measure in the other options conceals.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Critique',
    text: 'Critique the reasoning: "Since 0.7 x 0.7 = 0.49, and 0.49 is below 0.5, there is no association between the two variables."',
    options: [
      'The reasoning confuses a combined probability with the evidence for association, which depends on how far the observed proportion departs from expectation across many trials.',
      'The reasoning is sound, because 0.49 is smaller than 0.5.',
      'The reasoning is sound, because the two trials were independent.',
      'The reasoning is invalid only because the sample size was not stated.',
    ],
    correct: 0,
    rationale:
      'Multiplying probabilities answers a different question from testing association between variables. Option 1 treats a numerical comparison as proof in either direction.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Assess',
    text: 'Assess the claim that a bar chart is always the best display for comparing results across four categories.',
    options: [
      'The claim is not justified: bar charts suit discrete categories but hide the distribution within each category and mislead if categories are unequal in size.',
      'The claim is justified, because a bar chart can represent any kind of data.',
      'The claim is justified, because bar charts share a common baseline.',
      'The claim is not justified only because bar charts take too long to construct by hand.',
    ],
    correct: 0,
    rationale:
      'Assessment must weigh a real advantage against a real limitation, which option 0 does. Option 2 identifies a genuine strength but offers no substantive objection to it.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Evaluate',
    text: 'A school announces that "84% of students passed" without stating how many students sat the examination. Evaluate the reliability of this claim.',
    options: [
      'The claim is weak, because without the cohort size the percentage cannot be interpreted: 84% of 20 is far less robust than 84% of 400.',
      'The claim is reliable, because a percentage is independent of the cohort size.',
      'The claim is unreliable only because the pass threshold was not stated.',
      'The claim is unreliable only because a high pass rate is educationally undesirable.',
    ],
    correct: 0,
    rationale:
      'A proportion without its denominator cannot convey evidential weight. Option 1 wrongly treats a percentage as independent of sample size, and option 3 substitutes a value judgement for an evidential one.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Reflect',
    text: 'Reflect on the principal limitation of reporting a student\'s mathematics achievement as a single grade from 1 to 8.',
    options: [
      'A single grade collapses distinct strengths and weaknesses across knowing, processing, applying and creating into one figure, so two students with the same grade can have very different profiles.',
      'A single grade is limited only because it is difficult to compute accurately.',
      'A single grade is not limited, because it is a fully objective measure of attainment.',
      'A single grade is limited only because students prefer qualitative feedback.',
    ],
    correct: 0,
    rationale:
      'Criterion C requires reflection on the consequences of assessment design for learning. Option 0 identifies substantive loss of information, while the others raise preference rather than validity.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Critique',
    text: 'A textbook shows a scalene triangle with three medians drawn, and the caption refers to them simply as "the lines". Critique this description.',
    options: [
      'The description is imprecise because "the lines" is not mathematically specific; each median joins a vertex to the midpoint of the opposite side, and this must be stated.',
      'The description is acceptable, because the diagram itself shows exactly which segments are drawn.',
      'The description is acceptable, because all segments drawn inside a triangle are equivalent.',
      'The description is imprecise only because the diagram is not drawn to scale.',
    ],
    correct: 0,
    rationale:
      'Mathematical communication depends on unambiguous terminology, and an unlabelled diagram cannot substitute for it. Option 1 fails because readers need the defining property, not merely the figure shown.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Evaluate',
    text: 'A study relating hours of sleep to reaction time reports a correlation coefficient of -0.82. Evaluate what this evidence supports.',
    options: [
      'It supports a reliable inverse association but not direction or cause; sleep may improve reaction time, slow reactions may delay bedtime, or a confounding factor such as caffeine may drive both.',
      'It supports the conclusion that sleep causes faster reactions.',
      'It supports the conclusion that there is no relationship between sleep and reaction time.',
      'It indicates only that reaction time was measured incorrectly.',
    ],
    correct: 0,
    rationale:
      'The magnitude of a correlation coefficient indicates strength of association only. Option 1 commits the causal inference error and option 2 misreads the sign as absence of relationship.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Critique',
    text: 'Critique the solution: "Let f(x) = 2x + 1. Since f(0) = 1 and f(1) = 3, the gradient is 2, so f(x) = 2x^2 + 1."',
    options: [
      'The gradient is correctly identified as 2, but a linear function with f(0) = 1 has y-intercept 1 and gradient 2, giving f(x) = 2x + 1; inserting an exponent not supported by any evidence misdescribes the function and every later value computed from it.',
      'The solution is correct, because the gradient determines the exponent.',
      'The solution is correct, because two points are enough to determine any function.',
      'The solution is incorrect only because the gradient was calculated wrongly.',
    ],
    correct: 0,
    rationale:
      'Two points on a straight line determine a unique linear function and give no evidence of curvature. Option 1 misattributes a power term to a gradient, and option 2 confuses determinacy within a family with determinacy of the family itself.',
  }),

  // ---------------- Criterion D: Real-world application and reflection (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 1,
    command: 'Calculate',
    text: 'A rectangular field measures 8 m by 5 m. Determine its area and its perimeter, giving each with its correct unit.',
    options: [
      'Area 40 m^2; perimeter 26 m',
      'Area 26 m^2; perimeter 40 m',
      'Area 40 m^2; perimeter 13 m',
      'Area 13 m^2; perimeter 40 m',
    ],
    correct: 0,
    rationale:
      'Area is 8 x 5 = 40 square metres and perimeter is 2(8 + 5) = 26 metres; the differing units are the discriminant. Option 1 applies the formulae but attaches the wrong units.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Determine',
    text: 'Two water tanks are available. Tank A measures 2 m by 1 m by 1 m and Tank B measures 1.5 m by 1.5 m by 1 m. Determine which tank holds more water.',
    options: [
      'Tank A, because it holds 2 m^3, which is greater than the 2.25 m^3 held by Tank B.',
      'Tank B, because it holds 2.25 m^3, which is greater than the 2 m^3 held by Tank A.',
      'Tank A, because it has the greater external surface area.',
      'Neither, because tanks with different dimensions cannot be compared.',
    ],
    correct: 1,
    rationale:
      'Capacity is volume, so A = 2 m^3 and B = 2.25 m^3, making B the larger. Option 2 substitutes an irrelevant surface-area measurement for capacity.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Apply',
    text: 'A journey of 240 km is completed at an average speed of 80 km per hour. Apply the relationship between distance, speed and time to determine the duration of the journey.',
    options: [
      '3 hours, because duration is obtained by dividing distance by speed.',
      '19 200 hours, because speed multiplied by duration gives distance.',
      '0.33 hours, because duration is obtained by dividing speed by distance.',
      '6 hours, because the journey is assumed to be a return trip.',
    ],
    correct: 0,
    rationale:
      '240 divided by 80 gives 3 hours. Option 1 applies the relationship in the wrong direction, and option 3 introduces an unstated assumption about a return journey.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Determine',
    text: 'Tariff A charges $20 per month plus $0.10 per minute. Tariff B charges $0.15 per minute with no monthly fee. Determine the cheaper option for 250 minutes of use.',
    options: [
      'Tariff A, costing $45 compared with $37.50 on Tariff B.',
      'Tariff B, costing $37.50 compared with $45 on Tariff A.',
      'Both cost $45, so the choice has no financial consequence.',
      'Tariff B, costing $27.50 compared with $45 on Tariff A.',
    ],
    correct: 1,
    rationale:
      'Tariff A gives 20 + 25 = $45 while Tariff B gives 250 x 0.15 = $37.50, so B is cheaper by $7.50. Option 2 omits the per-minute cost and option 3 miscalculates Tariff B.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Solve problem',
    text: 'Tickets cost $8 for adults and $5 for children. A total of 34 tickets were sold for $251. Solve for the number of children sold.',
    options: [
      '7 children and 27 adults, since 5c + 8(34 - c) = 251 simplifies to 272 - 3c = 251, giving c = 7.',
      '27 children and 7 adults, since 5c + 8(34 - c) = 251 simplifies to 272 - 3c = 251, giving c = 27.',
      '17 children and 17 adults, since the average ticket price is $7.38.',
      '14 children and 20 adults, since 5c + 8(34 - c) = 215 gives c = 14.',
    ],
    correct: 0,
    rationale:
      'Setting 5c + 8(34 - c) = 251 gives 3c = 21 and c = 7, verified by 7(5) + 27(8) = 251. Option 1 inverts the variable and option 3 substitutes a mean for two unknowns.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Use information',
    text: 'A map has a scale of 1:25 000. Determine the actual distance in kilometres between two points that are 8 cm apart on the map.',
    options: ['2 km', '0.32 km', '200 km', '20 km'],
    correct: 0,
    rationale:
      'Multiplying by 25 000 gives 200 000 cm, which is 2 km. Option 1 inverts the scale factor and option 2 omits the unit conversion.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Calculate',
    text: 'A loan of $2 000 is repaid with simple interest at 6% per year for 3 years. Determine the total amount repaid.',
    options: ['$2 360', '$2 180', '$2 400', '$1 160'],
    correct: 0,
    rationale:
      'Interest is 2000 x 0.06 x 3 = $360, giving a total of $2 360. Option 1 computes one year of interest only and option 2 applies interest to the wrong base.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Analyse',
    text: 'Analyse why simple interest rather than compound interest is the correct model for a school loan repaid in a single instalment within one year, with no further borrowing possible.',
    options: [
      'Because interest accrues on a reducing balance only and interest-on-interest cannot arise within a single repayment period, so simple interest gives the identical total.',
      'Because simple interest always produces more interest than compound interest.',
      'Because compound interest cannot be calculated for periods shorter than one year.',
      'Because simple interest does not require the principal to be known in advance.',
    ],
    correct: 0,
    rationale:
      'Without a second compounding interval the two models coincide, so using the compound formula would overstate the debt. Option 1 reverses the direction of the comparison.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Apply',
    text: 'A population of 20 000 contains 5 000 people aged over 65 and 3 000 children under 15. Apply the dependency ratio to determine the number of dependants per 100 working-age people.',
    options: [
      '66.7, since there are 8 000 dependants and 12 000 working-age people, giving 8 000/12 000 x 100.',
      '40, since there are 8 000 dependants in a population of 20 000, giving 8 000/20 000 x 100.',
      '25, since only those aged over 65 are counted as dependants.',
      '150, since 20 000 people divided by 8 000 dependants gives 2.5, which is then multiplied by 100.',
    ],
    correct: 0,
    rationale:
      'The working-age population is 20 000 - 8 000 = 12 000, so the ratio is 8 000/12 000 x 100 = 66.7. Option 2 uses the wrong denominator and option 3 omits child dependants.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Investigate',
    text: 'Investigate which fields on a bank statement provide the strongest evidence for identifying recurring expenditure.',
    options: [
      'The transaction description together with the date and amount, because recurrence is established when similar amounts under the same description appear across consecutive statements.',
      'The account number, because it identifies the account being analysed.',
      'The statement closing balance, because it accumulates all income and expenditure.',
      'The cash machine location code, because it identifies where withdrawals were made.',
    ],
    correct: 0,
    rationale:
      'Recurrence is a temporal and descriptive pattern, so description, date and amount must be read together. The remaining options identify fields that are constant across the statement or unrelated to repetition.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the claim that a linear model is always adequate for describing how a child\'s height changes over time.',
    options: [
      'The claim is not justified, because growth is not linear: rapid early increase, a plateau at adolescence and later slowdown cause a linear model to diverge over time.',
      'The claim is justified, because height always increases at a constant rate.',
      'The claim is justified, because linear models are the simplest to interpret.',
      'The claim is not justified only because height is measured in centimetres rather than metres.',
    ],
    correct: 0,
    rationale:
      'A model is adequate only within the range over which it was fitted, and human growth is sigmoidal. Option 1 asserts a constant rate contradicted by growth data.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Investigate',
    text: 'A village must choose between a wind turbine and solar panels to supply community electricity. Investigate which factor is decisive for this specific location.',
    options: [
      'The consistency and timing of the local resource, comparing reliable sunlight hours against mean wind speed and its diurnal profile, since intermittency determines whether storage or backup is required.',
      'The colour of the turbine blades, because appearance determines community acceptance.',
      'The weight of the turbine, because heavier equipment resists high winds.',
      'The name of the manufacturer, because the brand determines conversion efficiency.',
    ],
    correct: 0,
    rationale:
      'Resource intermittency dominates system design because it sets the required storage and backup capacity, which drives cost. Options 1 to 3 substitute aesthetic, structural or brand factors for the engineering variable that governs feasibility.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Reflect',
    text: 'Reflect on the consequences of choosing revenue rather than profit as the metric for deciding which of two local businesses is performing better.',
    options: [
      'The metric can reverse the conclusion, since a high-revenue business may carry higher costs and lower profit, so the choice encodes a value judgment while appearing objective.',
      'The choice of metric has no effect, because all financial metrics rank businesses identically.',
      'The choice of metric affects only the presentation of the report, not its conclusions.',
      'Revenue is always the most objective metric available for business analysis.',
    ],
    correct: 0,
    rationale:
      'Metric selection determines which performance dimension is made visible and which hidden, so it is never neutral. Option 1 wrongly assumes every metric produces the same ranking.',
  }),
];

export default withIds(SUBJECT, items);
