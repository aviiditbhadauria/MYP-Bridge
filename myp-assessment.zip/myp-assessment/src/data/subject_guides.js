/**
 * Subject Guides loader.
 *
 * Reads the modular JSON payload in ./guides/ and validates it against the
 * glossary so no interactive term anchor can point at a definition that does
 * not exist. Validation runs at import time, so a malformed payload fails the
 * process at boot rather than rendering a broken panel.
 */
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import keyTerms from './terms.index.js';

const here = dirname(fileURLToPath(import.meta.url));
const GUIDES_DIR = join(here, 'guides');

/** The only two payload roles allowed in the guides directory. */
const ROLE = { GUIDE: 'guide', DIALOGUE: 'dialogue' };

const BAND_KEYS = ['1-2', '3-4', '5-6', '7-8'];
const CRITERION_IDS = ['A', 'B', 'C', 'D'];

function readJson(file) {
  return JSON.parse(readFileSync(file, 'utf8'));
}

/**
 * Role is derived from the id rather than the filename, so a file can be
 * renamed without silently changing what it contributes.
 */
function roleOf(doc) {
  if (Array.isArray(doc?.turns) && Array.isArray(doc?.term_map)) return ROLE.DIALOGUE;
  if (doc?.criteria?.length) return ROLE.GUIDE;
  return null;
}

const payload = readdirSync(GUIDES_DIR)
  .filter((f) => f.endsWith('.json'))
  .sort()
  .map((f) => ({ file: f, doc: readJson(join(GUIDES_DIR, f)) }))
  .map(({ file, doc }) => ({ file, doc, role: roleOf(doc) }));

export const subjectGuides = payload
  .filter((p) => p.role === ROLE.GUIDE)
  .map((p) => p.doc);

export const classroomDialogues = payload
  .filter((p) => p.role === ROLE.DIALOGUE)
  .map((p) => p.doc);

/** Lower-cased glossary index for anchor resolution. */
const glossaryIndex = new Map(keyTerms.map((t) => [t.term.toLowerCase(), t]));

/** Reconstructs the plain text of a turn from its segments. */
export function turnText(turn) {
  return turn.segments.map((s) => s.value).join('');
}

function validateGuide(guide, errors) {
  const label = guide?.id ?? 'unnamed guide';
  if (!guide?.id || !/^[a-z0-9-]+$/.test(guide.id)) {
    errors.push(`${label}: id must be a lowercase hyphenated slug`);
  }
  if (!guide?.name) errors.push(`${label}: missing name`);
  if (!guide?.framework_overview || guide.framework_overview.length < 80) {
    errors.push(`${label}: framework_overview must be a substantive paragraph`);
  }
  for (const field of ['assessment_objectives', 'eassessment_expectations']) {
    if (!Array.isArray(guide?.[field]) || guide[field].length === 0) {
      errors.push(`${label}: ${field} must be a non-empty array`);
    }
  }
  if (!Array.isArray(guide?.global_contexts) || guide.global_contexts.length === 0) {
    errors.push(`${label}: global_contexts must be a non-empty array`);
  }
  if (!Array.isArray(guide?.criteria)) {
    errors.push(`${label}: criteria must be an array`);
    return;
  }

  const ids = guide.criteria.map((c) => c.id);
  // Service as Action is assessed on three areas rather than four criteria, so a
  // guide may supply either A-D or A-C. The sequence must be contiguous from A.
  const expectedLength = 4;
  const validSequence =
    (ids.length === expectedLength || ids.length === 3) &&
    ids.every((id, i) => id === CRITERION_IDS[i]);
  if (!validSequence) {
    errors.push(
      `${label}: criteria ids must be a contiguous run from A (A-D, or A-C for Service as Action); got ${ids.join(', ') || 'none'}`,
    );
  }

  for (const criterion of guide.criteria) {
    const cLabel = `${label} criterion ${criterion.id}`;
    if (!criterion.name) errors.push(`${cLabel}: missing name`);
    if (!criterion.bands || typeof criterion.bands !== 'object') {
      errors.push(`${cLabel}: bands must be an object`);
      continue;
    }
    const present = Object.keys(criterion.bands);
    const missing = BAND_KEYS.filter((b) => !present.includes(b));
    const extra = present.filter((b) => !BAND_KEYS.includes(b));
    if (missing.length) errors.push(`${cLabel}: missing score bands ${missing.join(', ')}`);
    if (extra.length) errors.push(`${cLabel}: unexpected score bands ${extra.join(', ')}`);
    for (const band of BAND_KEYS) {
      const text = criterion.bands?.[band];
      if (typeof text !== 'string' || text.trim().length < 20) {
        errors.push(`${cLabel}: band "${band}" needs a substantive descriptor`);
      }
    }
    for (const term of criterion.term_anchors ?? []) {
      if (!glossaryIndex.has(String(term).toLowerCase())) {
        errors.push(`${cLabel}: term anchor "${term}" is not in the glossary`);
      }
    }
  }
}

function validateDialogue(dialogue, errors) {
  const label = dialogue?.id ?? 'unnamed dialogue';
  if (!dialogue?.title) errors.push(`${label}: missing title`);
  if (!dialogue?.context) errors.push(`${label}: missing context`);

  // guide_ids is what the client matches on, so a typo here would silently
  // hide a transcript from its subject group. Fail loudly instead.
  if (!Array.isArray(dialogue?.guide_ids) || dialogue.guide_ids.length === 0) {
    errors.push(`${label}: guide_ids must be a non-empty array`);
  } else {
    for (const id of dialogue.guide_ids) {
      if (!subjectGuides.some((g) => g.id === id)) {
        errors.push(`${label}: guide_ids references unknown guide "${id}"`);
      }
    }
  }

  if (!Array.isArray(dialogue?.turns) || dialogue.turns.length === 0) {
    errors.push(`${label}: turns must be a non-empty array`);
    return;
  }

  const annotated = new Set();
  for (const turn of dialogue.turns) {
    if (!turn.speaker) errors.push(`${label}: a turn is missing its speaker`);
    if (!Array.isArray(turn.segments) || turn.segments.length === 0) {
      errors.push(`${label} ${turn.id ?? '?'}: segments must be a non-empty array`);
      continue;
    }
    for (const segment of turn.segments) {
      if (typeof segment.value !== 'string' || segment.value.trim() === '') {
        errors.push(`${label} ${turn.id}: segment value must be non-empty`);
      }
      if (segment.type === 'text') continue;
      if (segment.type !== 'term') {
        errors.push(`${label} ${turn.id}: unknown segment type "${segment.type}"`);
        continue;
      }
      if (!glossaryIndex.has(String(segment.term).toLowerCase())) {
        errors.push(`${label} ${turn.id}: annotated term "${segment.term}" is not in the glossary`);
      }
      annotated.add(String(segment.term).toLowerCase());
    }
  }

  for (const entry of dialogue.term_map ?? []) {
    if (!entry.term) {
      errors.push(`${label}: term_map entry is missing term`);
      continue;
    }
    if (!glossaryIndex.has(entry.term.toLowerCase())) {
      errors.push(`${label}: term_map term "${entry.term}" is not in the glossary`);
    }
    if (!entry.contextual_definition) {
      errors.push(`${label}: term_map entry "${entry.term}" is missing contextual_definition`);
    }
    if (!annotated.has(entry.term.toLowerCase())) {
      errors.push(`${label}: term_map entry "${entry.term}" is never annotated in the dialogue`);
    }
  }
}

/** Throws on any malformed guide, dialogue or dangling term anchor. */
export function validateGuides() {
  const errors = [];
  for (const guide of subjectGuides) validateGuide(guide, errors);
  for (const dialogue of classroomDialogues) validateDialogue(dialogue, errors);

  const ids = new Set();
  for (const guide of subjectGuides) {
    if (ids.has(guide.id)) errors.push(`duplicate guide id "${guide.id}"`);
    ids.add(guide.id);
  }

  if (errors.length) {
    throw new Error(`Subject guide validation failed:\n  - ${errors.join('\n  - ')}`);
  }
  return { guides: subjectGuides.length, dialogues: classroomDialogues.length };
}

/** Guide index for the selector dropdown. */
export function guideSummaries() {
  return subjectGuides.map((g) => ({
    id: g.id,
    name: g.name,
    abbreviation: g.abbreviation,
    pathway: g.pathway,
    levels: g.levels,
    criteria_count: g.criteria.length,
    pathway_count: g.pathways?.length ?? 0,
  }));
}

export function findGuide(id) {
  const key = String(id ?? '').toLowerCase();
  return subjectGuides.find((g) => g.id === key || g.abbreviation.toLowerCase() === key) ?? null;
}

export function findDialogue(id) {
  const key = String(id ?? '').toLowerCase();
  return classroomDialogues.find((d) => d.id === key) ?? null;
}

export { BAND_KEYS, CRITERION_IDS };

export default subjectGuides;
