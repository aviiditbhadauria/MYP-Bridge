/**
 * MYP Command Term glossary (criteria A to F).
 *
 * Command terms are the verbs that carry the assessed cognitive demand. A
 * response written to the wrong command term is assessed against the wrong
 * descriptor, so each entry states the demand the verb places on a student.
 */
export default [
  {
    term: 'State',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'Give a brief explicit answer, offering a specified fact or a single step in a process.',
    myp_context_example:
      'In Criterion A for Sciences, a student states that the pH of the solution is 4, which is assessed at the lowest band because no mechanism is supplied.',
    related_terms: ['Identify', 'Outline', 'Describe'],
  },
  {
    term: 'Define',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'Give the precise formal meaning of a term, identifying the essential qualities that distinguish it from related terms.',
    myp_context_example:
      'In Language & Literature, a student defines an unreliable narrator as one whose account cannot be taken at face value, naming the feature rather than describing an effect.',
    related_terms: ['Give a definition', 'Describe', 'Distinguish'],
  },
  {
    term: 'Give a definition',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'State the accepted formal meaning of a term, typically in definitional form, without necessarily extending to distinguishing it.',
    myp_context_example:
      'In Language Acquisition, a student gives a definition of a receptive skill as one that centres on understanding input rather than producing output.',
    related_terms: ['Define', 'Identify', 'State'],
  },
  {
    term: 'Identify',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'Recognise and name a feature, factor, variable or relationship within a given context.',
    myp_context_example:
      'In Mathematics, a student identifies the independent variable in an investigation as the temperature of the water being used.',
    related_terms: ['State', 'Name', 'Recognise'],
  },
  {
    term: 'Describe',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'Give an account of the features, characteristics or sequence of something in a clear and specific manner.',
    myp_context_example:
      'In Sciences, a student describes what happens to particles as a solid melts: they gain kinetic energy, overcome the forces holding them in fixed positions, and move past one another while staying in close contact.',
    related_terms: ['State', 'Outline', 'Explain'],
  },
  {
    term: 'Explain',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'Give a reasoned account of a cause, effect, process or relationship, addressing why or how something occurs.',
    myp_context_example:
      'In Criterion A for Sciences, explaining why a metal conducts electricity requires naming delocalised electrons as the mobile charge carriers rather than describing the metal.',
    related_terms: ['Describe', 'Outline', 'Analyse'],
  },
  {
    term: 'Outline',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'Give a brief account of the main points or the sequence of steps in a process, without full development.',
    myp_context_example:
      'In Individuals & Societies, outlining the stages of cause-and-effect analysis means distinguishing long-term from short-term causes, not writing the full analysis.',
    related_terms: ['Describe', 'Summarize', 'State'],
  },
  {
    term: 'Give an example',
    subject_group: 'All Subjects',
    criterion_association: 'A',
    category: 'Command Term',
    formal_definition:
      'Provide one concrete instance that demonstrates that the general statement or concept holds.',
    myp_context_example:
      'In Individuals & Societies, giving a physical barrier to trade as a mountain range forcing a costly detour distinguishes the concept from an economic or monetary barrier.',
    related_terms: ['Identify', 'Illustrate', 'Define'],
  },
  {
    term: 'Analyse',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Break a whole into component parts and examine how they relate to each other and contribute to the whole.',
    myp_context_example:
      'In Sciences, analysing why a catalyst increases reaction rate requires separating collision frequency from activation energy and showing that only the latter changes.',
    related_terms: ['Compare', 'Examine', 'Evaluate'],
  },
  {
    term: 'Compare',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Identify and state both similarities and differences between two or more items, addressing both directions of the comparison.',
    myp_context_example:
      'In Language Acquisition, comparing reading and conversation requires noting that reading supplies controlled model input while conversation imposes real-time retrieval and interactional adjustment.',
    related_terms: ['Contrast', 'Analyse', 'Examine'],
  },
  {
    term: 'Contrast',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Identify and state significant differences between items, without requiring similarities to be addressed.',
    myp_context_example:
      'In Mathematics, contrasting the effect of doubling the radius of a circle shows circumference doubling while area quadruples.',
    related_terms: ['Compare', 'Differentiate'],
  },
  {
    term: 'Construct',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Build or devise an example, argument, explanation or model from given components, applying knowledge to a new situation.',
    myp_context_example:
      'In Mathematics, constructing the formula for a taxi fare requires assembling three additive parts, with distance multiplied only by the per-unit rate.',
    related_terms: ['Develop', 'Design', 'Formulate'],
  },
  {
    term: 'Design',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Devise a plan, method or procedure to achieve a stated purpose within recognised constraints.',
    myp_context_example:
      'In Language Acquisition, designing a method for recording spontaneous verb accuracy requires an unscripted task, a transcription and an accuracy tally with error context.',
    related_terms: ['Plan', 'Develop', 'Construct'],
  },
  {
    term: 'Develop',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Expand, elaborate or refine a plan, method or idea so that it becomes more detailed, effective or complete.',
    myp_context_example:
      'In Individuals & Societies, developing an inquiry into retail development must add a comparison group and a stated evidential threshold beyond the initial question.',
    related_terms: ['Design', 'Extend', 'Refine'],
  },
  {
    term: 'Examine',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Investigate a subject or problem by considering its various aspects, features or parts in order to expose its nature or condition.',
    myp_context_example:
      'In Sciences, examining whether extra fertiliser always raises yield requires accounting for diminishing returns once another factor becomes limiting.',
    related_terms: ['Analyse', 'Investigate', 'Assess'],
  },
  {
    term: 'Formulate an inquiry question',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Develop a precise, testable and open research question that can be answered with evidence rather than opinion.',
    myp_context_example:
      'In Language & Literature, a formulated inquiry question names the text, the technique area and the intended analysis, such as which lexical and grammatical choices construct a character as threatening and how they position the reader.',
    related_terms: ['Formulate', 'Develop', 'Pose'],
  },
  {
    term: 'Identify and justify',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Recognise and name a relevant factor or variable, then supply a reason grounded in evidence for including or excluding it.',
    myp_context_example:
      'In Sciences, identifying noise level as a variable to prioritise is justified by its independent controllability, measurability and a plausible effect on concentration.',
    related_terms: ['Prioritize', 'Justify', 'Identify'],
  },
  {
    term: 'Organize',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Arrange elements into a logical, coherent order suited to purpose and audience, with clear structure and sequence.',
    myp_context_example:
      'In Language Acquisition, organizing a vocabulary plan pairs high-frequency targets with modelled contexts, repeated personal use, delayed testing and revision.',
    related_terms: ['Order', 'Structure', 'Categorize'],
  },
  {
    term: 'Pattern',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Identify a regularity, sequence or recurring relationship in data and extend it to generate a generalisation or rule.',
    myp_context_example:
      'In Mathematics, recognising that 3, 7, 11, 15 has a constant first difference of 4 with initial value 3 yields the rule 4n minus 1.',
    related_terms: ['Generalize', 'Extrapolate', 'Sequence'],
  },
  {
    term: 'Prioritize',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Rank factors or options by importance, effectiveness or likelihood, giving reasons for the order chosen.',
    myp_context_example:
      'In Language Acquisition, prioritising level calibration before unsupported authentic recordings reflects what the current phase of the class can actually follow.',
    related_terms: ['Rank', 'Identify and justify', 'Evaluate'],
  },
  {
    term: 'Solve problem',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Identify a problem, determine what is required, select and apply an appropriate strategy, and check the resulting answer.',
    myp_context_example:
      'In Mathematics, solving 5c + 8(34 - c) = 251 for a ticket problem requires forming the equation, isolating c, and verifying the integer solution.',
    related_terms: ['Calculate', 'Apply', 'Determine'],
  },
  {
    term: 'Display',
    subject_group: 'All Subjects',
    criterion_association: 'B',
    category: 'Command Term',
    formal_definition:
      'Present data or information in a systematic way, such as a table, chart, graph, diagram or model.',
    myp_context_example:
      'In Sciences, displaying results as a table with averages and calculated range makes the reliability of the trends assessable.',
    related_terms: ['Represent', 'Present', 'Tabulate'],
  },
  {
    term: 'Apply',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Use a principle, rule, method or concept to solve a problem or produce a result in a particular context.',
    myp_context_example:
      'In Mathematics, applying proportional reasoning to 5 cups for 12 muffins gives 12.5 cups for 30 muffins only if the ratio is assumed to hold.',
    related_terms: ['Use', 'Calculate', 'Solve problem'],
  },
  {
    term: 'Argue',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Present a case with reasons and evidence, anticipating and addressing opposing viewpoints.',
    myp_context_example:
      'In Language Acquisition, arguing that a course should study first languages requires stating metalinguistic benefit and acknowledging the opportunity cost of finite curriculum time.',
    related_terms: ['Justify', 'Discuss', 'Assess'],
  },
  {
    term: 'Assess',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Consider the strengths and limitations of an argument, method or piece of evidence, weighing them against stated criteria.',
    myp_context_example:
      'In Individuals & Societies, assessing the usefulness of a company-commissioned survey requires checking transparency and methodology against the sponsor\'s commercial interest.',
    related_terms: ['Evaluate', 'Critique', 'Examine'],
  },
  {
    term: 'Comment',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Make an observation or offer a brief, informed opinion on a matter, giving reasons proportionate to the scope of the response.',
    myp_context_example:
      'In Sciences, commenting on the claim that more data always improves a conclusion must separate the reduction of random error from the persistence of systematic error.',
    related_terms: ['Discuss', 'Examine', 'State'],
  },
  {
    term: 'Critique',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Give a reasoned, informed opinion about the strengths and weaknesses of a statement, argument or piece of work.',
    myp_context_example:
      'In Language & Literature, critiquing an analysis that merely names a technique identifies the absence of justification, textual reference and linkage to purpose.',
    related_terms: ['Assess', 'Evaluate', 'Comment'],
  },
  {
    term: 'Discuss',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Consider different aspects of a subject or problem, developing an explanation that addresses several connected points.',
    myp_context_example:
      'In Language Acquisition, discussing subtitles considers their effect on where audience attention is directed, not merely their accuracy.',
    related_terms: ['Consider', 'Examine', 'Comment'],
  },
  {
    term: 'Evaluate',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Make an appraisal by weighing up the strengths and limitations of an option, decision or development against stated criteria.',
    myp_context_example:
      'In Criterion D, students evaluate the implications of a technological solution by addressing political, economic, environmental, social, ethical and moral factors.',
    related_terms: ['Assess', 'Justify', 'Argue'],
  },
  {
    term: 'Expose',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Reveal or identify the limitations, errors, assumptions or weaknesses inherent in a claim, argument or piece of work.',
    myp_context_example:
      'In Language & Literature, exposing a generalisation from one author\'s subject matter to all literature identifies an unwarranted generalisation.',
    related_terms: ['Critique', 'Identify', 'Evaluate'],
  },
  {
    term: 'Justify',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Give a reason or series of reasons that support a claim, conclusion or course of action.',
    myp_context_example:
      'In Mathematics, justifying the median as the preferred measure of house price centre rests on its insensitivity to a single extreme value.',
    related_terms: ['Argue', 'Explain', 'Defend'],
  },
  {
    term: 'Reflect',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Think deeply and deliberately about a concept, experience or process, producing considered personal insight.',
    myp_context_example:
      'In Criterion D, reflecting on why individual environmental action feels negligible identifies a category error between absolute scale and cumulative effect.',
    related_terms: ['Ponder', 'Consider', 'Evaluate'],
  },
  {
    term: 'Summarize',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Condense an account to its essential features, preserving the meaning of the original while reducing detail.',
    myp_context_example:
      'In Mathematics, summarizing what a mean of 20 communicates states that a measure of centre is given but spread, shape and individual values are not.',
    related_terms: ['Condense', 'Outline', 'Abstract'],
  },
  {
    term: 'Compose',
    subject_group: 'All Subjects',
    criterion_association: 'C',
    category: 'Command Term',
    formal_definition:
      'Create a coherent original piece of writing, speech or other output that serves a stated purpose and audience.',
    myp_context_example:
      'In Language & Literature, composing requires a purposeful register suited to the audience, not merely grammatical sentences.',
    related_terms: ['Create', 'Construct', 'Produce'],
  },
  {
    term: 'Calculate',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Determine an exact numerical answer from given data using appropriate methods, showing sufficient working to be checked.',
    myp_context_example:
      'In Mathematics, calculating simple interest on a $2 000 loan at 6 per cent per year for three years gives $360, so the total repaid is $2 360.',
    related_terms: ['Determine', 'Compute', 'Apply'],
  },
  {
    term: 'Demonstrate',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Show clearly by practical application, example or demonstration that a principle, skill or process is understood.',
    myp_context_example:
      'In Sciences, demonstrating the effect of a catalyst is done by measuring rate before and after addition, not by asserting the mechanism.',
    related_terms: ['Show', 'Display', 'Illustrate'],
  },
  {
    term: 'Determine',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Establish the specific value, direction or outcome of something from data or evidence.',
    myp_context_example:
      'In Individuals & Societies, determining which tank holds more water requires computing both volumes rather than comparing external surface area.',
    related_terms: ['Calculate', 'Establish', 'Find'],
  },
  {
    term: 'Experiment',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Carry out a controlled practical procedure designed to answer a question, gathering and recording data systematically.',
    myp_context_example:
      'In Sciences, a controlled experiment varies one independent variable while holding all others constant so the effect can be attributed.',
    related_terms: ['Investigate', 'Conduct', 'Measure'],
  },
  {
    term: 'Investigate',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Conduct a systematic enquiry into a phenomenon or problem, gathering evidence and reaching a supported conclusion.',
    myp_context_example:
      'In Individuals & Societies, investigating whether a wind farm will be approved requires examining the environmental dimension because it is directly and irreversibly altered.',
    related_terms: ['Examine', 'Research', 'Explore'],
  },
  {
    term: 'Predict',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'State an expected outcome based on prior knowledge, theory or observed trends, before further evidence is available.',
    myp_context_example:
      'In Sciences, predicting that doubling reactant concentration increases rate is justified by collision theory rather than asserted.',
    related_terms: ['Forecast', 'Anticipate', 'Project'],
  },
  {
    term: 'Research',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Gather and analyse information from a range of sources in order to answer a question or inform a decision.',
    myp_context_example:
      'In Sciences, researching a yield claim requires controlled replicated trials across sites and seasons with a no-fertiliser control.',
    related_terms: ['Investigate', 'Gather', 'Source'],
  },
  {
    term: 'Use information',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Select and deploy relevant data, evidence, maps, statistics or sources accurately to support a purpose.',
    myp_context_example:
      'In Individuals & Societies, using information correctly means selecting description, date and amount together on a bank statement, since none of the three establishes recurrence alone.',
    related_terms: ['Apply', 'Select', 'Interpret'],
  },
  {
    term: 'Manage',
    subject_group: 'All Subjects',
    criterion_association: 'D',
    category: 'Command Term',
    formal_definition:
      'Organise resources, people or processes to achieve an objective efficiently and within stated constraints.',
    myp_context_example:
      'In Individuals & Societies, managing a transition means allocating investment between transport modes while tracking distributional effects.',
    related_terms: ['Organize', 'Administer', 'Coordinate'],
  },
  {
    term: 'Choose',
    subject_group: 'All Subjects',
    criterion_association: 'E',
    category: 'Command Term',
    formal_definition:
      'Select from a range of alternatives, stating the criterion applied and why the selected option is the most suitable.',
    myp_context_example:
      'In Mathematics, choosing between factorisation and the quadratic formula is a decision about efficiency versus transparency of structure.',
    related_terms: ['Select', 'Decide', 'Prioritize'],
  },
  {
    term: 'Emphasize',
    subject_group: 'All Subjects',
    criterion_association: 'E',
    category: 'Command Term',
    formal_definition:
      'Give particular importance to a feature, factor or aspect of a phenomenon or argument.',
    myp_context_example:
      'In Sciences, emphasizing collision frequency in an explanation of reaction rate signals the specific mechanism the response depends on.',
    related_terms: ['Highlight', 'Stress', 'Focus'],
  },
  {
    term: 'Recommend',
    subject_group: 'All Subjects',
    criterion_association: 'E',
    category: 'Command Term',
    formal_definition:
      'Put forward a preferred course of action or solution, supported by justification.',
    myp_context_example:
      'In Individuals & Societies, recommending a landfill site requires outlining genuine consultation, monitoring and independent assessment before approval.',
    related_terms: ['Advise', 'Suggest', 'Propose'],
  },
  {
    term: 'Suggest',
    subject_group: 'All Subjects',
    criterion_association: 'E',
    category: 'Command Term',
    formal_definition:
      'Propose a course of action or interpretation that could be explored, without requiring full justification.',
    myp_context_example:
      'In Language Acquisition, suggesting that gist listening precedes detail listening proposes a sequence that can then be investigated.',
    related_terms: ['Propose', 'Offer', 'Recommend'],
  },
  {
    term: 'Show',
    subject_group: 'All Subjects',
    criterion_association: 'E',
    category: 'Command Term',
    formal_definition:
      'Give evidence or provide a worked result that demonstrates the truth of a statement or the operation of a principle.',
    myp_context_example:
      'In Mathematics, showing the growth-factor reasoning in a population question demonstrates the calculation rather than only reporting the number.',
    related_terms: ['Demonstrate', 'Evidence', 'Prove'],
  },
  {
    term: 'Value',
    subject_group: 'All Subjects',
    criterion_association: 'F',
    category: 'Command Term',
    formal_definition:
      'Estimate the worth or significance of something quantitatively or qualitatively in relation to a stated standard.',
    myp_context_example:
      'In Language Acquisition, valuing a dialect recognises the place-specific knowledge it encodes, which a purely functional measure of communicative efficiency would not capture.',
    related_terms: ['Assess', 'Estimate', 'Judge'],
  },
  {
    term: 'Appreciate',
    subject_group: 'All Subjects',
    criterion_association: 'F',
    category: 'Command Term',
    formal_definition:
      'Recognise the significance, value or quality of something with informed sensitivity.',
    myp_context_example:
      'In Language Acquisition, appreciating code-switching as a marker of solidarity reframes a behaviour often treated as a deficit.',
    related_terms: ['Recognise', 'Value', 'Respect'],
  },
  {
    term: 'Explore',
    subject_group: 'All Subjects',
    criterion_association: 'E',
    category: 'Command Term',
    formal_definition:
      'Investigate a situation or issue in order to understand it better, without requiring a final resolution.',
    myp_context_example:
      'In Individuals & Societies, exploring why a region\'s manufacturing declined generates candidate explanations before evidence is gathered.',
    related_terms: ['Investigate', 'Examine', 'Research'],
  },
  {
    term: 'Discover',
    subject_group: 'All Subjects',
    criterion_association: 'F',
    category: 'Command Term',
    formal_definition:
      'Find or identify something that was previously unknown or unrecognised within a given context.',
    myp_context_example:
      'In Language Acquisition, discovering a predictable pattern of cognate error reveals that form similarity is driving meaning transfer.',
    related_terms: ['Identify', 'Find', 'Establish'],
  },
  {
    term: 'Solve',
    subject_group: 'All Subjects',
    criterion_association: 'F',
    category: 'Command Term',
    formal_definition:
      'Find an answer to a problem or a way to overcome a difficulty, by applying appropriate knowledge and methods.',
    myp_context_example:
      'In Mathematics, solving for the number of children sold requires setting simultaneous conditions on the two ticket prices and the total taken.',
    related_terms: ['Solve problem', 'Determine', 'Calculate'],
  },
];
