/**
 * Subject-specific glossary, part 1: Mathematics and Sciences.
 *
 * These are the discipline terms students meet in MYP Mathematics Standard and
 * Extended, and in the Sciences (Biology, Chemistry, Physics) course families.
 * Command terms and framework terms live in terms-commands.js and
 * terms-framework.js respectively.
 */
export default [
  {
    term: 'Exact value',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'The precise numerical value of a quantity expressed exactly, with no rounding or approximation.',
    myp_context_example:
      'A student converts the repeating decimal 0.333... to the exact fraction 1/3 without rounding to 0.33.',
    related_terms: ['Approximation', 'Rounding', 'Irrational number'],
  },
  {
    term: 'Approximation',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'A numerical value close to the exact value, used when an exact form is impractical or when measurement limits demand it.',
    myp_context_example:
      'When estimating the cost of fuel for a 420 km journey, a student rounds the unit price to the nearest cent and states the precision of the result.',
    related_terms: ['Exact value', 'Rounding', 'Error interval', 'Significant figures'],
  },
  {
    term: 'Rounding',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Skill',
    formal_definition:
      'Approximating a number to a given number of decimal places or significant figures by examining the next digit.',
    myp_context_example:
      'Rounding 16.85 to one decimal place gives 16.9 because the hundredths digit is 5 or greater.',
    related_terms: ['Approximation', 'Significant figures'],
  },
  {
    term: 'Significant figures',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Skill',
    formal_definition:
      'The number of meaningful digits in a measured quantity, determined by the precision of the measuring instrument rather than by the decimal point.',
    myp_context_example:
      'A mass recorded as 0.00450 g carries three significant figures because the trailing zero after the decimal point is meaningful.',
    related_terms: ['Rounding', 'Accuracy', 'Precision'],
  },
  {
    term: 'Error interval',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'The range of values within which a measured quantity may lie, bounded by the limits of precision of the measurement.',
    myp_context_example:
      'A side measured as 12.4 cm to the nearest 0.1 cm gives an error interval of 12.35 cm to 12.45 cm.',
    related_terms: ['Bounds of accuracy', 'Upper bound', 'Lower bound'],
  },
  {
    term: 'Bounds of accuracy',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'The upper and lower limits within which a rounded measurement certainly falls.',
    myp_context_example:
      'Stating bounds of accuracy for a mean allows a student to judge whether a difference between two data sets is meaningful.',
    related_terms: ['Error interval', 'Rounding'],
  },
  {
    term: 'Percentage error',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Skill',
    formal_definition:
      'The size of an error expressed as a proportion of the true value, multiplied by one hundred to give a percentage.',
    myp_context_example:
      'A student computes percentage error when an experimental density differs from the accepted value, showing that 2 per cent deviation is acceptable for the method used.',
    related_terms: ['Absolute error', 'Relative error', 'Accuracy'],
  },
  {
    term: 'Direct proportion',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'A relationship in which one variable changes by the same constant factor as another, represented by y = kx through the origin.',
    myp_context_example:
      'In a model of the cost of a taxi fare, the base charge is a fixed cost and the per-kilometre rate is the variable cost, so the relationship is not directly proportional.',
    related_terms: ['Inverse proportion', 'Gradient', 'Constant of proportionality'],
  },
  {
    term: 'Inverse proportion',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'A relationship in which the product of two variables is constant, represented by y = k/x.',
    myp_context_example:
      'Modelling the time taken to complete a fixed workload against the number of workers demonstrates that doubling the workers halves the time.',
    related_terms: ['Direct proportion', 'Variation'],
  },
  {
    term: 'Gradient',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Skill',
    formal_definition:
      'The rate of change of a linear relationship, equal to the change in y divided by the change in x over a chosen interval.',
    myp_context_example:
      'A student calculates the gradient of a cost-distance graph to find the unit rate charged per kilometre.',
    related_terms: ['Slope', 'Rate of change', 'Direct proportion'],
  },
  {
    term: 'Rate of change',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'The measure of how one quantity changes per unit change in another quantity, used to describe both linear and non-linear relationships.',
    myp_context_example:
      'Comparing the rate of change of a population graph in two regions supports a reasoned conclusion about differing growth conditions.',
    related_terms: ['Gradient', 'Derivative', 'Function'],
  },
  {
    term: 'Function',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'A rule that assigns exactly one output to each permitted input, so that the same input always produces the same output.',
    myp_context_example:
      'In modelling a savings plan, a student treats the account balance as the dependent variable and the number of months as the independent variable, giving a function of time.',
    related_terms: ['Independent variable', 'Dependent variable', 'Domain', 'Range'],
  },
  {
    term: 'Domain',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'The complete set of permitted inputs for which a function is defined.',
    myp_context_example:
      'When a square-root function is applied to a measurement, the domain is restricted to inputs that are not negative, and a student must justify that restriction.',
    related_terms: ['Range', 'Function', 'Constraint'],
  },
  {
    term: 'Range',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'The complete set of outputs a function can produce from its permitted inputs.',
    myp_context_example:
      'A student states the range of a probability function to check that no modelled outcome is impossible or counted twice.',
    related_terms: ['Domain', 'Function'],
  },
  {
    term: 'Constraint',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'A restriction placed on the variables of a problem that limits the feasible solutions.',
    myp_context_example:
      'Allocating a fixed budget between two saves is a linear program in which the budget is the binding constraint.',
    related_terms: ['Domain', 'Linear program', 'Optimisation'],
  },
  {
    term: 'Linear program',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'A method for finding the maximum or minimum of a linear expression subject to a set of linear constraints, usually plotted as feasible regions.',
    myp_context_example:
      'A school plans a concert with limited hall capacity and a fixed budget; the seating arrangement that maximises income is found at a vertex of the feasible region.',
    related_terms: ['Constraint', 'Feasible region', 'Optimisation', 'Vertex'],
  },
  {
    term: 'Feasible region',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Concept',
    formal_definition:
      'The set of all points that satisfy every constraint of a linear program simultaneously.',
    myp_context_example:
      'Shading the overlap of the constraint inequalities produces the feasible region within which any solution must lie.',
    related_terms: ['Linear program', 'Constraint', 'Inequality'],
  },
  {
    term: 'Optimisation',
    subject_group: 'Mathematics',
    criterion_association: 'C',
    category: 'Mathematics Skill',
    formal_definition:
      'The process of finding the values of variables that maximise or minimise an objective function under given constraints.',
    myp_context_example:
      'A logistics team optimises delivery routes to minimise total distance while meeting every delivery window.',
    related_terms: ['Linear program', 'Constraint', 'Objective function'],
  },
  {
    term: 'Algebraic manipulation',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Skill',
    formal_definition:
      'Rearranging and simplifying algebraic expressions and equations while preserving equivalence at every step.',
    myp_context_example:
      'A student solves a simultaneous pair by elimination, showing each rearrangement so that the reasoning can be followed.',
    related_terms: ['Equation', 'Rearranging', 'Factorisation'],
  },
  {
    term: 'Simultaneous equations',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'A set of equations in the same unknowns that must all be satisfied by the same solution.',
    myp_context_example:
      'Two unknown costs in a catering order are found by forming simultaneous equations from the totals for two different menus.',
    related_terms: ['Equation', 'Substitution', 'Elimination'],
  },
  {
    term: 'Quadratic expression',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'An expression of the form ax squared plus bx plus c, whose graph is a parabola.',
    myp_context_example:
      'The path of a thrown ball is modelled by a quadratic expression, and the student determines the maximum height from the turning point.',
    related_terms: ['Factorisation', 'Parabola', 'Discriminant', 'Completing the square'],
  },
  {
    term: 'Discriminant',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'The quantity b squared minus four ac in a quadratic equation, which determines whether and how many real roots exist.',
    myp_context_example:
      'A student evaluates the discriminant to show that a proposed model of a flight path has no real solution and must be revised.',
    related_terms: ['Quadratic expression', 'Roots', 'Discriminant'],
  },
  {
    term: 'Completing the square',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Skill',
    formal_definition:
      'Rewriting a quadratic expression in the form of a bracket squared plus or minus a constant, revealing the turning point.',
    myp_context_example:
      'The maximum of a revenue quadratic is found by completing the square rather than by differentiating, which is appropriate at Standard level.',
    related_terms: ['Quadratic expression', 'Turning point'],
  },
  {
    term: 'Similarity',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'A transformation that changes the size of a figure by a scale factor while preserving its shape and angles.',
    myp_context_example:
      'A model aircraft is built at 1:50 scale, and the student uses similarity to calculate the real wing length.',
    related_terms: ['Transformation', 'Scale factor', 'Congruence'],
  },
  {
    term: 'Congruence',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'The condition that two figures have identical corresponding angles and side lengths, so they are indistinguishable in size, shape and orientation.',
    myp_context_example:
      'Checking congruence by comparing each corresponding side and angle confirms that two tiles fit the same gap.',
    related_terms: ['Similarity', 'Transformation', 'Correspondence'],
  },
  {
    term: 'Trigonometric ratio',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'The ratio of two sides of a right-angled triangle, named according to the side opposite the angle of interest.',
    myp_context_example:
      'The height of a lighthouse above sea level is found using the sine ratio once the angle of elevation and the horizontal distance are known.',
    related_terms: ['Sine', 'Cosine', 'Tangent', 'Pythagoras'],
  },
  {
    term: 'Pythagoras',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'The theorem stating that in a right-angled triangle the square of the hypotenuse equals the sum of the squares of the other two sides.',
    myp_context_example:
      'A student applies Pythagoras to find the length of a ladder that must reach a window of known height at a known distance from the wall.',
    related_terms: ['Trigonometric ratio', 'Right-angled triangle', 'Hypotenuse'],
  },
  {
    term: 'Similar triangles',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'Triangles whose corresponding angles are equal and whose corresponding sides are proportional, so corresponding lengths can be calculated.',
    myp_context_example:
      'The height of an object can be determined from the length of its shadow if a student holds a metre rule upright and compares shadows at the same moment.',
    related_terms: ['Similarity', 'Scale factor', 'Corresponding angles'],
  },
  {
    term: 'Standard form',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'A number written as a value between one and ten multiplied by a power of ten, used to express very large or very small quantities compactly.',
    myp_context_example:
      'The national debt of a country is quoted in standard form so that its magnitude is immediately apparent.',
    related_terms: ['Power of ten', 'Order of magnitude', 'Scientific notation'],
  },
  {
    term: 'Set',
    subject_group: 'Mathematics',
    criterion_association: 'D',
    category: 'Mathematics Concept',
    formal_definition:
      'A well-defined collection of distinct objects, called elements, treated as a single mathematical entity.',
    myp_context_example:
      'The set of students who scored above 80 per cent is listed in roster form and then restated using set-builder notation.',
    related_terms: ['Element', 'Subset', 'Venn diagram', 'Set-builder notation'],
  },
  {
    term: 'Union and intersection',
    subject_group: 'Mathematics',
    criterion_association: 'D',
    category: 'Mathematics Skill',
    formal_definition:
      'The union of two sets contains every element of either set; the intersection contains only the elements common to both.',
    myp_context_example:
      'Survey data on whether students take bus or train to school is analysed by finding the union of all travellers and the intersection of the two modes.',
    related_terms: ['Set', 'Venn diagram', 'Complement'],
  },
  {
    term: 'Logical quantifier',
    subject_group: 'Mathematics',
    criterion_association: 'D',
    category: 'Mathematics Concept',
    formal_definition:
      'A word such as for all, there exists or there is a unique that specifies the scope of a statement over a set of values.',
    myp_context_example:
      'A student distinguishes a statement proved for all positive integers from one supported by a single counterexample, which disproves the universal claim.',
    related_terms: ['Proposition', 'Contradiction', 'Counterexample'],
  },
  {
    term: 'Proof',
    subject_group: 'Mathematics',
    criterion_association: 'D',
    category: 'Mathematics Concept',
    formal_definition:
      'A rigorous logical argument that establishes a statement for all cases in its domain, rather than for observed examples alone.',
    myp_context_example:
      'A student supplies a proof that the sum of two even integers is even, using the definition rather than enumerating examples.',
    related_terms: ['Logical quantifier', 'Deductive reasoning', 'Counterexample'],
  },
  {
    term: 'System of equations',
    subject_group: 'Mathematics',
    criterion_association: 'B',
    category: 'Mathematics Concept',
    formal_definition:
      'A set of equations considered together, whose solution must satisfy every equation simultaneously.',
    myp_context_example:
      'A two-stage mixing problem is represented as a system of equations in the masses of each concentrate.',
    related_terms: ['Simultaneous equations', 'Solution', 'Substitution'],
  },
  {
    term: 'Statistics',
    subject_group: 'Mathematics',
    criterion_association: 'F',
    category: 'Mathematics Concept',
    formal_definition:
      'The branch of mathematics concerned with collecting, representing and interpreting data, drawing conclusions about populations from samples.',
    myp_context_example:
      'A class survey of daily screen time is summarised with measures of centre and spread before any conclusion is drawn.',
    related_terms: ['Data', 'Mean', 'Median', 'Mode', 'Interquartile range'],
  },
  {
    term: 'Mean',
    subject_group: 'Mathematics',
    criterion_association: 'F',
    category: 'Mathematics Concept',
    formal_definition:
      'The arithmetic average of a data set, found by dividing the sum of the values by the number of values.',
    myp_context_example:
      'A student reports the mean and the median of a skewed distribution and explains why the two differ.',
    related_terms: ['Median', 'Mode', 'Statistics', 'Measures of centre'],
  },
  {
    term: 'Standard deviation',
    subject_group: 'Mathematics',
    criterion_association: 'F',
    category: 'Mathematics Concept',
    formal_definition:
      'A measure of the spread of data about the mean, expressed in the same units as the data itself.',
    myp_context_example:
      'Two classes with the same mean but different standard deviations are compared to show which cohort is more consistent in its attainment.',
    related_terms: ['Variance', 'Interquartile range', 'Spread'],
  },
  {
    term: 'Discrete and continuous data',
    subject_group: 'Mathematics',
    criterion_association: 'F',
    category: 'Mathematics Concept',
    formal_definition:
      'Discrete data take countable separate values; continuous data can take any value within a range and are usually shown as a histogram.',
    myp_context_example:
      'The number of goals scored is discrete, whereas the reaction time of a sprinter is continuous and is recorded to an agreed precision.',
    related_terms: ['Histogram', 'Bar chart', 'Data'],
  },
  {
    term: 'Correlation',
    subject_group: 'Mathematics',
    criterion_association: 'F',
    category: 'Mathematics Concept',
    formal_definition:
      'The strength and direction of the linear relationship between two quantitative variables, judged from a scatter diagram.',
    myp_context_example:
      'A scatter diagram of study hours against grade shows a positive correlation, but a student states that correlation does not establish causation.',
    related_terms: ['Scatter diagram', 'Causation', 'Line of best fit'],
  },
  {
    term: 'Estimation',
    subject_group: 'Mathematics',
    criterion_association: 'F',
    category: 'Mathematics Skill',
    formal_definition:
      'Producing a reasonable numerical answer to a problem for which an exact method is unavailable, and judging its accuracy.',
    myp_context_example:
      'A student estimates the number of tiles in a bathroom from the floor area and then checks the estimate against an actual count.',
    related_terms: ['Approximation', 'Error interval', 'Significant figures'],
  },
  {
    term: 'Accuracy and precision',
    subject_group: 'Mathematics',
    criterion_association: 'F',
    category: 'Mathematics Concept',
    formal_definition:
      'Accuracy is closeness to the true value; precision is the closeness of repeated measurements to one another, regardless of the true value.',
    myp_context_example:
      'Repeated measurements clustered far from the accepted value are precise but inaccurate, and the remedy differs in each case.',
    related_terms: ['Error interval', 'Rounding', 'Significant figures'],
  },
  {
    term: 'Cell',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The basic structural and functional unit of all living organisms, containing cytoplasm and enclosed by a membrane.',
    myp_context_example:
      'Comparing a plant cell and an animal cell identifies the cell wall, chloroplast and large permanent vacuole as plant-specific structures.',
    related_terms: ['Organelle', 'Tissue', 'Organ system', 'Eukaryotic cell'],
  },
  {
    term: 'Organelle',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'A specialised structure within a cell that performs a particular function, such as a mitochondrion or a ribosome.',
    myp_context_example:
      'A student links the large mitochondria of a muscle cell to the increased energy demand of continuous contraction.',
    related_terms: ['Cell', 'Tissue', 'Specialisation'],
  },
  {
    term: 'Tissue',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'A group of similar cells and their extracellular material working together to perform a specific function.',
    myp_context_example:
      'Xylem tissue is identified as the tissue that transports water and dissolved mineral ions upward through a plant.',
    related_terms: ['Cell', 'Organ', 'Organ system', 'Organelle'],
  },
  {
    term: 'Organ system',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'A group of tissues working together to perform a coordinated function within an organism.',
    myp_context_example:
      'The digestive system coordinates ingestion, digestion, absorption and egestion through several organs working in sequence.',
    related_terms: ['Organ', 'Tissue', 'Homeostasis'],
  },
  {
    term: 'Photosynthesis',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The process by which plants and algae convert light energy into stored chemical energy, producing glucose and oxygen from carbon dioxide and water.',
    myp_context_example:
      'Aquatic plants are placed at different depths in a pond to test how the rate of photosynthesis responds to light intensity.',
    related_terms: ['Chlorophyll', 'Limiting factor', 'Respiration', 'Carbon dioxide'],
  },
  {
    term: 'Cell respiration',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The controlled release of energy from glucose in the presence of oxygen to form ATP, producing carbon dioxide and water.',
    myp_context_example:
      'The respiration rate of germinating seeds is compared with that of dormant seeds to show the effect of temperature on metabolic activity.',
    related_terms: ['ATP', 'Photosynthesis', 'Enzyme', 'Diffusion'],
  },
  {
    term: 'Enzyme',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'A biological catalyst, usually a protein, that increases the rate of a reaction by lowering its activation energy without being consumed.',
    myp_context_example:
      'The effect of temperature on catalase activity is investigated by measuring the rate of oxygen production.',
    related_terms: ['Activation energy', 'Active site', 'Substrate', 'Catalyst'],
  },
  {
    term: 'Activation energy',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The minimum energy required for reactants to react, which determines the rate of a reaction and is lowered by a catalyst.',
    myp_context_example:
      'A student explains why a reaction proceeds faster when a catalyst is added even though the overall energy change is unchanged.',
    related_terms: ['Enzyme', 'Catalyst', 'Rate of reaction'],
  },
  {
    term: 'Limiting factor',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The factor in short supply that constrains the rate of a process once other factors are no longer limiting it.',
    myp_context_example:
      'At high light intensities the rate of photosynthesis plateaus because carbon dioxide has become the limiting factor.',
    related_terms: ['Rate of reaction', 'Photosynthesis', 'Controlled variable'],
  },
  {
    term: 'Homeostasis',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The maintenance of a stable internal environment by coordinated detection and correction of changes in conditions.',
    myp_context_example:
      'Body temperature is regulated by negative feedback, with sweating and shivering opposing any deviation from the set point.',
    related_terms: ['Negative feedback', 'Set point', 'Organ system', 'Homeostasis'],
  },
  {
    term: 'Negative feedback',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'A regulatory mechanism in which a change in a condition triggers a response that opposes the original change.',
    myp_context_example:
      'When blood glucose rises, insulin release lowers it; when it falls, glucagon release raises it, and both act by negative feedback.',
    related_terms: ['Homeostasis', 'Set point'],
  },
  {
    term: 'Diffusion',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The net passive movement of particles from a region of higher concentration to a region of lower concentration.',
    myp_context_example:
      'Oxygen moves from the alveolar surface into the blood by diffusion, maintaining a steep concentration gradient.',
    related_terms: ['Osmosis', 'Concentration gradient', 'Semipermeable membrane', 'Active transport'],
  },
  {
    term: 'Osmosis',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The diffusion of water molecules through a partially permeable membrane from a region of lower water potential to higher water potential.',
    myp_context_example:
      'Vegetables placed in strongly salted solution lose water by osmosis, losing mass and becoming limp.',
    related_terms: ['Diffusion', 'Semipermeable membrane', 'Water potential'],
  },
  {
    term: 'Active transport',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The movement of substances across a membrane against the concentration gradient, requiring energy released from ATP.',
    myp_context_example:
      'Root hair cells actively transport nitrate ions from low concentration in the soil to a higher concentration in the cell sap.',
    related_terms: ['Diffusion', 'ATP', 'Concentration gradient'],
  },
  {
    term: 'Water potential',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'A measure of the tendency of water to move from one place to another, determined by pressure and solute concentration.',
    myp_context_example:
      'Water moves up a plant because the water potential of the leaf sap is lower than that of the root sap.',
    related_terms: ['Osmosis', 'Transpiration', 'Semipermeable membrane'],
  },
  {
    term: 'Transpiration',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The loss of water vapour from the leaves of a plant, mainly through open stomata.',
    myp_context_example:
      'A potted plant is weighed before and after several hours under a clear plastic bag, and the water collected by transpiration is quantified.',
    related_terms: ['Water potential', 'Stoma', 'Osmosis', 'Evaporation'],
  },
  {
    term: 'Stoma',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'A pore on the surface of a leaf, surrounded by guard cells, through which gas exchange and transpiration occur.',
    myp_context_example:
      'Stomata close in dry conditions, reducing water loss but also restricting the carbon dioxide supply for photosynthesis.',
    related_terms: ['Transpiration', 'Guard cell', 'Photosynthesis'],
  },
  {
    term: 'Chlorophyll',
    subject_group: 'Sciences',
    criterion_association: 'D',
    category: 'Sciences Concept',
    formal_definition:
      'The green pigment in chloroplasts that absorbs light energy for photosynthesis, absorbing mainly blue and red wavelengths.',
    myp_context_example:
      'Extracting chlorophyll from leaves and plotting its absorption spectrum explains why green light is reflected rather than absorbed.',
    related_terms: ['Photosynthesis', 'Chloroplast', 'Absorption spectrum'],
  },
  {
    term: 'Genetic inheritance',
    subject_group: 'Sciences',
    criterion_association: 'F',
    category: 'Sciences Concept',
    formal_definition:
      'The transmission of characteristics from parents to offspring through genes carried on chromosomes.',
    myp_context_example:
      'A Punnett square is used to predict the proportion of offspring likely to show a recessive characteristic from two heterozygous parents.',
    related_terms: ['Allele', 'Genotype', 'Phenotype', 'Chromosome'],
  },
  {
    term: 'Evolution',
    subject_group: 'Sciences',
    criterion_association: 'F',
    category: 'Sciences Concept',
    formal_definition:
      'The change in the inherited characteristics of a population over successive generations, driven by natural selection acting on variation.',
    myp_context_example:
      'Antibiotic resistance spreads in a bacterial population because resistant individuals survive and reproduce, passing on the allele.',
    related_terms: ['Natural selection', 'Variation', 'Mutation', 'Speciation'],
  },
  {
    term: 'Natural selection',
    subject_group: 'Sciences',
    criterion_association: 'F',
    category: 'Sciences Concept',
    formal_definition:
      'The mechanism by which individuals with advantageous inherited characteristics survive and reproduce more, increasing the frequency of those alleles.',
    myp_context_example:
      'Finches with thicker beaks survived the drought and reproduced, so beak thickness increased in the population over generations.',
    related_terms: ['Evolution', 'Variation', 'Adaptation'],
  },
  {
    term: 'Biodiversity',
    subject_group: 'Sciences',
    criterion_association: 'F',
    category: 'Sciences Concept',
    formal_definition:
      'The variety of living organisms within a given habitat or across the biosphere, encompassing genetic, species and ecosystem diversity.',
    myp_context_example:
      'Transect data from two habitats are compared to quantify biodiversity rather than counting species alone.',
    related_terms: ['Ecosystem', 'Habitat', 'Conservation'],
  },
  {
    term: 'Classification',
    subject_group: 'Sciences',
    criterion_association: 'F',
    category: 'Sciences Skill',
    formal_definition:
      'The arrangement of organisms into groups according to shared characteristics, using evidence to determine relationships.',
    myp_context_example:
      'A dichotomous key is used to classify an unknown organism from observable features before its name is applied.',
    related_terms: ['Taxonomy', 'Dichotomous key', 'Species'],
  },
  {
    term: 'Matter and particle arrangement',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'The arrangement, motion and type of particles that determine the physical properties and state of a substance.',
    myp_context_example:
      'Diffusion of a gas through air is explained by particles moving in random directions with large spaces between them.',
    related_terms: ['State of matter', 'Particle model', 'Diffusion'],
  },
  {
    term: 'Periodic table',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'An ordered arrangement of the chemical elements by atomic number, revealing trends in properties and grouping elements by shared behaviour.',
    myp_context_example:
      'Predicting that sodium and potassium react similarly requires recognising their shared group on the periodic table.',
    related_terms: ['Element', 'Group', 'Valency', 'Reactivity series'],
  },
  {
    term: 'Valency',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'The combining capacity of an atom, determined by the number of electrons gained, lost or shared in a bond.',
    myp_context_example:
      'Working out that oxygen has a valency of two explains why its formula is O2 and not a single oxygen atom.',
    related_terms: ['Ionic bonding', 'Valency', 'Compound formula'],
  },
  {
    term: 'Ionic bonding',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'The electrostatic attraction between oppositely charged ions formed by the transfer of electrons from a metal to a non-metal.',
    myp_context_example:
      'The giant lattice structure of sodium chloride is used to explain both its high melting point and its brittleness.',
    related_terms: ['Valency', 'Covalent bonding', 'Ionic compound', 'Lattice'],
  },
  {
    term: 'Covalent bonding',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'The bond formed when atoms share one or more pairs of electrons between their outer shells.',
    myp_context_example:
      'Sharing electron pairs is used to explain why molecular substances such as water have relatively low melting points.',
    related_terms: ['Ionic bonding', 'Molecule', 'Valency'],
  },
  {
    term: 'Conservation of mass',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'The principle that mass is neither created nor destroyed in a chemical reaction, so the total mass of the products equals the total mass of the reactants.',
    myp_context_example:
      'The mass of the products exceeding the mass of the reactants in an open flask experiment is explained by oxygen entering from the air.',
    related_terms: ['Chemical reaction', 'Reactant', 'Product'],
  },
  {
    term: 'Energy transfer',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'The movement of energy from one object or system to another by conduction, convection, radiation or by mechanical work.',
    myp_context_example:
      'A metal spoon in hot tea transfers energy by conduction, while the movement of the tea itself transfers energy by convection.',
    related_terms: ['Conduction', 'Convection', 'Radiation', 'Conservation of energy'],
  },
  {
    term: 'Waves',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'A transfer of energy without a net transfer of matter, described by amplitude, wavelength, frequency and speed.',
    myp_context_example:
      'Comparing the ripple patterns for water, sound and light waves highlights that all transfer energy while matter stays in place.',
    related_terms: ['Amplitude', 'Wavelength', 'Frequency', 'Wave speed'],
  },
  {
    term: 'Forces and motion',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'A force is a push or pull that changes the motion or shape of an object, measured in newtons.',
    myp_context_example:
      'A remote-controlled car accelerates, travels at constant speed and then brakes, and the student identifies the net force in each phase.',
    related_terms: ['Resultant force', 'Equilibrium', 'Speed', 'Acceleration'],
  },
  {
    term: 'Energy conservation',
    subject_group: 'Sciences',
    criterion_association: 'C',
    category: 'Sciences Concept',
    formal_definition:
      'The principle that energy is transferred or transformed but never destroyed, so the total energy before and after a process is equal.',
    myp_context_example:
      'A student traces energy through a falling ball, accounting for the transfer from gravitational potential to kinetic and then to thermal energy and sound.',
    related_terms: ['Energy transfer', 'Kinetic energy', 'Potential energy', 'Dissipation'],
  },
  {
    term: 'Scientific method',
    subject_group: 'Sciences',
    criterion_association: 'A',
    category: 'Sciences Skill',
    formal_definition:
      'A systematic procedure for investigating a question, involving a hypothesis, variables, controlled fair testing, data collection and evaluation.',
    myp_context_example:
      'A student changes one variable while holding the others constant so that any change in the dependent variable can be attributed to that variable alone.',
    related_terms: ['Hypothesis', 'Variable', 'Controlled variable', 'Evaluation'],
  },
  {
    term: 'Variable',
    subject_group: 'Sciences',
    criterion_association: 'A',
    category: 'Sciences Concept',
    formal_definition:
      'A measurable quantity that may change during an investigation: the independent variable is changed, the dependent variable is measured, and controlled variables are kept constant.',
    myp_context_example:
      'When testing the effect of light intensity on photosynthesis, light intensity is the independent variable and the rate of oxygen production is the dependent variable.',
    related_terms: ['Scientific method', 'Controlled variable', 'Hypothesis'],
  },
  {
    term: 'Hypothesis',
    subject_group: 'Sciences',
    criterion_association: 'A',
    category: 'Sciences Concept',
    formal_definition:
      'A testable, falsifiable prediction about the relationship between variables, which investigation either supports or refutes.',
    myp_context_example:
      'A hypothesis stated as a definite claim can be disproved by a single contradicting result, unlike a vague prediction.',
    related_terms: ['Scientific method', 'Variable', 'Evidence'],
  },
  {
    term: 'Paradox',
    subject_group: 'Sciences',
    criterion_association: 'A',
    category: 'Sciences Concept',
    formal_definition:
      'A statement that appears self-contradictory but which may contain a deeper truth once the conditions and definitions are examined.',
    myp_context_example:
      'A student examines the apparent paradox that a hot metal rod feels colder than a plastic one at the same temperature, resolving it by considering thermal conductivity.',
    related_terms: ['Evidence', 'Reasoning', 'Assumption'],
  },
  {
    term: 'Theory',
    subject_group: 'Sciences',
    criterion_association: 'E',
    category: 'Sciences Concept',
    formal_definition:
      'A well-substantiated explanation of a natural phenomenon, supported by extensive repeated evidence and capable of refinement, not merely a guess.',
    myp_context_example:
      'A student argues that the distinction between a scientific theory and an everyday guess concerns the evidence base rather than the certainty of the explanation.',
    related_terms: ['Evidence', 'Law', 'Scientific method'],
  },
  {
    term: 'Law',
    subject_group: 'Sciences',
    criterion_association: 'E',
    category: 'Sciences Concept',
    formal_definition:
      'A concise statement of a consistently observed pattern or relationship in nature, which describes what happens rather than explaining why.',
    myp_context_example:
      'Newton laws are used to predict the motion of objects, while the underlying theory explains the mechanism behind that motion.',
    related_terms: ['Theory', 'Evidence', 'Scientific method'],
  },
];
