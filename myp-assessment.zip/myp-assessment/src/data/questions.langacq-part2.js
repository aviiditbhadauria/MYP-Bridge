import { q, withIds } from './question-builder.js';

const SUBJECT = 'Language Acquisition';

const items = [
  // ---------------- Criterion C: Communicating and thinking critically (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 1,
    command: 'Analyse',
    text: 'Analyse the likely effect on meaning of using a formal register when addressing a close friend.',
    options: [
      'The register mismatch creates interpersonal distance that may be read as formality, respect or unfriendliness depending on the relationship and the context.',
      'The register mismatch has no effect on meaning.',
      'The register mismatch always communicates respect.',
      'The register mismatch changes only the length of the message.',
    ],
    correct: 0,
    rationale:
      'Register choices are interpreted against social expectations, so meaning is context-dependent rather than fixed. Option 1 asserts a single invariant reading, and option 2 misattributes a social effect to a formal property.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Apply',
    text: 'Apply the concept of a false friend to the assumption that a target-language word has the same meaning as its first-language cognate.',
    options: [
      'The cognates share form but differ in meaning, so familiarity with the form produces a systematic error if the assumption is left unchecked.',
      'Cognates always share meaning, so the assumption is correct.',
      'Cognates are always cognates, so the assumption is irrelevant.',
      'The assumption matters only for formal writing.',
    ],
    correct: 0,
    rationale:
      'Form similarity inflates confidence in meaning and produces a predictable pattern of error. Option 1 treats lexical cognacy as guaranteeing semantic identity, and option 2 confines this to a register-specific issue.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Discuss',
    text: 'Discuss why learners should be taught to listen for gist before listening for detail.',
    options: [
      'Gist establishes a mental framework of the text so that detail can be placed within it and gaps repaired, whereas detail-first listening with no framework often yields isolated fragments that cannot be integrated.',
      'Gist listening is quicker, so it saves time for the test.',
      'Gist listening is unnecessary, because detail listening provides the same information.',
      'Gist listening is appropriate only for longer recordings.',
    ],
    correct: 0,
    rationale:
      'Top-down processing establishes expectations that then support bottom-up decoding. Option 1 reduces the strategy to a time-saving device, and option 2 claims the two approaches are equivalent in outcome.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Critique',
    text: 'Critique the practice of assessing speaking through a scripted dialogue read aloud.',
    options: [
      'Rehearsed reading measures pronunciation and memorised text rather than interactive competence, so an unscripted exchange is required before any claim about speaking ability can be made.',
      'Scripted reading is valid, because it standardises the assessment for every candidate.',
      'Scripted reading is invalid only because it takes longer to administer.',
      'Scripted reading is valid, because interactive ability cannot be assessed.',
    ],
    correct: 0,
    rationale:
      'Reliability gained through scripting is purchased at the cost of construct validity. Option 1 is correct about standardisation but ignores that standardising the wrong thing invalidates the claim being made.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Critique',
    text: 'Critique the advice that learners should avoid using their first language during language lessons.',
    options: [
      'It ignores that strategic use of the first language can clarify complex meaning and sustain participation while productive target-language resources are still developing, so its value depends on purpose rather than on blanket prohibition.',
      'It is sound advice, because the first language always prevents target-language development.',
      'It is sound advice, because learners should only ever use the target language.',
      'It is unsound only because learners enjoy speaking their first language.',
    ],
    correct: 0,
    rationale:
      'Pedagogical decisions about translanguaging depend on instructional purpose. Option 1 asserts a universal harm that is not evidenced, and option 2 mistakes preference for principle.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate the practice of awarding credit only for writing produced entirely in the target language.',
    options: [
      'Strict exclusivity prevents learners from communicating meaning at all while productive resources are insufficient, so the criterion rewards avoidance rather than accuracy and accuracy should be credited within a communicative task.',
      'Target-language-only writing is correct, because accuracy requires exclusive use.',
      'Target-language-only writing is unfair, because written assessment forms no part of the course.',
      'Target-language-only writing has no effect on learning.',
    ],
    correct: 0,
    rationale:
      'An assessment criterion must reward the construct being assessed rather than a proxy for it. Option 1 confuses exclusivity with accuracy, and option 2 removes the construct from assessment altogether.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Argue',
    text: 'Argue whether a language course should require learners to study their own first language alongside the target language, and state one counterargument.',
    options: [
      'Studying the first language raises metalinguistic awareness that supports acquisition, while neglecting it can position the learner\'s own language as deficient; the counterargument is that curriculum time is finite and target exposure should be prioritised.',
      'It should always be required, because bilingualism always improves target-language accuracy.',
      'It should never be required, because a single language focus always produces faster progress.',
      'It should be required only for learners who already speak two languages.',
    ],
    correct: 0,
    rationale:
      'A defensible argument must weigh a genuine pedagogical gain against a real opportunity cost. Options 1 to 3 each assert an absolute outcome that the evidence does not support.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Compare',
    text: 'Compare how a poem and a legal notice use language to achieve their purpose.',
    options: [
      'The poem compresses and repeats to create affective and rhythmic effect, while the notice uses fixed formulae, imperative structures and precise reference in order to eliminate ambiguity.',
      'Both use identical features, because both are short texts.',
      'The poem is more precise than the notice, because poems are short.',
      'The notice is more expressive than the poem, because notices are official.',
    ],
    correct: 0,
    rationale:
      'Purpose determines the linguistic features selected, so genre predicts style strongly. Option 1 reduces style to length, and option 2 assumes a single direction of precision between the two genres.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the reliability of a single online translation as evidence of a word\'s standard meaning.',
    options: [
      'It is weak evidence because a translation reflects one rendered sense and one register, whereas polysemy and usage variation require dictionary or corpus evidence across several contexts.',
      'It is reliable, because online tools draw on large corpora.',
      'It is reliable, because a single occurrence is sufficient.',
      'It is unreliable only because online tools are often unavailable.',
    ],
    correct: 0,
    rationale:
      'One rendering cannot represent the sense range or the register range of a polysemous item. Option 1 confuses corpus size with representative output, and option 2 mistakes availability for evidentiary value.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Critique',
    text: 'Critique the claim that accent should be corrected until learners sound like a native speaker.',
    options: [
      'The claim is defensible only where intelligibility is affected, because accent also signals identity and background; prioritising native-like production risks communicative inhibition and treats one variety as the only legitimate target.',
      'The claim is sound, because a standard accent is always the professional requirement.',
      'The claim is unsound, because pronunciation is never assessed in language courses.',
      'The claim is sound, because every employer requires a native accent.',
    ],
    correct: 0,
    rationale:
      'A critique must distinguish intelligibility from native-likeness, which carry different pedagogical weight. Option 1 assumes a single accent serves every context, and option 2 excludes pronunciation from assessment.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Expose',
    text: 'Expose the flaw in the reasoning: "Learners at Phase 6 make fewer errors than learners at Phase 3, so Phase 6 learners have better pronunciation."',
    options: [
      'The inference conflates a general measure of accuracy with a single sub-skill, since fewer errors overall may reflect a decline in grammar errors rather than any change in pronunciation.',
      'The inference is sound, because accuracy across sub-skills develops together.',
      'The inference is unsound only because Phase 6 is a higher phase.',
      'The inference is sound, because pronunciation is one component of accuracy.',
    ],
    correct: 0,
    rationale:
      'Overall accuracy and pronunciation are distinct measures that develop independently. Option 1 asserts an unwarranted uniformity across sub-skills, and option 2 treats partial inclusion as proof of identity.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the claim that exposure to a language guarantees fluency.',
    options: [
      'The claim is unsupported, because fluency depends on the quantity of interaction, the pressure to communicate, feedback and the learner\'s opportunities for production rather than on exposure alone.',
      'The claim is justified, because exposure is a precondition for fluency.',
      'The claim is justified, because all learners progress at the same rate given equal exposure.',
      'The claim is unjustified only because exposure is always insufficient in duration.',
    ],
    correct: 0,
    rationale:
      'A necessary condition does not guarantee an outcome, since fluency additionally requires interaction and output. Option 1 turns a precondition into a sufficient cause, and option 2 denies well-documented individual variation.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Reflect',
    text: 'Reflect on why marking a learner\'s first-language use as an error can damage their sense of identity and belonging.',
    options: [
      'Because the first language is part of how learners are socially recognised, so implying it is in error separates classroom participation from home identity and discourages risk-taking in the target language.',
      'Because first languages are never grammatically correct.',
      'Because identity has no connection to language.',
      'Because correcting first-language use is legally prohibited in schools.',
    ],
    correct: 0,
    rationale:
      'The risk concerns affiliation and willingness to communicate, not the grammaticality of the first language. Option 1 wrongly attributes structural properties to the learner\'s home language, and option 2 conflates identity with grammar.',
  }),

  // ---------------- Criterion D: Reflecting on language in real-world contexts (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 1,
    command: 'Describe',
    text: 'Describe one reason why a public sign may use very simple and direct wording.',
    options: [
      'Public signage must be understood quickly by passing members of the public who share no background knowledge.',
      'Public signage is always written by people with limited vocabulary.',
      'Simple wording is required because languages cannot express complex ideas.',
      'Simple wording is used because readers always prefer short texts.',
    ],
    correct: 0,
    rationale:
      'Simplification follows from the constraints of context, audience and available time. Option 1 asserts an individual deficit as the cause, and option 2 attributes a general preference that does not hold in other genres.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Explain',
    text: 'Explain why a bilingual speaker may switch languages partway through a conversation with a friend.',
    options: [
      'Because code-switching can convey emphasis, informality or solidarity more efficiently, and functions partly to signal closeness that would be costly to express in a single language.',
      'Because bilingual speakers cannot control which language they use.',
      'Because switching always indicates a lack of fluency in either language.',
      'Because friends should only ever communicate in one language.',
    ],
    correct: 0,
    rationale:
      'Code-switching is a resource for meaning and social signalling rather than a deficit. Option 1 misrepresents it as involuntary, and option 2 confuses purposeful switching with inadequate proficiency.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Evaluate',
    text: 'Evaluate the claim that a language improves by borrowing more words from English.',
    options: [
      'Loanwords can enrich vocabulary and express new concepts efficiently, but heavy borrowing can displace existing local terms and narrow the range of expression available to speakers.',
      'Loanwords always improve a language, because more words means more expression.',
      'Loanwords always damage a language, because existing words are sufficient.',
      'Loanwords have no effect on the language that receives them.',
    ],
    correct: 0,
    rationale:
      'Lexical change involves both gain and substitution, so both must be assessed. Options 1 and 2 each treat an increase in vocabulary as unambiguously beneficial or harmful.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Discuss',
    text: 'Discuss the consequences for a learner of moving from a monolingual school environment into a multilingual one.',
    options: [
      'The learner gains communicative opportunity and audience for the target language but also faces faster spoken input and pressure to adapt to unfamiliar varieties, so support must be recalibrated to the new exposure demands.',
      'The learner benefits without difficulty, because multilingual environments are always easier.',
      'The learner will lose their first language immediately.',
      'The learner is unaffected, because schools use identical methods in every context.',
    ],
    correct: 0,
    rationale:
      'A new context brings both affordances and processing demands, which is the substance of Criterion D reflection. Options 1 and 2 assert extreme positions that ignore the interaction of exposure and support.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate a proposal to require all workplace communication in a multilingual city to use the official language only.',
    options: [
      'The proposal supplies a shared working language but removes one that many employees use comfortably, so it risks excluding contributors whose expertise is not expressed in that language unless interpretation or bilingual channels are provided.',
      'The proposal should be adopted, because one language always prevents misunderstanding.',
      'The proposal should be adopted, because multilingual communication is always slower.',
      'The proposal should be rejected, because languages cannot coexist in one workplace.',
    ],
    correct: 0,
    rationale:
      'A shared language addresses coordination while risking exclusion, so the design must accommodate both. Options 1 and 2 treat language diversity purely as an obstacle rather than as an organisational resource.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Reflect',
    text: 'Reflect on how translated subtitles affect what an audience notices in a film.',
    options: [
      'Audiences attend to text, so the specific wording of subtitles directs attention toward particular dialogue and may divert it from imagery, sound and performance that carry other meanings.',
      'Subtitles have no effect on what audiences notice.',
      'Subtitles change the film only when they are poorly written.',
      'Audiences notice only the visuals, because they ignore all text.',
    ],
    correct: 0,
    rationale:
      'Subtitling shifts attention from the visual and aural track toward verbal content, so it alters what is perceived. Option 1 is wrong because viewers attend to text continuously, and option 2 presents subtitles as inert.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate a proposal to make a regional language compulsory in schools in order to preserve local heritage.',
    options: [
      'Preserving a language is valuable, but compulsion risks marginalising multilingual students and parents, so policy must weigh heritage value against individual access and choice.',
      'Compulsion is justified, because heritage always takes priority over individual preference.',
      'Compulsion is unjustified, because regional languages are no longer spoken in homes.',
      'Compulsion is unjustified only because suitable textbooks are unavailable.',
    ],
    correct: 0,
    rationale:
      'A Criterion D evaluation must weigh the collective goal against effects on individuals. Option 1 subordinates individual access without argument, and option 2 assumes a monolingual reality that varies by region.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the impact on a community of the loss of a local dialect over two generations.',
    options: [
      'A local dialect encodes place-specific knowledge, humour and identity, so its loss removes a distinct voice from cultural representation and weakens the transmission of that knowledge to younger members.',
      'A dialect carries no cultural information, so its loss is purely aesthetic.',
      'The loss is offset, because standard language is always more expressive.',
      'Dialects are preserved automatically in writing, so no loss occurs.',
    ],
    correct: 0,
    rationale:
      'Dialect loss is a loss of culturally specific knowledge and representation rather than merely of variety. Option 1 treats dialect as empty of meaning, and option 2 assumes standard forms are inherently more expressive.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Discuss',
    text: 'Discuss why translation service platforms can reduce the number of people employed as professional translators in a region.',
    options: [
      'Machine translation lowers the cost per word and removes the need for a human intermediary for many routine text types, so volume shifts to low-value categories and premium translators face reduced demand for basic work.',
      'Translation platforms eliminate all translation work, so no translators are required at all.',
      'Translation platforms increase employment, because machine output must always be checked by a translator.',
      'Translation platforms have no effect on translator employment, because demand is infinite.',
    ],
    correct: 0,
    rationale:
      'Technology displaces tasks rather than whole occupations, so the effect depends on task segmentation and quality requirements. Option 1 removes all remaining work, and option 2 ignores the checking work that actually persists.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the effect of English dominance on screen captioning worldwide.',
    options: [
      'Audiences accustomed to English may prefer subtitles that translate from English, so films are re-dubbed rather than subtitled, which raises accessibility for some viewers while reducing visibility for other languages.',
      'English dominance has no effect on captioning practices.',
      'English dominance improves subtitle quality in every language.',
      'English dominance eliminates the need for dubbing entirely.',
    ],
    correct: 0,
    rationale:
      'Distribution and audience language shape subtitling versus dubbing practice, so dominance has real linguistic consequences. Option 1 claims an absence of effect and option 2 asserts a uniform quality gain.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate a proposal to require identification of oneself online using only a first name and nationality in order to reduce harassment.',
    options: [
      'Reduced identifying detail may deter targeted abuse, but it also narrows avenues for accountability and research and may disadvantage minority groups whose names are distinctive, so the design requires moderation and appeal rather than anonymity alone.',
      'The proposal is wholly beneficial, because anonymity always prevents harm.',
      'The proposal is wholly harmful, because anonymity always prevents accountability.',
      'The proposal has no effect, because harassment is unrelated to identity disclosure.',
    ],
    correct: 0,
    rationale:
      'A genuine trade-off exists between protection from targeted abuse and routes to accountability. Options 1 and 2 each assert an absolute outcome that the evidence does not support.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Reflect',
    text: 'Reflect on why treating one dialect as the standard against which others are measured disadvantages speakers of those dialects.',
    options: [
      'Because the standard becomes the reference point, speakers of other dialects are positioned as deviating rather than as users of a different system, which misrepresents their competence and reduces their access to linguistic prestige.',
      'Because dialects do not contain any systematic grammar.',
      'Because standard languages are defined by the number of speakers alone.',
      'Because dialect speakers cannot understand any standard form.',
    ],
    correct: 0,
    rationale:
      'Measurement against a single reference converts descriptive variation into a deficit judgement. Option 1 wrongly denies systematic grammar to dialect speakers and option 2 reduces the standard to population size.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate a proposal for a city to require all emergency public signage to be provided in every language spoken by its residents.',
    options: [
      'Full provision guarantees that no resident is excluded from urgent instructions, but it raises real maintenance, translation and update costs and risks version mismatch when one language is revised after an incident, so signposting and a single authoritative source are essential.',
      'The proposal should be adopted without qualification, because inclusivity never carries a cost.',
      'The proposal should be rejected, because emergency services should use only the most widely spoken language.',
      'The proposal has no effect on safety, because language does not affect comprehension under stress.',
    ],
    correct: 0,
    rationale:
      'Inclusion in emergency communication has genuine benefits but introduces operational risks that must be managed, not dismissed. Options 1 and 2 each assert an absolute outcome and option 3 wrongly treats comprehension under stress as language-independent.',
  }),
];

export default withIds(SUBJECT, items);
