import { q, withIds } from './question-builder.js';

const SUBJECT = 'Language & Literature';

const items = [
  // ---------------- Criterion A: Knowing and understanding (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Define',
    text: 'Define the term "repetition" as a technique used by a writer.',
    options: [
      'The deliberate reuse of a word, phrase, sound or idea for emphasis, rhythm or to develop a theme.',
      'The accidental recurrence of a word in a text due to limited vocabulary.',
      'The restatement of a sentence in a different but identical word order.',
      'The copying of a passage from one text into another without attribution.',
    ],
    correct: 0,
    rationale:
      'Repetition is a deliberate rhetorical technique; option 2 is an error rather than a technique, and option 3 describes paraphrase. Criterion A requires distinguishing technique from error.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Identify',
    text: 'Identify the point of view from which a first-person narrative is told.',
    options: [
      'The point of view of a narrator who is a character within the story and uses "I".',
      'The point of view of an omniscient narrator who knows all characters\' thoughts.',
      'The point of view of a narrator who knows only what can be seen from outside.',
      'The point of view of the author outside the story.',
    ],
    correct: 0,
    rationale:
      'First-person narration uses "I" and is limited to the perceptions of a participating character. Option 1 defines third-person omniscient narration and option 2 defines third-person limited narration.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Define',
    text: 'Define "imagery" in literary analysis.',
    options: [
      'Language that appeals to the senses to make a description vivid and concrete for the reader.',
      'The inclusion of photographs or illustrations alongside a written text.',
      'A comparison drawn between two unlike things.',
      'A deliberate falsehood presented as truth to develop a narrative.',
    ],
    correct: 0,
    rationale:
      'Imagery is sensory language; option 1 describes multimodal composition, option 2 defines simile, and option 3 defines hyperbole or irony.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'State',
    text: 'State what the term "audience" refers to in the analysis of a text.',
    options: [
      'The group of readers or listeners for whom a text is produced and for whom its choices are significant.',
      'The person who physically prints or publishes the text.',
      'The historical period in which the text was first produced.',
      'The collection of all texts written by the same author.',
    ],
    correct: 0,
    rationale:
      'Audience analysis is central to Criterion D and to judging register, tone and purpose. Option 1 confuses audience with production and option 2 confuses it with period.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Give an example',
    text: 'Give an example of a simile.',
    options: [
      'Her voice was like silk drawn across glass.',
      'Her voice was beautiful.',
      'The door slammed loudly in the empty hallway.',
      'He was angry about the delay to the project.',
    ],
    correct: 0,
    rationale:
      'A simile is a direct comparison using "like" or "as". Option 2 states a quality without comparison, and option 3 is an example of onomatopoeia.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'Explain the effect of choosing first-person narration over third-person narration in a text about an unresolved event.',
    options: [
      'First-person narration restricts the reader to one participant\'s subjective account, so the event remains ambiguous and any gaps can be read as evasions or limited memory.',
      'First-person narration gives the reader more information than third-person narration.',
      'First-person narration removes all ambiguity because the narrator is the authority on the events.',
      'First-person narration forces the reader to distrust every statement made in the text.',
    ],
    correct: 0,
    rationale:
      'Restricted perspective creates ambiguity through selectivity rather than through contradiction. Option 1 falsely claims first-person narration widens access to information, and option 2 mistakes reliability for omniscience.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Describe',
    text: 'Describe how the presence of an unreliable narrator signals bias in a text.',
    options: [
      'Contradictions between what the narrator claims and what the narrative shows alert the reader that the account cannot be taken at face value.',
      'The narrator\'s use of long sentences alerts the reader to unreliability.',
      'The narrator\'s gender alerts the reader to unreliability.',
      'Unreliability is signalled only by the author directly stating it in the text.',
    ],
    correct: 0,
    rationale:
      'Unreliability is conventionally cued by internal contradiction between statement and evidence. Option 2 is a purely stylistic feature with no such implication, and option 1 substitutes an extrinsic label for textual cues.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'Explain why a text produced for one audience may not communicate effectively with a different audience.',
    options: [
      'Because shared background knowledge, register and expectations differ, so assumptions the original audience supplies automatically may be absent for a new one.',
      'Because the vocabulary of a text is fixed at the moment of publication and cannot be understood later.',
      'Because shorter texts always suit less educated audiences.',
      'Because audiences cannot change their minds about a text.',
    ],
    correct: 0,
    rationale:
      'Effectiveness depends on shared knowledge and conventions, not on text length or permanence. Option 1 falsely treats language as decaying after publication, and option 3 reduces audience to a single variable.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Outline',
    text: 'Outline the stages involved in analysing how a writer\'s word choice positions the reader.',
    options: [
      'Identify the lexis used, consider the connotations and formality of those choices, relate them to the writer\'s purpose, then determine whether the reader is invited to agree, feel or distrust.',
      'Count the number of adjectives in the text and average their length.',
      'Identify the topic, summarise the plot and list the characters.',
      'Identify the publication date and the author\'s biography, then infer the intended meaning.',
    ],
    correct: 0,
    rationale:
      'Analysis must connect specific choices to connotation, purpose and reader positioning. Option 2 substitutes quantitative counting for interpretation, and option 3 reduces analysis to content summary.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Identify',
    text: 'Identify the rhetorical effect of a speaker beginning a persuasive speech by presenting a statistic that is later shown to be unrepresentative.',
    options: [
      'The technique is an appeal to false authority, because presenting a figure as typical misleads the audience about the evidence base.',
      'The technique is effective because statistics always persuade audiences.',
      'The technique is an example of balanced presentation, because it introduces evidence early.',
      'The technique has no effect, since audiences do not check statistics.',
    ],
    correct: 0,
    rationale:
      'Presenting unrepresentative data as typical is a distortion of evidence regardless of the eventual rebuttal. Option 1 asserts that statistics are inherently persuasive and option 2 misdescribes the structure.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Define',
    text: 'Define "register" as it applies to a text.',
    options: [
      'The particular choice of vocabulary, sentence structure and formality suited to a context, purpose and audience.',
      'The total number of words used in a text.',
      'The sequence in which events occur within a narrative.',
      'The physical layout and typography of a published book.',
    ],
    correct: 0,
    rationale:
      'Register is a sociolinguistic concept about appropriate language for context and audience. Option 2 defines length, option 3 defines plot, and option 4 defines presentation format.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Explain how an author\'s use of archaic language can both enrich and restrict a text.',
    options: [
      'It enriches the text by evoking period and adding texture, but restricts it by demanding historical and lexical knowledge that narrows the possible audience.',
      'It enriches the text by making it easier to read, and restricts it only by increasing length.',
      'It enriches the text by removing regional differences, and restricts it by reducing word count.',
      'It restricts the text only, because archaic language has no literary effect.',
    ],
    correct: 0,
    rationale:
      'Archaic diction operates simultaneously as a resource and as a barrier, which is exactly the double effect criterion-level analysis requires. Option 1 wrongly equates difficulty with length.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Explain why the context in which a text is produced can alter the meaning of its language.',
    options: [
      'Because words carry connotations shaped by the social and historical circumstances of their use, so a later audience may read a term differently from its original intent.',
      'Because words change their literal meanings completely every century.',
      'Because the context determines the number of words in the text.',
      'Because a text produced in one context cannot be read in another.',
    ],
    correct: 0,
    rationale:
      'Semantic change alters connotation while generally preserving reference, which is why context matters. Option 1 overstates the change to meaning and option 3 confuses context with length.',
  }),

  // ---------------- Criterion B: Inquiring and designing (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 1,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question best focuses an investigation into how a writer has used language to present a character as threatening?',
    options: [
      'Which lexical and grammatical choices does the writer use to construct the character as threatening, and how do these position the reader?',
      'Is the writer good at writing about threatening characters?',
      'What is the character like in the story?',
      'Why does the story contain a threatening character at all?',
    ],
    correct: 0,
    rationale:
      'A focused inquiry question names the technique area, the text and the intended analysis. The remaining options are evaluative, descriptive or explanatory but none is investigable through close reading.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Formulate an inquiry question',
    text: 'A student is investigating how two advertisements target different audiences. Which inquiry question is most precise?',
    options: [
      'How do the two advertisements differ in register, visual composition and choice of music in order to influence different demographic groups?',
      'Which advertisement is better?',
      'What do the advertisements sell?',
      'Are advertisements more persuasive than news articles?',
    ],
    correct: 0,
    rationale:
      'Precision requires specifying the analytical features compared, the texts and the population of interest. Option 1 asks for a value judgement rather than analysis, and option 2 requires no textual study.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Organize',
    text: 'Organize a plan for researching how a spoken word poem has changed over fifty years, before presenting to an audience.',
    options: [
      'Define the focus, locate and evaluate recordings across the period, transcribe and annotate repeated features, check a secondary source, then structure the presentation by technique and effect.',
      'Watch one recording, decide an opinion, and present it as a documentary about the whole period.',
      'Collect the most extreme examples available, then present them in chronological order without explanation.',
      'Ask classmates which version they prefer and present the majority view with examples.',
    ],
    correct: 0,
    rationale:
      'A defensible Criterion B process requires definition, source evaluation, systematic annotation and corroboration. Options 1 and 2 select evidence to fit a conclusion, and option 3 substitutes preference for analysis.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Examine',
    text: 'Examine the reliability of a single social media post as a source about a local community\'s response to a development proposal.',
    options: [
      'It is unreliable because it is unreferenced, unverified and represents one individual\'s view, so it cannot establish what the community collectively believes.',
      'It is reliable because social media platforms allow wide readership.',
      'It is reliable because the post was written by a resident of the area.',
      'It is unreliable only because posts are usually shorter than newspaper articles.',
    ],
    correct: 0,
    rationale:
      'A single unreferenced post is an individual account, not a representative sample of opinion. Option 1 confuses reach with reliability, and option 3 identifies residence rather than evidence.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Design',
    text: 'Design a survey to determine how frequently readers of different ages prefer a particular written text.',
    options: [
      'Sample readers across age bands, give each the same text under identical conditions, ask a fixed preference question with rating options, and record responses by band.',
      'Ask the reading group in the library which text they prefer, since they are the most readily available.',
      'Ask each participant to describe the text in their own words and classify the responses afterwards.',
      'Interview the authors and ask which text they believe readers prefer.',
    ],
    correct: 0,
    rationale:
      'A valid survey requires a defined sample, standardised presentation and a fixed response format. Option 1 uses a convenience sample, and option 2 and option 3 collect tangential data.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Identify',
    text: 'Identify the key difference between researching a topic and researching a text.',
    options: [
      'Researching a text involves close analysis of its specific language, structure and context, whereas researching a topic establishes background facts about a subject.',
      'Researching a text is always quicker than researching a topic.',
      'Researching a topic requires reading the primary text, whereas researching a text does not.',
      'There is no difference, since the two terms are interchangeable.',
    ],
    correct: 0,
    rationale:
      'Text-based research interprets particular choices within a text, while topic research assembles factual background. Option 2 conflates text research with topic research entirely.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Construct',
    text: 'Construct an inquiry question for a comparison of how two news outlets reported the same international event.',
    options: [
      'How do the two outlets differ in headline construction, source selection and framing in shaping their presentation of the same event?',
      'Which outlet reported the event more accurately?',
      'Which outlet has more readers?',
      'How long did each outlet spend reporting the event?',
    ],
    correct: 0,
    rationale:
      'A comparative inquiry must identify specific analytical dimensions across both texts. Options 1 to 3 ask questions of fact or preference that cannot be answered by textual analysis alone.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Examine',
    text: 'Examine the claim that a text\'s meaning is entirely determined by its author\'s intention.',
    options: [
      'The claim understates the role of context, genre, convention and reader response, since meaning is produced through interaction between text, reader and circumstances rather than transmitted intact.',
      'The claim is correct, because authors write to communicate precisely one meaning.',
      'The claim is correct, because readers do not bring their own experiences to a text.',
      'The claim is correct only for poetry, since poetry has a fixed meaning.',
    ],
    correct: 0,
    rationale:
      'Reader-response and contextual models treat meaning as negotiated, not delivered. Option 1 overstates authorial control and option 2 denies the reader\'s interpretive contribution.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Analyse',
    text: 'Analyse why a historical text may be more useful for understanding the past than a modern account of the same event.',
    options: [
      'A contemporary text records perceptions and language available at the time, so it evidences how the event was understood rather than how it is now reconstructed.',
      'A historical text is always more accurate because it was written closer to the events.',
      'A historical text is more useful only because it is shorter.',
      'A historical text is more useful only because it has not yet been challenged by later scholarship.',
    ],
    correct: 0,
    rationale:
      'Contemporary texts are primary sources for period perception; option 1 confuses proximity with accuracy, since they share the biases of their moment.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Prioritize',
    text: 'A student must research a short text from an unfamiliar culture before a short presentation. Which line of inquiry should be prioritized first?',
    options: [
      'Establishing the cultural context of the text, since conventions of genre, register and allusion determine whether specific choices can be interpreted at all.',
      'Counting the number of sentences, since length determines complexity.',
      'Choosing the presentation template, since format determines the message.',
      'Comparing the text with three other texts, since breadth always precedes context.',
    ],
    correct: 0,
    rationale:
      'Contextual knowledge is a precondition for close reading of an unfamiliar text. Option 2 prioritises a superficial metric, and option 3 confuses presentation with analysis.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Examine',
    text: 'Examine the claim that a more thorough literary analysis is always a better analysis.',
    options: [
      'The claim is not justified, because thoroughness without a focused question can obscure the text; analysis is strongest when depth is directed by a specific inquiry.',
      'The claim is justified, because longer analyses are always more accurate.',
      'The claim is justified, because teachers award marks for volume.',
      'The claim is not justified only because students write too quickly in timed conditions.',
    ],
    correct: 0,
    rationale:
      'Criterion B rewards purposeful inquiry rather than accumulation. Option 1 equates quantity with quality, and option 2 appeals to marking practice rather than analytical merit.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Develop',
    text: 'Develop a plan for investigating how an author\'s treatment of a single theme changes across three novels published in different decades.',
    options: [
      'Define the theme precisely, select three novels, establish each publication context, identify how the theme is framed in each, then compare framings against the contexts rather than treating the author\'s view as constant.',
      'Read the three novels, list the theme in each, and conclude that the author was consistent in all three.',
      'Read only the most recent novel, since it reflects the author\'s mature view.',
      'Ask a teacher which novel best expresses the theme and report that judgment.',
    ],
    correct: 0,
    rationale:
      'A valid design controls for context, defines terms and resists the assumption of a fixed authorial viewpoint. Option 1 assumes constancy, which the study is designed to test.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Construct',
    text: 'Construct a research question that would test whether a single author\'s political position has shifted consistently across three works written in different decades.',
    options: [
      'Across the three works, how consistently does the author\'s explicit position on the same political question shift in line with the political context of each publication, and where does it fail to shift?',
      'Was the author a political writer?',
      'Which of the three works is the author\'s best book?',
      'What did the author believe about politics?',
    ],
    correct: 0,
    rationale:
      'Option 0 holds the political question constant across the three texts, ties change to publication context and requires the null case to be reported, so the finding is falsifiable. The alternatives require no textual comparison and none can be answered with evidence.',
  }),

  // ---------------- Criterion C: Communicating and thinking critically (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 1,
    command: 'Analyse',
    text: 'Analyse the effect of a writer ending a chapter without resolving the conflict it introduces.',
    options: [
      'The unresolved conflict creates tension and prompts the reader to continue, since the narrative withholds resolution and therefore sustains curiosity.',
      'The unresolved conflict makes the plot illogical, because narratives must be resolved immediately.',
      'The unresolved conflict has no effect, since readers forget chapter endings.',
      'The unresolved conflict reduces the length of the chapter.',
    ],
    correct: 0,
    rationale:
      'Deliberate deferral is a structural device producing narrative tension. Option 1 confuses artistic choice with error, and option 2 ignores established narrative convention.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Apply',
    text: 'Apply the concept of bias to a headline that describes a protest as a "riot". Choose the option that best identifies the bias present.',
    options: [
      'The lexical choice frames the protest as disorderly, reflecting the reporter\'s standpoint rather than a neutral description of events.',
      'The headline is unbiased, because "riot" is the standard technical term for a protest.',
      'The headline is biased only because it is shorter than the article.',
      'The headline is unbiased, because word choice cannot affect readers.',
    ],
    correct: 0,
    rationale:
      'Lexical selection carries connotation, so "riot" presupposes illegitimacy that the events themselves may not warrant. Option 1 wrongly treats a loaded term as purely technical.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Summarize',
    text: 'Summarize the main difference between an explicit and an implicit meaning in a text.',
    options: [
      'An explicit meaning is stated directly by the text, whereas an implicit meaning must be inferred from the choices the writer has made.',
      'An explicit meaning is understood by educated readers, while an implicit meaning is understood by all readers.',
      'An explicit meaning appears at the end, while an implicit meaning appears at the beginning.',
      'An explicit meaning uses short sentences, while an implicit meaning uses long sentences.',
    ],
    correct: 0,
    rationale:
      'The distinction is between stated content and inferred content, not between reader ability or position. Option 2 conflates inference with literacy level, which is a common misreading of this distinction.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Critique',
    text: 'Critique the analysis: "The writer uses short sentences in the final scene, which is effective."',
    options: [
      'The analysis identifies a technique but offers no justification of the effect produced, no reference to context and no link to purpose, so it does not constitute analysis.',
      'The analysis is complete, because naming a technique and an effect is sufficient.',
      'The analysis is invalid only because it does not state the theme of the text.',
      'The analysis is complete, because short sentences are always effective in fiction.',
    ],
    correct: 0,
    rationale:
      'Analysis requires linking technique to effect with textual justification. Option 1 states a criterion-level requirement for analysis, which option 2 mistakes for a stylistic preference.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate the claim that a text written in formal standard English is more sophisticated than one written in a regional variety.',
    options: [
      'The claim is not justified, because standard languages are institutional standards rather than intrinsically superior systems; sophistication should be judged by the appropriateness and control of the choices made.',
      'The claim is justified, because standard English has a larger vocabulary than any regional variety.',
      'The claim is justified, because regional varieties contain no grammar.',
      'The claim is not justified only because formal English is harder to write.',
    ],
    correct: 0,
    rationale:
      'Descriptivism treats varieties as equally systematic, differing in use rather than in correctness. Option 1 wrongly equates breadth of vocabulary with sophistication.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Discuss',
    text: 'Discuss why the same event can be presented very differently by two photographers in the same crowd.',
    options: [
      'Framing, timing and angle determine what is included and excluded, so each photograph constructs a different emphasis while omitting the surrounding context that might contradict it.',
      'The photographs differ only because one photographer used a better camera.',
      'The photographs are identical in meaning because both show the same event.',
      'The photographs differ only because the crowd moved between shots.',
    ],
    correct: 0,
    rationale:
      'Photographic meaning is constructed by selection and framing rather than by recording neutrally. Option 2 attributes meaning to equipment rather than to composition, and option 1 assumes content determines meaning.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Argue',
    text: 'Argue whether censorship of a literary text is ever justified, and state one counterargument.',
    options: [
      'Protection of a vulnerable group from demonstrable harm is a defensible justification, while the counterargument holds that suppression usually produces underground circulation and removes the text from the curriculum where it could be taught critically.',
      'Censorship is never justified, because all restriction of art is censorship.',
      'Censorship is always justified, because audiences cannot be trusted to respond maturely.',
      'Censorship is justified only for texts more than one hundred years old.',
    ],
    correct: 0,
    rationale:
      'A reasoned argument must weigh a substantive principle against a real opposing case, which only the first option does. Options 1 to 3 take absolute positions that foreclose the trade-off.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Compare',
    text: 'Compare how two texts addressing the same social issue build different arguments.',
    options: [
      'One may rely on statistical evidence and expert testimony while the other relies on personal testimony and anecdote, so the difference lies in the evidential basis and the audience each is designed to persuade.',
      'Both build identical arguments, because the issue determines the conclusion.',
      'One is persuasive and the other is not, based on length alone.',
      'Neither builds an argument, because narrative cannot support a position.',
    ],
    correct: 0,
    rationale:
      'Argumentative structure and evidence type determine persuasive reach for a target audience. Option 1 wrongly asserts that subject matter determines conclusion, and option 3 dismisses narrative as incapable of argument.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the claim that a translation conveys the same meaning as its source text.',
    options: [
      'The claim is not justified, because word choice, connotation, register and cultural reference rarely transfer exactly, so meaning is always partly adapted to the target language and audience.',
      'The claim is justified, provided the translation is accurate at sentence level.',
      'The claim is justified, provided the translator is a native speaker of the target language.',
      'The claim is not justified only because translations are always shorter.',
    ],
    correct: 0,
    rationale:
      'Semantic and pragmatic meaning diverge systematically in translation. Option 1 mistakes sentence-level accuracy for total equivalence, and option 2 confuses fluency with fidelity.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Critique',
    text: 'Critique the analysis: "The writer describes the setting in great detail to establish the time period and the mood, and the imagery of decay reinforces the narrator\'s declining mental state."',
    options: [
      'The analysis is largely well developed but would be strengthened by quoting specific images and linking them explicitly to the narrator\'s psychology rather than asserting the connection in general terms.',
      'The analysis is complete, because it identifies technique, purpose and effect.',
      'The analysis is weak only because it fails to comment on the sentence length.',
      'The analysis is invalid because setting cannot reflect a narrator\'s mental state.',
    ],
    correct: 0,
    rationale:
      'Criterion C requires analysis to be supported by reference to specific textual choices. Option 0 offers substantive critique; option 1 wrongly accepts an unsupported assertion as complete, and option 2 asserts an impossibility.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the claim that advertising language is always dishonest.',
    options: [
      'The claim is overstated, because advertising routinely uses hyperbole and omission, but some advertising accurately represents products, so honesty must be assessed case by case against evidence.',
      'The claim is correct, because all advertising exaggerates by definition.',
      'The claim is incorrect because advertising never uses persuasion.',
      'The claim is correct only for advertising aimed at children.',
    ],
    correct: 0,
    rationale:
      'A critical evaluation must distinguish tendency from universal rule. Option 1 and option 2 both assert absolutes in opposite directions without evidence.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Expose',
    text: 'Expose the flaw in the reasoning: "This author writes only about war, so war must be the central concern of all literature."',
    options: [
      'The reasoning generalises from a single author\'s subject matter to a whole category, mistaking an individual corpus for the discipline itself.',
      'The reasoning is sound, because literature reflects the dominant concerns of its authors.',
      'The reasoning is unsound only because the author in question is not famous.',
      'The reasoning is sound, because war is a universal human experience.',
    ],
    correct: 0,
    rationale:
      'A single author\'s work cannot establish what all literature concerns; the inference commits an unwarranted generalisation. Option 1 confuses description with universalisation, and option 2 makes an appeal to universality rather than evidence.',
  }),

  // ---------------- Criterion D: Reflecting on language in real-world contexts (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 1,
    command: 'Describe',
    text: 'Describe one reason why slang changes more rapidly than formal written English.',
    options: [
      'Slang is used primarily in face-to-face peer interaction, where novelty signals belonging and it is therefore replaced quickly.',
      'Slang is always grammatically simpler, so it changes more easily.',
      'Slang is never written down, so it cannot change.',
      'Slang changes rapidly because it is taught formally in schools.',
    ],
    correct: 0,
    rationale:
      'Rapid turnover is a function of the social function of slang, marking group identity. Option 2 confuses simplification with rate of change, and option 3 contradicts extensive written use of slang.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Explain',
    text: 'Explain why a speaker changes register when addressing a supervisor rather than a close friend.',
    options: [
      'The relationship and the power difference alter what is considered appropriate, so vocabulary, formality and directness shift to match the new context.',
      'The speaker must always use the longest words available in any formal situation.',
      'The speaker should continue to speak exactly as before to remain consistent.',
      'The speaker should use formal language only when being corrected.',
    ],
    correct: 0,
    rationale:
      'Register is relational, so a change in relationship requires a change in language. Option 1 reduces formality to a vocabulary-length rule and option 2 treats consistency as universally desirable.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Evaluate',
    text: 'Evaluate the claim that written communication is always clearer than spoken communication.',
    options: [
      'The claim is not justified, because writing permits revision and permanence but removes tone and non-verbal cues, so clarity depends on the message and the audience.',
      'The claim is justified, because writing cannot be misunderstood.',
      'The claim is justified, because spoken language is always imprecise.',
      'The claim is not justified only because writing is slower to produce.',
    ],
    correct: 0,
    rationale:
      'Each medium carries affordances and losses relative to the other. Option 1 falsely claims writing is immune to misinterpretation and option 2 wrongly denigrates spoken language.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Discuss',
    text: 'Discuss how a community standard of written English can disadvantage some speakers.',
    options: [
      'Where assessment rewards standard forms, speakers of regional or multilingual repertoires may be penalised for their normal usage, so judgements about ability become judgements about conformity to one variety.',
      'A standard variety disadvantages speakers only if they are taught it at school.',
      'A standard variety never disadvantages speakers, because it is the most logical option available.',
      'A standard variety disadvantages only speakers who cannot read.',
    ],
    correct: 0,
    rationale:
      'Standardisation measures conformity rather than competence when varieties are systematically treated as different in quality. Option 1 denies the possibility of disadvantage altogether and option 2 reverses the direction of the effect.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate a proposal that all public signs should display only one language.',
    options: [
      'Reducing language to one excludes those who do not read it, so social access and cultural visibility must be weighed against administrative simplicity.',
      'One language should be used because it is easier for visitors to understand.',
      'One language should be used because multiple languages are always more expensive than one.',
      'Multiple languages should always be used because language has no cost implications.',
    ],
    correct: 0,
    rationale:
      'A Criterion D evaluation must weigh social access against practical cost rather than assume either dominates. Options 1 and 2 both appeal to unevidenced generalizations.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Reflect',
    text: 'Reflect on how messaging apps have changed the conventions of written communication.',
    options: [
      'Informality has become the norm as brevity and immediacy are rewarded, so conventions of formality, punctuation and paragraph structure are shifting in written language.',
      'Written conventions are unchanged, because platforms do not affect language.',
      'Informality has become the norm because writing is no longer taught.',
      'Written conventions are unchanged, because spoken language has become more formal.',
    ],
    correct: 0,
    rationale:
      'Platform affordances shape register in measurable ways, which is why written norms shift with medium. Option 1 asserts that technology cannot affect language, and option 2 and option 3 attribute the change to pedagogy rather than medium.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the ethical responsibility of a news organisation that publishes a story built on a single anonymous source.',
    options: [
      'Publishing unverified and non-attributable claims risks circulating misinformation and harming those named, so corroboration, care in wording and a stated degree of certainty are needed.',
      'There is no ethical responsibility, because the organisation only reports what it is given.',
      'There is an ethical responsibility only if the source turns out to be wrong.',
      'There is an ethical responsibility only if the story is about a public figure.',
    ],
    correct: 0,
    rationale:
      'Ethical publishing practice concerns foreseeable risk and appropriate attribution, not outcomes alone. Option 1 absolves the publisher of verification duty, and option 2 makes ethics depend on a later discovery.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the effect of an AI-generated summary replacing an original article on a website.',
    options: [
      'Compression removes context, attribution and nuance that made the original accountable, so readers receive fewer verifiable sources and less ability to judge reliability.',
      'Compression always improves clarity, because shorter texts are easier to understand.',
      'There is no effect, because summaries preserve all of the original meaning.',
      'There is no effect, because readers do not rely on original sources.',
    ],
    correct: 0,
    rationale:
      'Summaries systematically drop the attribution that permits verification. Option 1 mistakes brevity for comprehension, and option 2 asserts an equivalence between summary and original that does not hold.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Discuss',
    text: 'Discuss how the language of social media comment sections differs from that of an academic journal, and what each is optimised for.',
    options: [
      'Comment sections favour brevity, affect and identity performance, whereas journals favour precision, method and accountable authorship; each convention serves its purpose and its context.',
      'Comment sections are superior because they allow everyone to contribute equally.',
      'Journals are superior because their language is more complex.',
      'The two are identical because register does not depend on context.',
    ],
    correct: 0,
    rationale:
      'Conventions arise from the values of their context, which is the core of Criterion D reflection on language. Option 1 assumes contribution counts are equal, and option 2 equates complexity with quality.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate a proposal to make a regional language compulsory in schools so that local heritage is preserved.',
    options: [
      'Preserving a language is valuable, but compulsion risks marginalising multilingual students and parents, so language policy must weigh heritage value against individual access and choice.',
      'Compulsion is justified because heritage always takes priority over individual preference.',
      'Compulsion is unjustified because regional languages are no longer spoken at home.',
      'Compulsion is unjustified only because textbooks are unavailable.',
    ],
    correct: 0,
    rationale:
      'A Criterion D evaluation must consider effects on individuals as well as on the collective goal. Option 1 subordinates individual access without argument, and option 2 assumes a monolingual reality that varies by region.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Reflect',
    text: 'Reflect on why teaching students to recognise bias in language is a transferable skill rather than a topic-specific one.',
    options: [
      'Because bias is produced by ordinary word choice and framing in any context, so the analytical habit applies to news, advertising, conversation and academic writing alike.',
      'Because bias appears only in journalistic writing and nowhere else.',
      'Because identifying bias is useful only for students who intend to study literature.',
      'Because bias detection requires memorising a fixed list of banned words.',
    ],
    correct: 0,
    rationale:
      'Transferability follows from identifying the general mechanism, which here is connotation and framing. Option 3 wrongly confines the skill, and option 2 mistakes a transferable habit for a memorised list.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the impact on a community of the loss of a local dialect over two generations.',
    options: [
      'A local dialect encodes place-specific knowledge, humour and identity, so its loss removes a distinct voice from cultural representation and weakens the transmission of that knowledge to younger members.',
      'A dialect carries no cultural information, so its loss is purely aesthetic.',
      'The loss is offset because standard language is always more expressive.',
      'Dialects are preserved automatically in writing, so no loss occurs.',
    ],
    correct: 0,
    rationale:
      'Dialect loss is a loss of culturally specific knowledge and representation, not merely of variety. Option 2 treats dialect as empty of meaning and option 3 assumes standard forms are inherently more expressive.',
  }),
];

export default withIds(SUBJECT, items);
