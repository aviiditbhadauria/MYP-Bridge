import { q, withIds } from './question-builder.js';

const SUBJECT = 'Individuals & Societies';

const items = [
  // ---------------- Criterion A: Knowing and understanding (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Define',
    text: 'Define the term "supply" in an economic context.',
    options: [
      'The quantity of a good or service that producers are willing and able to offer for sale at a given set of prices.',
      'The quantity of a good that consumers wish to purchase at a given price.',
      'The total amount of a good produced, regardless of whether anyone wants it.',
      'The cost incurred by producers in making a good.',
    ],
    correct: 0,
    rationale:
      'Supply depends on both willingness and ability to offer at a price, whereas demand is the consumer-side concept in option 1. Option 2 defines output and option 3 defines cost.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'State',
    text: 'State the name of the peninsula forming most of the southern border of the country in which the Great Barrier Reef lies.',
    options: ['Cape York Peninsula', 'Yorke Peninsula', 'Kowloon Peninsula', 'Iberian Peninsula'],
    correct: 0,
    rationale:
      'The Great Barrier Reef lies off the coast of Queensland, Australia, bordered to the south by the Cape York Peninsula. Options 1 and 3 are in other countries or regions entirely.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Define',
    text: 'Define "urbanisation" as used in geography.',
    options: [
      'The process by which an increasing proportion of a population lives in towns and cities rather than in rural areas.',
      'The construction of new housing on the edge of an existing city.',
      'The movement of people from one city to another.',
      'The decline of manufacturing in a city centre.',
    ],
    correct: 0,
    rationale:
      'Urbanisation is a change in the distribution of population, not merely in housing stock. Option 1 describes one mechanism, and option 2 describes one consequence.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Identify',
    text: 'Identify which of the following is a primary source for studying the Industrial Revolution.',
    options: [
      'A factory owner\'s diary describing working conditions at the time.',
      'A modern textbook surveying the causes of industrialisation.',
      'A statistical table of GDP compiled in 2021.',
      'An economic model used to interpret nineteenth-century data.',
    ],
    correct: 0,
    rationale:
      'A primary source is produced at the time of the events by a direct participant. Options 1 and 2 are later interpretations rather than contemporary accounts.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Give an example',
    text: 'Give an example of a physical barrier to trade between two countries.',
    options: [
      'A mountain range that forces goods to travel by a long, costly detour.',
      'A tariff imposed by one government on imported goods.',
      'A quota limiting the volume of imports permitted.',
      'A currency used in one country and not accepted in the other.',
    ],
    correct: 0,
    rationale:
      'A physical barrier is geographical rather than imposed by policy. Option 1 is an economic barrier, option 2 is a quantitative restriction, and option 3 is a monetary barrier.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'Explain why a country may choose to maintain a national defence industry rather than import all of its military equipment.',
    options: [
      'Domestic production guarantees supply independent of international trade routes and political relations, so it preserves strategic autonomy in a crisis.',
      'Domestic production is always cheaper, because imported goods carry tariffs.',
      'Domestic production is necessary because imported equipment cannot function domestically.',
      'Domestic production is desirable mainly because it employs fewer people.',
    ],
    correct: 0,
    rationale:
      'Strategic autonomy concerns independence from external constraint rather than cost. Option 1 claims an automatic price advantage and option 2 misstates the rationale as national employment reduction.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Describe',
    text: 'Describe the main stages of a demographic transition model as a population moves from a high birth and death rate to a low birth and death rate.',
    options: [
      'Death rates fall first because of improved food, sanitation and medicine, creating rapid population growth; birth rates then fall later as education, income and urbanisation rise.',
      'Birth rates fall first because of improved healthcare, creating rapid decline immediately.',
      'Birth and death rates fall simultaneously, so population growth remains constant throughout.',
      'Death rates rise first because of industrialisation, then both rates fall together.',
    ],
    correct: 0,
    rationale:
      'The essential asymmetry is that mortality declines before fertility, producing the demographic dividend of rapid growth. Option 1 misorders the stages and option 2 removes the growth phase entirely.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Outline',
    text: 'Outline the stages involved in analysing a historical event using cause and effect.',
    options: [
      'Establish what happened, identify the political, economic, social, technological and environmental conditions preceding it, distinguish long-term from short-term causes, then assess the consequences and unintended outcomes.',
      'List the most dramatic events of the period and rank them by importance.',
      'Identify the single most important cause and present it as the explanation.',
      'Summarise the event in chronological order and conclude.',
    ],
    correct: 0,
    rationale:
      'Causal analysis requires distinguishing types of cause and separating consequences from intentions. Option 2 imposes monocausal explanation, and option 0 substitutes description for analysis.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Explain',
    text: 'Explain why an increase in the price of a good may reduce the quantity demanded but rarely reduce the quantity supplied in the short run.',
    options: [
      'Demanders can substitute or reduce purchases immediately, while suppliers are committed to contracts, plant and sunk costs, so their output decisions adjust only over time.',
      'Suppliers always hold fixed stocks, so they can never respond to price changes.',
      'Demand and supply respond identically, so the difference is an error in the data.',
      'Suppliers respond only to changes in the exchange rate.',
    ],
    correct: 0,
    rationale:
      'Asymmetry arises from differing adjustment costs across the two sides of the market. Option 1 confuses the elasticity of response with the absence of one, and option 2 misattributes the difference to data quality.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Define',
    text: 'Define "opportunity cost" as used in economics.',
    options: [
      'The value of the next best alternative given up when a choice is made.',
      'The monetary price paid for a good or service.',
      'The total revenue forgone when a firm closes down temporarily.',
      'The cost of producing one additional unit of output.',
    ],
    correct: 0,
    rationale:
      'Opportunity cost concerns forgone alternatives, not the price paid. Option 1 defines marginal cost and option 2 is an accounting concept rather than an economic one.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Explain why a developing country may experience both rapid economic growth and rising inequality at the same time.',
    options: [
      'Growth concentrated in capital-intensive or export sectors can raise national output while wages and asset ownership lag, so aggregate figures rise faster than household incomes.',
      'Growth and inequality are mutually exclusive, so both cannot occur together.',
      'Rising inequality always causes economic growth to slow immediately.',
      'Inequality rises only in countries that experience no economic growth.',
    ],
    correct: 0,
    rationale:
      'Distribution and growth are analytically separate, and structural change can widen the gap. Option 1 asserts an impossible combination, and option 2 claims an automatic effect that is not generally observed.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Give an example',
    text: 'Give an example of a positive externality.',
    options: [
      'A company installs lighting in a public park, reducing crime for all who use it.',
      'A factory discharges waste into a river, degrading water quality for others.',
      'A commuter drives to work, increasing congestion on the road.',
      'A smoker lights a cigarette in a shared space, affecting others present.',
    ],
    correct: 0,
    rationale:
      'A positive externality benefits third parties beyond those transacting. The remaining options are all negative externalities because they impose costs on others.',
  }),

  // ---------------- Criterion B: Inquiring and designing (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 1,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question is best formulated for investigating how a new retail development affects the surrounding area?',
    options: [
      'How has the opening of the retail development affected local employment, traffic and residents\' perceptions, and how do these effects differ between groups?',
      'Is the retail development good or bad for the area?',
      'How big is the retail development?',
      'How many shops are in the retail development?',
    ],
    correct: 0,
    rationale:
      'A rigorous inquiry names measurable impacts, specifies the groups compared and avoids embedding a value judgement in the wording. Option 0 requires no evidence to answer.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 1,
    command: 'Identify',
    text: 'Identify which of the following is data rather than information in a business context.',
    options: [
      'The figure 1 240 units sold in March.',
      'The conclusion that sales rose because of the discount applied in March.',
      'The decision to discontinue the discount in April.',
      'The forecast that sales will fall by 10% next quarter.',
    ],
    correct: 0,
    rationale:
      'Data is unprocessed figures; options 1 to 3 are interpretations, decisions and predictions built upon it. Criterion B requires distinguishing the raw material of an inquiry from the analysis.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question is most precise for investigating why a school\'s examination results improved?',
    options: [
      'Which changes to revision provision, timetabling and teacher feedback coincide with the change in mean grade between 2019 and 2025, and which student groups benefited most?',
      'Why did the results improve?',
      'Did the teachers try harder?',
      'Are the new results better than the old ones?',
    ],
    correct: 0,
    rationale:
      'Specificity requires named variables, a time frame and an equity dimension. Option 1 embeds an unsupported causal assumption in the wording of the question itself.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Design',
    text: 'Design a method for investigating how many households in a town rely on private cars for daily travel.',
    options: [
      'Take a random sample of households, administer the same short questionnaire to each, record the responses and report the sample size alongside the proportions found.',
      'Ask households at the school gate, since they are easiest to reach.',
      'Count the cars parked outside the town centre each morning for one week.',
      'Ask local businesses how many of their employees drive to work.',
    ],
    correct: 0,
    rationale:
      'A random sample with a standardised instrument and a stated denominator supports a generalisable proportion. Option 1 uses a convenience sample and option 2 uses an uncalibrated indirect measure.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Organize',
    text: 'Organize a sequence for investigating the causes of a decline in a regional manufacturing industry.',
    options: [
      'Define the scale and period of the decline, identify candidate economic, political, technological and environmental factors, gather quantitative and qualitative evidence for each, then test which explanations the evidence supports.',
      'Interview one retired worker and report his account as the cause.',
      'Compare the decline with a region whose industry is growing and assume the causes are opposite.',
      'List every factor that could be involved without gathering evidence for any of them.',
    ],
    correct: 0,
    rationale:
      'A defensible investigation defines scope, generates candidate explanations, gathers evidence and tests it. Option 1 generalises from a single account, and option 3 substitutes speculation for evidence.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Analyse',
    text: 'Analyse why a single photograph of a crowd at a political demonstration may be a weak source for a history assessment.',
    options: [
      'It records one moment, one angle and one viewpoint, so it cannot show how representative the crowd was, who was absent or what occurred before and after.',
      'It is weak only because photographs were taken with a different technology.',
      'It is strong evidence because it is a direct record of the event.',
      'It is weak only because photographs cannot be archived.',
    ],
    correct: 0,
    rationale:
      'A single image is a partial record whose selection of moment and angle is itself evidence requiring corroboration. Option 2 confuses the medium with reliability and option 0 wrongly asserts that photographs cannot be preserved.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Examine',
    text: 'Examine the claim that a data set collected from social media accurately represents public opinion on a policy.',
    options: [
      'The claim is untenable because social media users are self-selected, unrepresentative in age and socioeconomic composition, and predisposed towards more extreme expression than the general population.',
      'The claim is valid because the sample is very large.',
      'The claim is valid because social media is available to everyone.',
      'The claim is untenable only because social media data are not collected by researchers.',
    ],
    correct: 0,
    rationale:
      'Representativeness, not sample size, determines whether a sample supports generalisation. Option 1 confuses quantity with validity, and option 2 wrongly assumes equal platform access.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question would generate the most useful evidence about the effect of a new public transport line on local business?',
    options: [
      'How did footfall, revenue and opening hours of businesses within 400 m of the new stations change relative to comparable streets further from the stations?',
      'Do business owners like the new transport line?',
      'Has the transport line increased overall transport usage in the city?',
      'Was the transport line built on time?',
    ],
    correct: 0,
    rationale:
      'Using a comparison group controls for city-wide trends and the specified radius makes the exposure measurable. Options 1 to 3 either measure something other than business impact or ask about a matter of fact already documented.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the reliability of an official government statistic as evidence about the standard of living in a country.',
    options: [
      'It is reliable for the indicators it defines consistently, but the choice of indicators, the treatment of informal activity and the political interest of the publishing body all require independent corroboration.',
      'It is unreliable because governments are always concealing poor outcomes.',
      'It is reliable without qualification because official statistics are independently audited.',
      'It is reliable only for countries that publish every statistic.',
    ],
    correct: 0,
    rationale:
      'Official statistics are strong within their defined scope and weak where definition or interest intervenes. Option 1 asserts deliberate concealment, and option 2 wrongly assumes automatic independent audit.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Prioritize',
    text: 'A geography class must investigate local air quality. Which approach should be prioritised first?',
    options: [
      'Establishing a baseline of measurements taken at fixed points at the same times over several weeks before comparing any intervention.',
      'Collecting opinions from residents about how polluted the area feels.',
      'Examining satellite images of the region taken from space.',
      'Reading a global report on air quality published last year.',
    ],
    correct: 0,
    rationale:
      'A baseline under controlled conditions is a precondition for attributing any later change. Option 1 measures perception rather than concentration, and option 2 provides no local measurement at all.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Examine',
    text: 'Examine the claim that studying only written sources gives a balanced view of a historical period.',
    options: [
      'Written archives disproportionately preserve the views of literate, wealthy and institutional groups, so material, oral and visual sources are needed to recover the experience of others.',
      'Written sources are always the most reliable and therefore make others unnecessary.',
      'Written sources are always biased and therefore useless for study.',
      'Written sources are balanced because they were produced at the time of the events.',
    ],
    correct: 0,
    rationale:
      'Survival of evidence is socially patterned, so a single source type systematically omits certain groups. Option 1 equates proximity with reliability and option 2 rejects all written evidence for a pattern of bias.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Develop',
    text: 'Develop an inquiry design for assessing whether a proposed shopping centre would increase traffic collisions in the surrounding area.',
    options: [
      'Compile collision data for the area for several years before the proposal, identify comparable areas without the proposal, establish the current traffic generation rate, and state in advance what magnitude of change would count as evidence.',
      'Survey residents about whether they feel roads have become more dangerous.',
      'Compare the proposal with a different proposal proposed at another location.',
      'Assume collisions will rise and select data to support that conclusion.',
    ],
    correct: 0,
    rationale:
      'The design includes a baseline, a comparison group, a quantified exposure and a stated evidential threshold. Option 1 measures perception and option 3 compares mismatched cases, neither of which can isolate a causal effect.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Analyse',
    text: 'Analyse why correlation between internet access and examination results does not establish that internet access causes higher results.',
    options: [
      'Because household income, parental education and quiet study space plausibly raise both internet provision and results, so the observed association may be entirely confounded.',
      'Because internet access has no relationship with results whatsoever.',
      'Because correlation can only be calculated for physical variables.',
      'Because examination results cannot be measured reliably.',
    ],
    correct: 0,
    rationale:
      'Confounding variables produce the association without any causal pathway from internet access. Option 1 overstates the null hypothesis and option 2 restricts correlation to a single type of variable.',
  }),

  // ---------------- Criterion C: Communicating and thinking critically (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 1,
    command: 'Justify',
    text: 'A student claims a photograph proves that a nineteenth-century factory was overcrowded. Justify or challenge the claim.',
    options: [
      'Challenge it: a single photograph shows one room at one moment and may have been staged or chosen for effect, so it evidences an intention to depict conditions rather than their extent.',
      'Accept it, because photographs cannot be manipulated.',
      'Accept it, because photographs are primary sources.',
      'Challenge it, only because photographs do not show the date.',
    ],
    correct: 0,
    rationale:
      'Photographs are primary sources for what someone wished to depict, not neutral surveys of a whole. Option 1 asserts that the medium guarantees accuracy and option 2 conflates source type with proof.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Compare',
    text: 'Compare the perspective of a history textbook written by a government ministry with one written by an independent scholar.',
    options: [
      'The ministry text is likely to emphasise national achievement and omit contested events, while the scholar may foreground disputed interpretations and require the reader to weigh competing claims.',
      'Both present the same facts, differing only in writing style.',
      'The ministry text is always correct, because governments hold the official records.',
      'The scholar\'s text is always unbiased, because independent authors hold no views.',
    ],
    correct: 0,
    rationale:
      'Institutional position shapes selection and framing as much as it shapes the archive consulted. Option 1 treats institutional neutrality as guaranteed on one side and on the other.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Apply',
    text: 'Apply the concept of a representative sample to a survey of 400 people conducted entirely outside one shopping centre.',
    options: [
      'The sample is unlikely to be representative, because shoppers at one location exclude non-shoppers, home-based consumers and people who cannot travel to that centre.',
      'The sample is representative, because 400 is a large enough number.',
      'The sample is representative, because all respondents answered the same question.',
      'The sample is unrepresentative only because the sample size is too large.',
    ],
    correct: 0,
    rationale:
      'Representativeness concerns who was included, and location selection systematically excludes identifiable groups. Option 1 confuses sample size with sampling method.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Discuss',
    text: 'Discuss why two historians may reach different conclusions from the same set of sources.',
    options: [
      'They may weight sources differently, apply different standards of reliability, infer causation differently or hold different concepts of what matters, so the disagreement is rational and must be resolved by argument rather than authority.',
      'Only one of them can be correct, because sources determine a single conclusion.',
      'They disagree because only one of them has read all the sources.',
      'They disagree only because the sources are contradictory.',
    ],
    correct: 0,
    rationale:
      'Interpretation involves inferential choices, so disagreement is expected and is adjudicated by reasoning. Option 1 wrongly asserts a deterministic relation between sources and conclusion, and option 2 treats contradiction as the sole cause of disagreement.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Critique',
    text: 'Critique the reasoning: "Employment in the region rose by 4% after the new factory opened, so the factory created the jobs."',
    options: [
      'The reasoning assumes causation from a before-and-after change without excluding other explanations such as a national recovery, relocation from elsewhere or a change in how employment was recorded.',
      'The reasoning is sound, because a rise followed by an opening indicates causation.',
      'The reasoning is sound, because 4% is a substantial increase.',
      'The reasoning is unsound only because the period examined is too short.',
    ],
    correct: 0,
    rationale:
      'Post hoc reasoning must exclude rival explanations before a causal claim is made. Option 1 treats sequence as sufficient and option 2 substitutes magnitude for justification.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate the claim that economic growth necessarily improves the lives of everyone in a country.',
    options: [
      'The claim is not justified, because aggregate growth can be concentrated in particular sectors or regions and can coincide with rising costs of housing, so distribution must be examined separately.',
      'The claim is justified, because a larger economy must raise every household income.',
      'The claim is justified, because growth is measured using household incomes.',
      'The claim is not justified only because growth is difficult to measure.',
    ],
    correct: 0,
    rationale:
      'National aggregates conceal distributional outcomes, which is why growth and welfare measures diverge. Option 1 incorrectly assumes a homogeneous population and option 2 misstates what growth measures include.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Argue',
    text: 'Argue whether a government should prioritise economic growth over environmental protection, and state one counterargument.',
    options: [
      'Growth raises incomes and employment, while the counterargument holds that irreversible ecological damage removes the natural capital on which the economy itself depends, so the trade-off is narrower than it first appears.',
      'Growth should always be prioritised, because environment follows economic development.',
      'Environment should always be prioritised, because economic growth is never beneficial.',
      'The two goals are entirely unrelated, so no trade-off exists.',
    ],
    correct: 0,
    rationale:
      'A reasoned argument must engage the genuine interdependence rather than posit a simple trade-off. Options 1 to 3 each assert an absolute and option 3 denies the interdependence that the evidence shows.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Justify',
    text: 'Justify why a map showing average income by administrative region can mislead about individual living standards.',
    options: [
      'Because regional averages conceal the distribution within the region, so a small number of very high incomes can raise an area mean while most residents remain poor.',
      'Because maps cannot represent numerical data accurately.',
      'Because income is not related to living standards.',
      'Because regional averages always overstate income.',
    ],
    correct: 0,
    rationale:
      'Aggregation conceals intra-regional distribution, which is the central danger of choropleth mapping. Option 1 asserts a technical impossibility, and option 3 makes an unsupportable universal claim about direction of bias.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Assess',
    text: 'Assess the usefulness of a consumer survey conducted by a company that intends to sell the product being surveyed.',
    options: [
      'It may be useful if the questions, sample and analysis are transparent and independently checkable, but the sponsor\'s commercial interest creates a real risk of selective reporting that must be assessed against the published methodology.',
      'It is automatically invalid, because commercial sponsorship always corrupts research.',
      'It is automatically reliable, because companies understand their own products.',
      'It is useful only if the results favour the sponsor.',
    ],
    correct: 0,
    rationale:
      'Assessability depends on transparency and scrutiny, while conflict of interest is a risk to be evaluated rather than an automatic disqualification. Option 1 treats conflict of interest as decisive in either direction.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Critique',
    text: 'Critique the argument: "The policy reduced unemployment by 5%, so it was a success."',
    options: [
      'The argument uses only an economic indicator, ignoring whether the jobs created were secure, adequately paid or accessible to those previously unemployed, so success must be assessed against stated policy objectives.',
      'The argument is sound, because a fall in unemployment is the only valid measure of policy success.',
      'The argument is unsound only because 5% is a small reduction.',
      'The argument is sound, because unemployment is easily measured.',
    ],
    correct: 0,
    rationale:
      'Evaluation requires measuring outcomes against stated objectives, not selecting one favourable indicator. Option 1 reduces a multidimensional evaluation to a single statistic.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the reliability of historical population figures taken from a colonial census.',
    options: [
      'They may undercount because people were misclassified or deliberately excluded, and categories were constructed to serve administrative purposes, so they require corroboration and critical reading of what was counted.',
      'They are completely unreliable because all historical figures are fabricated.',
      'They are reliable because censuses were conducted by trained officials.',
      'They are reliable only for countries without a colonial history.',
    ],
    correct: 0,
    rationale:
      'Colonial censuses were instruments of administration with known categories of exclusion, so their limits are specific and assessable. Option 1 rejects all historical evidence, and option 2 wrongly treats official provenance as a guarantee of accuracy.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Expose',
    text: 'Expose the flaw in the reasoning: "People in the poorest regions have the least access to the internet, so providing internet access there is the only way to reduce poverty."',
    options: [
      'The argument treats one contributing factor as the sole cause, ignoring education, healthcare, employment opportunities and governance, and so the intervention cannot be shown to reduce poverty on its own.',
      'The argument is sound, because internet access is the strongest single determinant of income.',
      'The argument is unsound only because the regions are too large to connect.',
      'The argument is sound, because other factors are outside government control.',
    ],
    correct: 0,
    rationale:
      'The inference commits a reduction to a single cause among several interacting ones. Option 1 asserts an unevidenced hierarchy of determinants, and option 2 substitutes a practical objection for the logical one.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the use of a correlation index between two variables as sole evidence for a historical or economic claim.',
    options: [
      'A correlation index quantifies co-variation only, so it cannot establish direction, mechanism or causation, and any causal claim built on it requires a stated mechanism and consideration of confounding variables.',
      'A correlation index establishes causation as long as the coefficient exceeds 0.5.',
      'A correlation index is sufficient because co-variation is itself proof of a relationship.',
      'A correlation index is unnecessary because qualitative evidence is always stronger.',
    ],
    correct: 0,
    rationale:
      'Correlation measures association, and causal inference requires additional warrant. Option 1 offers a spurious threshold rule, while option 2 treats association as proof and option 3 asserts an unwarranted hierarchy of evidence types.',
  }),

  // ---------------- Criterion D: Reflecting on impacts in real-world contexts (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 1,
    command: 'Describe',
    text: 'Describe one effect of building a new road through a rural area.',
    options: [
      'Vehicle access improves for residents and businesses, but farmland is fragmented and wildlife movement is disrupted.',
      'Only positive effects occur, because roads always benefit communities.',
      'Only negative effects occur, because roads always damage ecosystems.',
      'There is no effect, because rural roads already serve all needs.',
    ],
    correct: 0,
    rationale:
      'Infrastructure produces both benefits and costs, which is what Criterion D requires students to identify. Options 1 and 2 each assert an exclusively one-sided outcome.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Determine',
    text: 'Determine which action would most directly reduce household water consumption in a region facing water stress.',
    options: [
      'Fixing leaking distribution pipes, since lost treated water is eliminated before reaching any consumer.',
      'Building more reservoirs, since storage increases the amount available at any moment.',
      'Running public awareness campaigns about water use, since residents control most consumption.',
      'Subsidising larger household water tanks, since larger capacity reduces consumption.',
    ],
    correct: 0,
    rationale:
      'Distribution losses represent pure wastage and are addressed most cheaply at the source. Option 2 presupposes that water is available to store, and option 3 implies behaviour is the dominant component when physical losses often exceed household use.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Explain',
    text: 'Explain why the same development project may be welcomed by one community group and opposed by another.',
    options: [
      'Different groups hold different interests, values and exposures to the effects, so the same physical outcome can represent benefit, cost or threat depending on who bears it.',
      'One group is always right and the other is always mistaken.',
      'Opposition always indicates ignorance of the project\'s benefits.',
      'Both groups are necessarily acting in bad faith.',
    ],
    correct: 0,
    rationale:
      'Stakeholder positions reflect differential costs and benefits, not error or bad faith. Option 1 appeals to moral authority rather than analysis, and option 2 assumes opposition is always uninformed.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate a proposal to build a large shopping centre on the edge of a growing town.',
    options: [
      'The centre would create retail jobs and reduce pressure on existing high streets, but out-of-town retail increases car dependence, congestion and emissions, so transport provision and local employment conditions determine whether the benefits are realised locally.',
      'The proposal should proceed because retail growth is always beneficial to a town.',
      'The proposal should be rejected because retail development always reduces town-centre trade.',
      'The proposal should proceed because land on the edge of a town is always cheaper and always available.',
    ],
    correct: 0,
    rationale:
      'PEESEM evaluation requires weighing economic benefits against environmental costs with attention to where benefits land. Options 1 and 2 assert universal outcomes and option 3 assumes land availability without evidence.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Discuss',
    text: 'Discuss the ethical issues involved in relocating a community for a dam construction project.',
    options: [
      'Communities receive compensation and resettlement support, yet compensation cannot replace land, livelihood, ancestral attachment or social networks, so the project requires demonstration of necessity and genuine consultation rather than payment alone.',
      'Adequate financial compensation resolves the ethical issue in full.',
      'No ethical issue arises, because the project benefits a larger population.',
      'Ethical concerns arise only if the community resists the relocation.',
    ],
    correct: 0,
    rationale:
      'Ethical appraisal addresses non-monetary losses that compensation cannot restore. Option 1 treats the issue as purely financial and option 2 makes the presence of a dispute the criterion for ethical concern.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate a proposal to raise the minimum wage in a low-wage economy.',
    options: [
      'Higher wages raise incomes for low-paid workers but may raise firms\' costs, leading to reduced hours, automation or higher prices, so the outcome depends on market structure, bargaining power and the competitiveness of the sector.',
      'The proposal is wholly beneficial, because higher wages always increase employment.',
      'The proposal is wholly harmful, because higher wages always cause unemployment.',
      'The proposal has no effect on employment because wages and employment are unrelated.',
    ],
    correct: 0,
    rationale:
      'Employment responses depend on the elasticity of demand for labour and on the structure of the sector. Options 1 and 2 assert universal outcomes, and option 3 negates a fundamental market relationship.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate a proposal to ban single-use plastic bags in a coastal city with an established recycling system.',
    options: [
      'A ban reduces marine plastic and signals a norm change, but it shifts demand onto paper or cotton alternatives with higher production impacts, so the case depends on substituting genuinely lower-impact materials and on waste-management capacity.',
      'A ban has no environmental effect, because plastic bags are already recycled in this city.',
      'A ban is beneficial in every respect, because paper bags have no production impacts.',
      'A ban is harmful, because paper bags decompose more slowly than plastic in seawater.',
    ],
    correct: 0,
    rationale:
      'Substitution effects must be assessed rather than assumed, since alternatives carry their own impacts. Option 1 ignores substitution entirely and option 2 asserts an unsupported decomposition rate.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the impact of a government investing heavily in high-speed rail rather than in local bus services.',
    options: [
      'High-speed rail may improve long-distance connectivity and national cohesion, but capacity concentrated on trunk routes can divert funding from the bus networks that low-income and rural communities depend on, so the distributional effect decides the outcome.',
      'High-speed rail is always better, because it moves more people per hour than buses.',
      'High-speed rail is always worse, because buses are cheaper to operate.',
      'The two investments have identical effects on all communities.',
    ],
    correct: 0,
    rationale:
      'Investment choices redistribute accessibility across populations, which is the decisive consideration. Option 1 equates capacity with benefit and option 3 asserts distributional neutrality.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate a proposal for a new landfill site located near a low-income community.',
    options: [
      'The site may bring jobs and lower waste transport costs, but residents bear noise, odour, heavy vehicle traffic and long-term contamination risk, so fairness requires genuine consultation, monitoring commitments and an independent assessment before approval.',
      'The site should be approved because employment benefits outweigh all other considerations.',
      'The site should be rejected because any landfill near housing causes harm to residents.',
      'The site should be approved because locating it there is the cheapest option for the developer.',
    ],
    correct: 0,
    rationale:
      'Environmental justice requires that burdens are not concentrated on those with least political influence. Option 1 asserts benefits dominate without analysis and option 3 assumes any co-location is harmful.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the impact of automation on employment in a manufacturing region.',
    options: [
      'Automation displaces routine manual roles while creating technical and maintenance positions, so total jobs may fall in the short term but the skills profile changes, requiring retraining investment and regional diversification.',
      'Automation always increases total employment because it creates new industries.',
      'Automation always decreases total employment permanently, with no new roles created.',
      'Automation has no effect on employment, since technology does not affect labour demand.',
    ],
    correct: 0,
    rationale:
      'Technological change redistributes tasks and skills, which requires policy response rather than a single net conclusion. Options 1 and 2 assert universal outcomes and option 3 denies labour substitution entirely.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the claim that an international organisation should be able to compel member states to meet agreed environmental standards.',
    options: [
      'Enforcement improves reliability by preventing free-riding, but sovereignty concerns limit legitimate intervention, so effectiveness depends on transparency, graduated consequences and states retaining consent to the rules they have accepted.',
      'Enforcement is always legitimate, because agreement binds states absolutely in all circumstances.',
      'Enforcement is never legitimate, because states cannot be compelled by international bodies.',
      'Enforcement is unnecessary, because member states always comply voluntarily.',
    ],
    correct: 0,
    rationale:
      'Cooperative compliance regimes balance assurance against consent, which is the substantive governance question. Options 1 and 2 assert absolute powers and obligations that international law does not confer.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Reflect',
    text: 'Reflect on why an individual\'s contribution to an environmental issue is often treated as negligible, and explain why that reasoning is problematic.',
    options: [
      'Scale makes individual action appear insignificant beside systemic contributors, yet aggregation means many small contributions can shift demand and political pressure, and dismissing them removes the mechanism by which change becomes politically possible.',
      'Individual action is genuinely negligible, because only regulation produces change.',
      'Individual action is significant, because one person can determine national policy alone.',
      'Aggregation is irrelevant, because environmental impacts do not accumulate.',
    ],
    correct: 0,
    rationale:
      'The reasoning substitutes absolute scale for cumulative effect, which is a category error about mechanisms. Option 1 contradicts the demonstrated effect of collective behaviour change and option 3 denies accumulation.',
  }),
];

export default withIds(SUBJECT, items);
