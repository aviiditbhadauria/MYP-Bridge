import { q, withIds } from './question-builder.js';

const SUBJECT = 'Sciences';

const items = [
  // ---------------- Criterion A: Knowing and understanding (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'State',
    text: 'State the chemical symbol for the element sodium.',
    options: ['Na', 'S', 'So', 'N'],
    correct: 0,
    rationale:
      'The symbol Na derives from the Latin natrium, while S is sulfur, N is nitrogen and So is not an element symbol. Precise recall of notation is directly assessed in Criterion A.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Define',
    text: 'Define the term "force" as used in physics.',
    options: [
      'A push or pull upon an object, measured in newtons, arising from an interaction between two objects.',
      'The motion of an object from one position to another.',
      'The amount of matter contained within a body.',
      'The resistance offered by a surface to a moving object.',
    ],
    correct: 0,
    rationale:
      'A force is an interaction measured in newtons, not a motion or a property of a single object in isolation. Option 3 describes mass and option 4 describes friction, a single force type.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Describe',
    text: 'Describe what happens to the particles in a solid when it is heated until it melts.',
    options: [
      'The particles gain kinetic energy and overcome the forces holding them in fixed positions, so they can move past one another while remaining in close contact.',
      'The particles lose kinetic energy and become more tightly bonded to one another.',
      'The particles break into individual atoms with large gaps between them.',
      'The particles remain in fixed positions but vibrate more slowly as temperature rises.',
    ],
    correct: 0,
    rationale:
      'Melting requires particles to gain enough energy to overcome interparticle forces while staying close together. Option 3 describes vaporisation, and option 1 reverses the effect of heating on kinetic energy.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Identify',
    text: 'Identify the process by which green plants make glucose using light energy.',
    options: ['Photosynthesis', 'Respiration', 'Transpiration', 'Fermentation'],
    correct: 0,
    rationale:
      'Photosynthesis converts light energy into chemical energy stored in glucose. Option 1 releases energy from glucose, option 2 loses water vapour through stomata, and option 3 anaerobically breaks down sugars in the absence of oxygen.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Give an example',
    text: 'Give an example of a physical change rather than a chemical change.',
    options: [
      'Ice melting into liquid water, since the substance remains water and only its state changes.',
      'Iron rusting, since a new substance is formed.',
      'Burning a candle, since new substances are formed.',
      'Baking bread, since new substances are formed.',
    ],
    correct: 0,
    rationale:
      'A physical change alters state or form without producing a new substance. Options 1 to 3 all form new substances and are therefore chemical changes.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'Explain how a catalyst increases the rate of a chemical reaction without altering the net energy change.',
    options: [
      'It lowers the activation energy by providing an alternative reaction pathway.',
      'It increases the total kinetic energy of the reacting particles.',
      'It shifts the chemical equilibrium toward the product side.',
      'It reacts with reactants to increase the enthalpy change of the reaction.',
    ],
    correct: 0,
    rationale:
      'A catalyst acts strictly by lowering activation energy via an alternate mechanism. Option 2 confuses temperature with catalyst action, and option 4 would change the net energy change, which catalysts cannot do.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'Explain why a current-carrying wire placed in a magnetic field experiences a force.',
    options: [
      'A moving charge in a magnetic field experiences a force, and a current is a directed flow of such charges, so the force acts on the wire.',
      'The magnetic field attracts the metal of the wire regardless of the direction of current.',
      'The electrons in the wire collide with the magnetic field particles and slow down.',
      'The wire becomes magnetised and is attracted to the poles of the magnet.',
    ],
    correct: 0,
    rationale:
      'The motor effect arises from the force on moving charges in a field. Option 1 is the unmoving-particle case, option 2 has no basis, and option 4 describes induced magnetisation rather than the motor effect.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Describe',
    text: 'Describe how the structure of a DNA molecule relates to its function.',
    options: [
      'A double helix of complementary strands stores information in the sequence of bases, and the strands separate so each can be copied during replication.',
      'A single long chain of amino acids stores information and is copied directly before cell division.',
      'A double helix of identical strands allows both strands to be read simultaneously with no base pairing required.',
      'A single strand of identical bases is unwound and rebuilt in a different order each time a protein is required.',
    ],
    correct: 0,
    rationale:
      'Complementary base pairing underpins both information storage and accurate copying. Option 1 describes protein rather than DNA, option 2 removes the requirement for complementarity, and option 3 confuses the storage of information with the reading of RNA.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Outline',
    text: 'Outline the sequence of events that occurs during the water cycle from evaporation to precipitation.',
    options: [
      'Liquid water evaporates into vapour, rises and cools as it condenses into cloud droplets, droplets coalesce and grow, and fall to the surface as precipitation.',
      'Water vapour condenses on the ground, is absorbed by plants, and returns to the sea by transpiration only.',
      'Rain falls onto the sea, evaporates instantly and returns to the ground as snow.',
      'Water passes directly from the ocean to the atmosphere and back without passing through a cloud.',
    ],
    correct: 0,
    rationale:
      'Evaporation, condensation, coalescence and precipitation form the standard sequence. Option 1 omits the cloud stage and reverses the direction of the cycle, and option 2 has no evidential basis.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Explain',
    text: 'Explain why a metal conducts electricity whereas a covalent substance such as diamond does not.',
    options: [
      'Metal atoms release delocalised electrons that can move freely through the lattice and carry charge, whereas diamond has all its valence electrons bound in covalent bonds.',
      'Metal atoms contain more protons than covalent substances, so charge is transferred more readily.',
      'Diamond contains fewer electrons than metal, so fewer are available to carry charge.',
      'Metal bonds are stronger than covalent bonds, so electrons are released more easily.',
    ],
    correct: 0,
    rationale:
      'Conductivity depends on mobile charge carriers, and only metals provide delocalised electrons. Option 1 wrongly attributes charge to protons, and option 2 confuses bond strength with electron mobility.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Explain',
    text: 'Explain why the equilibrium position in a reversible reaction shifts toward the side that releases fewer moles of gas when the system is placed under increased pressure.',
    options: [
      'Increasing pressure reduces volume, and the equilibrium shifts to the side with fewer gas particles because this lowers the pressure opposing the change.',
      'Increased pressure raises the kinetic energy of every particle, so the exothermic side is favoured.',
      'Pressure has no effect because the equilibrium constant is unchanged by pressure.',
      'Increased pressure shifts the equilibrium toward whichever side contains the larger molecules.',
    ],
    correct: 0,
    rationale:
      'Le Chatelier reasoning applies because pressure is an external change, and the fewer-moles side has fewer particles to sustain pressure. Option 2 misattributes the shift to particle energy and option 3 confuses K with the equilibrium position.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Explain why the boiling point of a covalent substance is higher for a larger molecule than for a smaller molecule of similar structure.',
    options: [
      'Larger molecules have greater surface area and contain more electrons, so the intermolecular forces between molecules are stronger and require more energy to overcome.',
      'Larger molecules contain stronger covalent bonds within the molecule, so more energy is needed to separate them.',
      'Larger molecules have higher atomic masses, so the molecules move faster in the liquid and must be heated further.',
      'Larger molecules have more electrons to ionise, so they hold onto their electrons more tightly.',
    ],
    correct: 0,
    rationale:
      'Boiling overcomes intermolecular forces, not covalent bonds, and strength grows with contact area and polarisable electron clouds. Option 1 is the most common Criterion A error, confusing intra- and intermolecular bonding.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Give an example',
    text: 'Give an example of a chemical situation in which a limiting reagent limits the amount of product formed.',
    options: [
      'Burning magnesium in excess air, where the oxygen supply can be exhausted so that some magnesium remains unreacted.',
      'Adding a drop of indicator to a large volume of solution, where the indicator is fully consumed.',
      'Heating a beaker of water to boiling, where heat becomes the limiting factor.',
      'Mixing two miscible liquids in a measuring cylinder, where volume becomes the limiting factor.',
    ],
    correct: 0,
    rationale:
      'A limiting reagent is consumed first and caps the product yield, leaving excess reactant unreacted. Option 2 involves a reagent that is not being consumed to form a product, and option 1 misidentifies heat as a reagent.',
  }),

  // ---------------- Criterion B: Inquiring and designing (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 1,
    command: 'Identify',
    text: 'In an investigation of the effect of temperature on the rate of dissolution of sugar, identify the independent variable.',
    options: [
      'The temperature of the water',
      'The time taken for the sugar to dissolve',
      'The volume of water used',
      'The mass of sugar added',
    ],
    correct: 0,
    rationale:
      'The independent variable is the factor deliberately changed by the investigator. Option 1 is the dependent variable being measured, while options 2 and 3 must both be controlled for the test to be valid.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question is best formulated for investigating whether a plant grows faster in warm or in cool conditions?',
    options: [
      'How does the temperature of the growing environment affect the rate of growth of this species, with light, water and soil held constant?',
      'Is it true that plants grow faster in warm conditions?',
      'What is the effect of temperature on plants?',
      'Which is better for plant growth, warm or cool conditions?',
    ],
    correct: 0,
    rationale:
      'A testable inquiry question names the manipulated variable, states how the outcome is measured and identifies controlled variables. The remaining options are closed, leading or too vague to investigate systematically.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Formulate an inquiry question',
    text: 'A student wishes to test whether a plant fertiliser affects the mass of cress seedlings. Which inquiry question is most rigorous?',
    options: [
      'What effect does a change in fertiliser concentration have on the mean mass of cress seedlings grown under otherwise identical conditions?',
      'Does fertiliser make plants grow?',
      'Which fertiliser is best for plants?',
      'Is this fertiliser good for cress?',
    ],
    correct: 0,
    rationale:
      'Option 0 specifies the manipulated variable, the measured outcome and the controlled conditions, and it uses the mean to improve reliability. The alternatives cannot be answered with data.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Design',
    text: 'Design the control set-up required to show that light is necessary for photosynthesis.',
    options: [
      'Set up two identical plants with the same soil, water and temperature, keeping one in light and the other covered with an opaque box, then compare their stored starch after several hours.',
      'Set up two plants, one placed in a sealed bag of carbon dioxide and the other left open, then compare their growth.',
      'Set up one plant in a dark cupboard and compare its colour with a plant kept in a greenhouse.',
      'Set up two plants, one watered with distilled water and the other with soapy water, then compare their growth.',
    ],
    correct: 0,
    rationale:
      'A control must vary only the tested factor. Option 1 changes the gas supply rather than light, option 2 compares two light conditions without a valid test of necessity, and option 3 changes water quality.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Organize',
    text: 'Organise a sequence of steps that produces valid evidence for the effect of light intensity on the rate of photosynthesis.',
    options: [
      'Set a fixed distance lamp with a plant, measure the volume of oxygen collected per minute at several distances, keep temperature and carbon dioxide constant, and repeat each measurement.',
      'Place the plant in direct sunlight, measure once, and record the volume of gas produced.',
      'Measure the gas produced at several distances while also varying the room temperature and the time of measurement.',
      'Place three different plants at three distances and record which plant produced the most gas.',
    ],
    correct: 0,
    rationale:
      'Validity requires one manipulated variable, controlled conditions, replication and a clear dependent measure. Option 2 omits replication and option 3 confounds three variables at once.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Predict',
    text: 'A student doubles the concentration of a reactant in a reaction mixture. Predict the effect on the rate of the reaction, and justify the prediction.',
    options: [
      'The rate increases because more particles per unit volume leads to a greater frequency of successful collisions with sufficient energy to react.',
      'The rate decreases because the particles have less room to move and collide.',
      'The rate is unchanged because concentration affects only equilibrium position, not rate.',
      'The rate increases because the particles become hotter.',
    ],
    correct: 0,
    rationale:
      'Collision theory links rate to collision frequency and to the proportion with energy exceeding activation energy. Option 2 confuses rate with equilibrium and option 3 attributes the increase to temperature.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Examine',
    text: 'Examine the claim that a plant food labelled "plant food" can be used as fertiliser for any plant.',
    options: [
      'The claim is untenable because nutrient requirements differ between species, so a formulation optimised for one plant may supply excess of one nutrient and deficiency of another, causing poor growth.',
      'The claim is correct because all plants require the same mineral nutrients in the same proportions.',
      'The claim is correct as long as the product is applied in sufficient quantity.',
      'The claim is untenable only because plant foods expire after a fixed period.',
    ],
    correct: 0,
    rationale:
      'Nutrient ratios are species-specific, and excess of one mineral can inhibit the uptake of another. Option 1 asserts a universal requirement that does not hold across species.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Compare',
    text: 'Compare the reliability of two methods for measuring the rate of reaction between sodium bicarbonate solution and dilute acid.',
    options: [
      'Measuring the volume of carbon dioxide collected per unit time is more reliable than timing how long it takes for effervescence to stop, because the endpoint is subjective whereas a gas volume is directly recorded.',
      'Timing the disappearance of effervescence is more reliable, because it requires no apparatus.',
      'Both methods are equally reliable, because they measure the same reaction.',
      'Measuring gas volume is less reliable, because the gas must be collected and corrected for temperature.',
    ],
    correct: 0,
    rationale:
      'Reliability depends on the precision of the measured quantity and the presence of an identifiable endpoint. Option 1 removes the endpoint problem entirely and is therefore superior.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Prioritize',
    text: 'Four variables are proposed as affecting the rate of rusting of an iron nail: paint colour, the humidity of the air, the amount of oxygen and the length of the nail. Prioritise which to investigate first.',
    options: [
      'Humidity, because it can be varied safely and independently and is a known rate-limiting factor for corrosion.',
      'Paint colour, because it changes the rate at which the nail is struck by rain.',
      'Length of the nail, because surface area determines how much iron is available to react.',
      'Amount of oxygen, because oxygen cannot be varied at all during an investigation.',
    ],
    correct: 0,
    rationale:
      'Prioritisation requires testability, control and a plausible mechanism; option 0 satisfies all three. Option 3 is invalid because the amount of oxygen can readily be varied.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Analyse',
    text: 'An investigation into the effect of pH on enzyme activity produces a rate that rises then falls sharply. Analyse what this shape indicates about the enzyme.',
    options: [
      'The enzyme has an optimum pH at the peak, because ionisation of active-site groups alters the shape of the active site away from the optimum and reduces successful substrate binding.',
      'The enzyme is being consumed by the reaction, since rate should increase continuously with concentration.',
      'The measurements were taken at increasing temperature as well as pH, so the shape reflects a temperature effect.',
      'The enzyme has no optimum pH, since pH affects only the rate and never the structure of a protein.',
    ],
    correct: 0,
    rationale:
      'Enzymes are proteins whose active-site ionisation depends on pH, so activity is maximal at an optimum and falls on either side. Option 3 is a plausible competing explanation that must be excluded by controlling temperature.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Develop',
    text: 'Develop an investigation to determine whether a sample of river water is safe to drink, identifying at least three different types of test.',
    options: [
      'Test for pH, test for nitrates using test paper and a control, test for dissolved oxygen, and test for bacterial contamination, comparing each result against published safe drinking-water limits.',
      'Measure only the pH and confirm the water is safe if it is neutral, since pH is the only indicator of safety.',
      'Observe the water for cloudiness and record the result as evidence of potability.',
      'Compare the temperature of the sample with the surrounding air to infer its purity.',
    ],
    correct: 0,
    rationale:
      'Potability requires several independent criteria evaluated against published limits. Option 1 confuses a single property with overall safety, and options 2 and 3 rely on proxies with no scientific link to contamination.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Examine',
    text: 'Examine the claim that a single unblended photograph is sufficient evidence for or against a claim about air quality in a city.',
    options: [
      'The claim is untenable because a photograph records a single location, time and viewing angle and captures only what scatters light, so particulate concentration and pollutant identity require instruments with calibrated detection limits.',
      'The claim is justified, because photographs record everything present in the frame.',
      'The claim is justified, because visibility is a complete measure of air quality.',
      'The claim is untenable only because photographs cannot be taken outdoors.',
    ],
    correct: 0,
    rationale:
      'Visual range is one crude proxy for one pollutant class among many. Option 1 asserts that photography is exhaustive, and option 2 treats a single proxy as a complete measurement.',
  }),

  // ---------------- Criterion C: Communicating and thinking critically (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 1,
    command: 'Organize',
    text: 'Organize the components of a valid conclusion drawn from an experiment into a logical order.',
    options: [
      'State what was measured, state the pattern observed, explain that pattern using scientific reasoning, then state whether the data support the original prediction and identify any limitations.',
      'State the prediction, repeat the prediction, restate the prediction with different wording, then state a new prediction.',
      'State what the results mean, list the equipment used, describe the safety precautions, then state what was measured.',
      'State the hypothesis, state the hypothesis again in the past tense, state the hypothesis in the future tense, then conclude.',
    ],
    correct: 0,
    rationale:
      'A scientific conclusion must move from data to pattern to explanation before appraising the evidence. The remaining options either duplicate content or place equipment and safety, which belong in the method, inside the conclusion.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Discuss',
    text: 'Discuss why a scientific model is never a perfect copy of reality yet can still be useful.',
    options: [
      'Models are deliberately simplified to capture the relationships that matter for a purpose, so accuracy within that purpose is preserved even though detail is omitted.',
      'Models are always inaccurate and are therefore of no scientific value.',
      'Models are accurate only when they reproduce every detail of the real system.',
      'Models are useful because they are exact copies that replace the need for experiment.',
    ],
    correct: 0,
    rationale:
      'The utility of a model lies in appropriate simplification for a stated purpose. Option 1 overstates the status of models and option 3 confuses a model with the phenomenon itself.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 2,
    command: 'Comment',
    text: 'Comment on the statement that "more data always makes a scientific conclusion more reliable".',
    options: [
      'It is only partly true: a larger sample narrows random uncertainty, but it cannot remove systematic error, bias in the sampling method or an uncontrolled variable.',
      'It is entirely true, because random error is the only source of uncertainty in measurement.',
      'It is false, because small samples are always more representative than large ones.',
      'It is true only for qualitative observations and never for numerical measurements.',
    ],
    correct: 0,
    rationale:
      'Replication reduces random uncertainty but leaves systematic error untouched, which is a distinction Criterion C requires students to make. Option 1 wrongly reduces all uncertainty to random error.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Critique',
    text: 'Critique the use of a single unblended photograph as evidence that a factory emits no harmful gases.',
    options: [
      'A single photograph captures only one instant, one location and one viewing angle, so it cannot establish absence of emissions; timed measurements at several points with instruments are required.',
      'A single photograph is valid evidence provided it was taken in daylight.',
      'A single photograph is valid evidence provided the chimney is visible in the frame.',
      'A single photograph is invalid only because photographs cannot be dated.',
    ],
    correct: 0,
    rationale:
      'A photograph is qualitative, momentary and spatially limited, so absence of visible emissions is not evidence of their absence. Option 1 and option 2 treat visual capture as equivalent to instrumental measurement.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate the statement that scientific knowledge is always objective and free from cultural influence.',
    options: [
      'It is not fully objective, because which questions get funded and investigated is shaped by social, political and economic priorities, even though the testing of claims uses agreed shared methods.',
      'It is entirely objective, because scientific method removes all human judgement.',
      'It is not objective at all, because every scientific conclusion is a matter of opinion.',
      'It is entirely subjective, because no two scientists ever agree on the evidence.',
    ],
    correct: 0,
    rationale:
      'Method is shared and self-correcting, while research priorities and access to resources are socially determined. Option 2 replaces methodological rigour with the absence of judgement, and option 3 denies the empirical constraint entirely.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 3,
    command: 'Assess',
    text: 'Assess the reliability of a scientific claim published on a website with no author, date or references listed.',
    options: [
      'The claim is difficult to verify because there is no identifiable author, date or evidence to trace, so it cannot be checked against replicated findings.',
      'The claim is reliable, because publication on the open internet requires peer review.',
      'The claim is reliable, because scientific information is free for anyone to publish.',
      'The claim is difficult to verify only because the writing style is informal.',
    ],
    correct: 0,
    rationale:
      'Assessability depends on traceability: who made the claim, when, and on what evidence. Option 1 wrongly assumes all internet publication is peer reviewed, and option 2 mistakes presentation for reliability.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the strength of the inference drawn from a single plant germinating faster in a nutrient solution than in pure water.',
    options: [
      'The inference is weak because a single trial confounds nutrient effect with individual variation; replicated trials with several plants and a control are needed before generalising.',
      'The inference is strong, because the result was clear and repeatable by eye.',
      'The inference is strong, because the control eliminated all other variables.',
      'The inference is weak only because pure water was used as the control instead of distilled water.',
    ],
    correct: 0,
    rationale:
      'Replication across independent individuals is required before generalisation from one organism. Option 1 mistakes a single observation for a controlled, replicated finding.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the claim that because a plant grows larger when given extra water, water quantity is the main limiting factor for its growth.',
    options: [
      'The inference is not justified, because other factors such as light, carbon dioxide and mineral nutrients may also be limiting, and only testing each in turn identifies the true limiting factor.',
      'The inference is justified, because growth is always limited by the amount of water supplied.',
      'The inference is justified, because a plant cannot grow without water.',
      'The inference is not justified only because the plant species was not named.',
    ],
    correct: 0,
    rationale:
      'Liebig limiting-factor reasoning requires that the other factors are demonstrably in adequate supply. Option 1 confuses water being necessary with water being limiting.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 4,
    command: 'Compare',
    text: 'Compare the scientific status of the claim that plants need sunlight with the claim that plants need a specific wavelength of blue light.',
    options: [
      'Both are testable, but the first is supported by abundant replicated evidence across many species whereas the second is a narrower, more recent and less broadly replicated claim requiring more evidence.',
      'The first claim is science while the second is opinion.',
      'Both claims are equally well established because both concern light.',
      'The second claim is stronger because it is more specific, regardless of evidence.',
    ],
    correct: 0,
    rationale:
      'Specificity does not confer evidential weight; the breadth and replication of evidence determine status. Option 1 substitutes categories of speech for evidential assessment.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Critique',
    text: 'Critique the statement that "the greenhouse effect is entirely harmful", given that it keeps Earth at a habitable temperature.',
    options: [
      'The statement is incomplete because it presents one consequence in isolation; the natural greenhouse effect maintains a habitable temperature, while the enhanced greenhouse effect arises from human emissions and carries distinct consequences.',
      'The statement is correct, because any warming of the planet is necessarily harmful.',
      'The statement is incorrect only because the greenhouse effect was discovered recently.',
      'The statement is correct, because the greenhouse effect and global warming are identical processes.',
    ],
    correct: 0,
    rationale:
      'Criterion C requires separating natural from enhanced greenhouse effects and evaluating consequences in context. Option 1 conflates the natural effect with the enhanced one and option 3 offers a purely chronological objection.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Assess',
    text: 'Assess the limitations of using the atomic model in which atoms are shown as solid spheres.',
    options: [
      'The model misrepresents atoms as solid and indivisible, when in fact the nucleus occupies almost all the mass with mostly empty space, and the electrons are not arranged in fixed orbits.',
      'The model is limited only because the spheres are drawn too large on the page.',
      'The model is limited only because it does not show the chemical symbols of each element.',
      'The model has no limitations, because atoms are in fact solid spheres.',
    ],
    correct: 0,
    rationale:
      'A scientific model must be appraised against current evidence, and Dalton\'s solid sphere predates subatomic structure and the quantum model. Option 3 conflates presentational choice with scientific limitation.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'C',
    level: 5,
    command: 'Expose',
    text: 'Expose the reasoning weakness in the claim that "since 90% of the students in this class passed, 90% of all students nationally pass".',
    options: [
      'The claim generalises from a single non-randomly selected group to the whole population, so sampling bias and the small sample size make the projection unjustified.',
      'The claim is sound, because 90% is greater than 50%.',
      'The claim is unsound only because the class was taught by a different teacher.',
      'The claim is sound, because the result was obtained by a controlled experiment.',
    ],
    correct: 0,
    rationale:
      'Representativeness, not the size of the proportion, determines whether generalisation is justified. Option 1 treats a majority as proof, and option 3 mislabels a single-class result as experimental.',
  }),

  // ---------------- Criterion D: Applying science in real-world contexts (13) ----------------
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 1,
    command: 'Describe',
    text: 'Describe one everyday consequence of the properties of the noble gases.',
    options: [
      'Noble gases are unreactive, so they are used in protective atmospheres around welding and in low-energy lighting such as neon lamps.',
      'Noble gases are highly reactive, so they are used as fuels in rockets.',
      'Noble gases dissolve readily in water, so they are used to purify water supplies.',
      'Noble gases are strongly acidic, so they are used in cleaning products.',
    ],
    correct: 0,
    rationale:
      'The full outer electron shell of the noble gases makes them extremely unreactive, which is why they suit protective and illumination applications. Options 1 to 3 each attribute properties the group does not possess.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Determine',
    text: 'Determine which change would most reduce the rate of rusting on a steel bicycle frame left outdoors.',
    options: [
      'Applying a layer of paint that excludes both water and oxygen.',
      'Increasing the temperature of the surrounding air.',
      'Washing the frame with salt water.',
      'Placing the frame in direct sunlight each day.',
    ],
    correct: 0,
    rationale:
      'Rusting is an oxidation reaction requiring water and oxygen, so excluding both removes the reactants. Options 1 and 2 would accelerate corrosion, and option 3 adds an electrolyte that speeds it further.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 2,
    command: 'Explain',
    text: 'Explain why a metal spoon is not damaged by being left in a hot drink, whereas a plastic spoon may deform.',
    options: [
      'Metals have strong metallic bonding with a substantial energy requirement to break, while the weaker intermolecular forces in thermoplastics are overcome at lower temperatures.',
      'Metals are always colder than plastics at the same temperature.',
      'Metals absorb heat from the drink, whereas plastics do not.',
      'Plastics have no particles, whereas metals do.',
    ],
    correct: 0,
    rationale:
      'Deformation depends on the energy required to overcome the bonding present, and metallic bonds are far stronger than the intermolecular attractions in thermoplastics. Option 3 confuses capacity with heat transfer, and option 2 contradicts thermal equilibrium.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate the environmental impact of using plastic bottles for drinking water instead of glass bottles.',
    options: [
      'Glass requires more energy to manufacture and is heavier to transport, but is inert and fully recyclable repeatedly, whereas plastic uses fossil feedstock and forms persistent waste that may enter the food chain.',
      'Glass is better in every respect, since it has no disadvantages at all.',
      'Plastic is better in every respect, since it is lighter and stronger than glass.',
      'The two materials have identical environmental footprints because both are used for the same purpose.',
    ],
    correct: 0,
    rationale:
      'PEESEM evaluation requires weighing both options against criteria rather than declaring one universally superior. Option 1 is an assertion without evidence and option 3 assumes identical footprints from a shared function.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Discuss',
    text: 'Discuss the ethical issues raised by the use of a drug that has been tested on animals but not yet on humans.',
    options: [
      'There is a duty to minimise avoidable harm to animals while recognising that human trials expose unknown numbers of people to unknown harm, so the ethical balance must weigh predicted benefit against predictable animal suffering.',
      'Animal testing is always justified because it produces reliable results.',
      'Animal testing should be banned entirely because no scientific benefit can ever be obtained from it.',
      'There are no ethical issues, because scientific progress takes priority over all other considerations.',
    ],
    correct: 0,
    rationale:
      'Criterion D requires a balanced ethical appraisal rather than an absolute position. Option 1 and option 3 both take an unqualified stance that forecloses the trade-off the task demands.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 3,
    command: 'Evaluate',
    text: 'Evaluate a proposal to build a large thermal power station close to a residential area.',
    options: [
      'The proposal generates electricity but also releases carbon dioxide, produces ash and releases heated water, so economic and social benefits must be weighed against environmental impacts on health, climate and local amenity.',
      'The proposal should proceed because electricity generation always benefits everyone.',
      'The proposal should be rejected because power stations have no economic benefit.',
      'The proposal should proceed because the local residents have already consented to it.',
    ],
    correct: 0,
    rationale:
      'A Criterion D evaluation must address multiple PEESEM dimensions and weigh them. Option 1 asserts a universal benefit and option 3 substitutes prior consent for an assessment of impacts.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the use of a life-saving drug that was first developed for a rare condition, where the drug company charges a very high price because the patient population is small.',
    options: [
      'High development costs must be recovered from a small market, yet access depends on ability to pay, so ethical frameworks weigh intellectual property rights against avoidable loss of life and often propose licensing or public funding.',
      'Charging a high price is always ethical because the drug required substantial research investment.',
      'Charging a low price is always ethical because the drug company earns a profit regardless.',
      'The price is irrelevant, because drug availability and drug affordability are the same issue.',
    ],
    correct: 0,
    rationale:
      'PEESEM evaluation requires weighing the moral cost of denial against commercial realities and proposing a defensible compromise. Option 3 confuses availability with affordability, and options 1 and 2 both assert rather than weigh.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate a proposal to vaccinate all schoolchildren against a disease that affects mostly adults, given that a single outbreak had caused serious harm.',
    options: [
      'Widespread vaccination reduces transmission and protects vulnerable adults indirectly, but the benefit must be weighed against side effects, cost and the reduction in natural immunity for a small number of recipients.',
      'Vaccinating all children is correct because it eliminates the disease within one year.',
      'Vaccinating all children is unnecessary because adults alone can be protected by treatment.',
      'Vaccinating all children is unjust because the disease affects mostly adults.',
    ],
    correct: 0,
    rationale:
      'Herd-immunity reasoning and risk-benefit weighing are both required. Option 1 promises elimination within a fixed period, which no immunisation programme can guarantee.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Investigate',
    text: 'Investigate which PEESEM dimension is most likely to determine the outcome of a proposal to build a wind farm on a coastal headland.',
    options: [
      'The environmental dimension, because coastal habitats, bird migration routes and offshore views would be directly and unavoidably altered regardless of the energy produced.',
      'The moral dimension, because wind energy is morally superior to fossil fuel energy.',
      'The economic dimension, because the project is funded by a private company.',
      'The political dimension, because national governments control all energy policy.',
    ],
    correct: 0,
    rationale:
      'The dominant dimension is the one most directly and irreversibly affected by the specific proposal. Option 1 assumes moral or political uniformity that does not exist.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 4,
    command: 'Research',
    text: 'Research which evidence would be needed to support a scientific claim that a new fertiliser doubles crop yield.',
    options: [
      'Controlled replicated field trials across several sites and seasons with a no-fertiliser control, measuring yield per unit area and reporting the variation between replicates.',
      'One photograph of a healthy field treated with the fertiliser.',
      'The manufacturer\'s own promotional description of the product.',
      'Testimony from one farmer who used the product successfully.',
    ],
    correct: 0,
    rationale:
      'A doubling claim is quantitative, so it requires quantitative, replicated and controlled measurement with reported variation. Option 3 is a commercial assertion, and option 1 confuses appearance with yield.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate the sustainability of a community that meets all its energy needs from a single wind farm.',
    options: [
      'Output varies with wind speed and is intermittent, so without storage, diverse sources or imported supply the community will face regular shortfalls even though the resource is renewable and low in emissions.',
      'The approach is fully sustainable, because wind is a renewable resource.',
      'The approach is unsustainable only because wind turbines produce noise.',
      'The approach is sustainable only if the wind farm is built on land rather than at sea.',
    ],
    correct: 0,
    rationale:
      'Renewability does not guarantee availability, so reliability and intermittency must be assessed alongside emissions. Option 1 conflates the resource type with system reliability.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Reflect',
    text: 'Reflect on why scientific literacy, rather than scientific expertise, is the appropriate preparation for most citizens making decisions about scientific applications.',
    options: [
      'Because most citizens will not practise science but will vote on, buy, or regulate technologies that depend on it, so they need to evaluate evidence and risk without producing it themselves.',
      'Because scientific expertise is unnecessary for understanding evidence.',
      'Because citizens should rely entirely on experts and form no view of their own.',
      'Because scientific literacy is easier to acquire than scientific expertise.',
    ],
    correct: 0,
    rationale:
      'Criterion D reflection concerns the public role in science governance and democratic accountability. Option 2 excludes citizens from evaluation entirely, and option 1 mistakes relative difficulty for relevance.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'D',
    level: 5,
    command: 'Evaluate',
    text: 'Evaluate a proposal to require all vehicles in a city centre to be electric in order to improve air quality.',
    options: [
      'Electric vehicles eliminate tailpipe emissions in the city centre but shift pollution to electricity generation and to tyre and brake wear, so the benefit depends on the cleanliness of the local grid and the vehicle fleet turnover.',
      'The proposal is wholly beneficial because electric vehicles produce no pollution of any kind.',
      'The proposal is wholly harmful because electric vehicles are more expensive to manufacture.',
      'The proposal has no effect on air quality because all vehicles emit similar amounts.',
    ],
    correct: 0,
    rationale:
      'PEESEM evaluation must relocate the emissions rather than assume they vanish. Option 1 states an absolute that is contradicted by life-cycle evidence, and option 3 contradicts the stated aim.',
  }),
];

export default withIds(SUBJECT, items);
