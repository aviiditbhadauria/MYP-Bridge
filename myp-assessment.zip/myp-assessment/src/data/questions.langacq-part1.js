import { q, withIds } from './question-builder.js';

const SUBJECT = 'Language Acquisition';

const items = [
  // ---------------- Criterion A: Knowing and understanding (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'Define',
    text: 'Define the term "receptive skills" in a language acquisition context.',
    options: [
      'The ability to understand spoken or written language when the focus is on meaning rather than on producing a response.',
      'The ability to produce spoken or written language accurately and appropriately.',
      'The ability to recognise and apply correct spelling conventions.',
      'The ability to hold a sustained conversation without an interpreter.',
    ],
    correct: 0,
    rationale:
      'Receptive skills are input-focused and comprise listening and reading. Option 1 defines productive skills, option 2 isolates a writing sub-skill, and option 3 describes a benchmark generally attributed to the higher phases.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 1,
    command: 'State',
    text: 'State the difference between the receptive and the productive vocabulary of a learner.',
    options: [
      'The receptive vocabulary is the set of words a learner understands, while the productive vocabulary is the smaller set the learner can also use accurately in speech or writing.',
      'The two vocabularies are identical for every learner.',
      'The receptive vocabulary is always larger than everything the learner has ever encountered.',
      'The productive vocabulary includes words the learner has only ever heard.',
    ],
    correct: 0,
    rationale:
      'Recognition precedes production, so receptive vocabulary generally exceeds productive vocabulary. Option 1 wrongly treats production as requiring no accuracy, and option 2 collapses the distinction.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Define',
    text: 'Define "register" in the context of language learning.',
    options: [
      'The set of vocabulary and structures appropriate to a particular situation, such as formal or informal, teacher or friend.',
      'The total number of words a learner has memorised.',
      'The order in which grammar points are introduced in a syllabus.',
      'The record a learner keeps of new vocabulary.',
    ],
    correct: 0,
    rationale:
      'Register concerns the functional appropriateness of language for a context. Option 1 confuses vocabulary size with register, and option 2 confuses syllabus design with language use.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Identify',
    text: 'Identify the term for the mixing of two languages within a single utterance by a bilingual speaker.',
    options: [
      'Code-switching.',
      'Code-breaking.',
      'Transliteration.',
      'Calque.',
    ],
    correct: 0,
    rationale:
      'Code-switching is the alternation between languages within discourse. Option 2 concerns rendering one script in another script system, and option 3 describes a loan translation.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 2,
    command: 'Give an example',
    text: 'Give an example of a lexical item held only in the receptive sense.',
    options: [
      'A word encountered in a news report that the learner can understand in context but cannot yet use in speech.',
      'A greeting the learner uses correctly with a classmate.',
      'A verb the learner conjugates accurately in the past tense.',
      'A phrase the learner writes without error in an email.',
    ],
    correct: 0,
    rationale:
      'Understanding without usable production is the defining feature of a receptive-only item. Options 1 to 3 all demonstrate productive control of the language.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'Explain why a learner may understand a sentence yet fail to produce it.',
    options: [
      'Because comprehension draws on recognition of stored language patterns, whereas production additionally requires recall of the form, selection of an appropriate register and organisation within working memory limits.',
      'Because understanding and producing language are a single skill at differing difficulty.',
      'Because learners only understand what they are required to produce.',
      'Because production requires a higher phase than comprehension for every aspect of the language.',
    ],
    correct: 0,
    rationale:
      'Receptive and productive processing draw on partly distinct systems, so they develop at different rates. Option 1 collapses the two processes, and option 2 asserts an absolute phase ceiling that does not exist.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Describe',
    text: 'Describe how a learner\'s productive vocabulary develops relative to their receptive vocabulary over a sustained period of study.',
    options: [
      'Both grow, but productive vocabulary grows more slowly and lags behind receptive vocabulary, so the gap narrows only gradually as accuracy develops.',
      'The two grow at exactly the same rate, so the gap closes immediately.',
      'Receptive vocabulary stops growing once productive vocabulary begins.',
      'Productive vocabulary grows faster because speaking is easier than listening.',
    ],
    correct: 0,
    rationale:
      'The receptive-productive gap is a well-documented feature of second-language development. Option 1 wrongly assumes parallel growth rates, and option 2 asserts an unsupported ceiling.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 3,
    command: 'Explain',
    text: 'Explain why loanwords are often difficult for a learner to recognise as being of foreign origin.',
    options: [
      'Because frequent borrowing integrates them phonologically and orthographically into the receiving language, so they look and sound like native items to a learner.',
      'Because loanwords are always spelled only in the original language.',
      'Because loanwords are never pronounced differently from native words.',
      'Because loanwords are defined by being written rather than spoken.',
    ],
    correct: 0,
    rationale:
      'Phonological and orthographic integration is precisely what makes loanwords unidentifiable to learners. Option 1 is false because most loanwords are adapted, and option 2 confuses origin with pronunciation.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Outline',
    text: 'Outline the features of an interaction expected at MYP Language Acquisition Phase 6.',
    options: [
      'Participants sustain spontaneous exchanges on familiar and some unfamiliar topics, contribute opinions as well as information, adjust to the partner, and use a range of structures with occasional persistent errors that rarely impede meaning.',
      'Participants read a prepared dialogue aloud with no hesitation and no capacity to respond to unexpected questions.',
      'Participants exchange single words and gestures without any sentence-level structure.',
      'Participants conduct rapid error-free debate on abstract political issues.',
    ],
    correct: 0,
    rationale:
      'Phase 6 targets consolidation, meaning fluency, range and interactional skill with residual error. Option 1 describes performance below phase expectations, and option 2 describes performance well above them.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 4,
    command: 'Define',
    text: 'Define "interference" as it applies to a bilingual learner.',
    options: [
      'The influence of patterns and sounds from one language on the learner\'s use or comprehension of another.',
      'The deliberate refusal to use a learner\'s strongest language in class.',
      'The reduction of vocabulary to a single shared set across both languages.',
      'The interference of background noise with spoken comprehension.',
    ],
    correct: 0,
    rationale:
      'Interference refers to cross-linguistic influence, which may be facilitative as well as disruptive. Option 1 conflates this with a pedagogical decision, and option 2 misidentifies a phonological phenomenon.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Explain why a learner\'s productive vocabulary is often narrower in conversation than in written work on the same topic.',
    options: [
      'Because spoken production imposes real-time processing and interactional demands alongside formulation, whereas writing permits revision and time to select precise lexical items.',
      'Because written text always requires a higher phase than speech for every aspect of the language.',
      'Because learners generally prefer writing to speaking.',
      'Because conversation restricts vocabulary to topics covered in lessons.',
    ],
    correct: 0,
    rationale:
      'The real-time demands of interaction constrain retrieval, which is why written work tends to be lexically more precise. Option 1 asserts a uniform phase gap across skills that does not exist.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'A',
    level: 5,
    command: 'Explain',
    text: 'Explain why two speakers of the same language may disagree about whether an expression is grammatically acceptable.',
    options: [
      'Because grammar includes both shared formal patterns and community-specific usage conventions, so a form may be well attested in one community and judged non-standard in another.',
      'Because one of the two speakers must be mistaken whenever disagreement occurs.',
      'Because grammatical acceptability depends only on dictionary entries.',
      'Because grammaticality is fixed at a given moment and cannot change.',
    ],
    correct: 0,
    rationale:
      'Descriptive grammar recognises systematic variation within a language, so disagreement concerns community norms rather than error. Option 1 appeals to authority over evidence, and option 2 denies the possibility of change.',
  }),

  // ---------------- Criterion B: Inquiring and designing (12) ----------------
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 1,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question is best formulated for investigating how often students use the target language outside lessons?',
    options: [
      'How frequently, in what settings and with which partners do students use the target language outside scheduled lessons?',
      'Do students enjoy using the target language?',
      'Is the target language better than the school\'s first language?',
      'How many students are in each class?',
    ],
    correct: 0,
    rationale:
      'A researchable question specifies frequency, context and participants, producing measurable evidence. Option 0 requires no measurement to answer, and option 2 asks a preference question rather than a usage one.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question best supports an investigation into the effect of vocabulary games on retention?',
    options: [
      'Does weekly use of retrieval games change the proportion of target vocabulary recalled in a delayed test compared with weekly list review?',
      'Are vocabulary games enjoyable for students?',
      'Which game is the best game?',
      'Do students remember words better now than before?',
    ],
    correct: 0,
    rationale:
      'Option 0 states an intervention, a comparison condition and an outcome with a delay, which allows retention to be distinguished from immediate recall. The alternatives ask preference questions or lack any comparison.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 2,
    command: 'Identify',
    text: 'Identify the principal difference between a bilingual person and a foreign language learner.',
    options: [
      'A bilingual person uses two or more languages in everyday life and develops them across natural contexts, whereas a foreign language learner typically encounters the target language mainly in the classroom.',
      'A bilingual person speaks more words in total than a foreign language learner.',
      'A bilingual person never makes errors in either language.',
      'A foreign language learner always begins at Phase 1.',
    ],
    correct: 0,
    rationale:
      'The distinction concerns context, exposure and language function rather than total quantity of speech. Option 1 wrongly equates bilingualism with size, and option 2 asserts error-free performance in both languages.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Design',
    text: 'Design a method for recording how accurately learners produce irregular verbs of the target language in spontaneous speech.',
    options: [
      'Record an unscripted spoken task, transcribe it, tally each verb form against the target norm, and report the proportion correct alongside the context of each error.',
      'Ask students to write the conjugations on a worksheet and mark them.',
      'Ask students to state the conjugation rule aloud.',
      'Time how long each student takes to answer one question about tense.',
    ],
    correct: 0,
    rationale:
      'Spontaneous unscripted speech is the relevant performance context, and the context of each error is needed to interpret accuracy. Option 1 measures the stated rule rather than its spontaneous use, and option 2 measures speed on a single item.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Organize',
    text: 'Organize a plan for raising a class\'s productive vocabulary over one term.',
    options: [
      'Select a target set of high-frequency items, embed them in modelled contexts, require repeated personal use in speaking and writing, test retention after a delay, and revise the set based on the results.',
      'Issue a vocabulary list each week and move on to the next list.',
      'Translate the textbook vocabulary into learners\' first language and ask them to memorise it.',
      'Study the entire target vocabulary from the first day of term before any use.',
    ],
    correct: 0,
    rationale:
      'Effective planning pairs high-frequency targets with repeated use, delayed testing and revision. Option 1 relies on recognition alone and never requires production, and option 2 front-loads an unprioritised list.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Compare',
    text: 'Compare the effect of reading a graded text and holding a conversation on productive language development.',
    options: [
      'Reading supplies accurate model input at a controlled difficulty level, while conversation forces rapid retrieval and interactional adjustment, so the two develop different aspects and are complementary.',
      'Reading develops speaking, because written models are necessarily spoken aloud.',
      'Conversation is ineffective, because accuracy can only be developed from writing.',
      'The two are identical, because input and output are the same process.',
    ],
    correct: 0,
    rationale:
      'Reading and conversation place different demands on the learner and develop complementary skills. Option 1 wrongly treats reading as inherently oral, and option 2 denies the input-to-output progression in its strongest form.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 3,
    command: 'Formulate an inquiry question',
    text: 'Which inquiry question would best investigate the effect of correction strategy during speaking tasks?',
    options: [
      'How do the timing and the type of correction affect the number of uncorrected errors in the same learner\'s speech six weeks later?',
      'Which correction strategy is the strictest?',
      'Do students enjoy being corrected?',
      'How many errors do students make in total?',
    ],
    correct: 0,
    rationale:
      'Option 0 isolates correction as a variable, defines the outcome and includes a delayed measure that distinguishes acquisition from momentary accuracy. The alternatives rank strategies or measure preference without comparison.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Analyse',
    text: 'Analyse why many hours of exposure to the target language do not by themselves produce fluency.',
    options: [
      'Because fluency depends on interactive processing and automatic retrieval in real time rather than on input volume, so hours without interaction may yield recognition without usable production.',
      'Because exposure must always be combined with written examinations.',
      'Because fluency is determined solely by the learner\'s age at first exposure.',
      'Because input produces only receptive skills and productive skills are unlearnable.',
    ],
    correct: 0,
    rationale:
      'Input volume is necessary but not sufficient, since processing demands determine whether language becomes automatic. Option 1 substitutes an unrelated assessment category for the missing variable, and option 2 denies a well-documented relationship.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Evaluate',
    text: 'Evaluate the practice of correcting every error a learner makes during a speaking task.',
    options: [
      'Frequent correction interrupts communication and may prompt learners to avoid risk-taking, so delayed focused correction on selected features is generally more productive, though immediate correction suits some features such as a misused taught structure.',
      'Immediate correction of every error is always the most effective strategy.',
      'Correction should never be given, because learners always improve independently.',
      'Correction is effective only for written work.',
    ],
    correct: 0,
    rationale:
      'Correction must be weighed against the risk of suppressing communication. Option 1 asserts universality without reference to interactional cost, and option 2 removes correction entirely rather than calibrating it.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 4,
    command: 'Prioritize',
    text: 'A class at Phase 3 needs to improve listening comprehension of authentic recordings. Which priority is most appropriate?',
    options: [
      'Establishing the length of audio the class can currently follow, then selecting recordings just above that level with support such as transcripts or pre-teaching of key vocabulary.',
      'Requiring students to watch an unedited news broadcast with no support.',
      'Testing whether students can repeat the recording word for word.',
      'Giving longer passages at a lower level for the whole term.',
    ],
    correct: 0,
    rationale:
      'Level calibration combined with scaffolded exposure addresses the actual bottleneck. Option 1 sets an unachievable demand for the current phase, and option 2 confuses listening comprehension with transcription.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Develop',
    text: 'Develop an inquiry design for testing whether a vocabulary app improves retention over a term.',
    options: [
      'Assign the app to half the class and a paper-based review schedule to the other half, give both groups the same item list, test both after six weeks on unseen items, and report the difference with attainment before the study recorded as a baseline.',
      'Give the whole class the app and ask whether they feel they have improved.',
      'Give the whole class the app and compare the class average with the previous year\'s class average.',
      'Let students choose whether to use the app, then test those who chose to use it.',
    ],
    correct: 0,
    rationale:
      'Random allocation, a comparison group, an equivalent item set and a baseline address selection and maturation threats. Option 1 compares unmatched cohorts, and option 2 allows self-selection into the treatment condition.',
  }),
  q({
    subject: SUBJECT,
    criterion: 'B',
    level: 5,
    command: 'Examine',
    text: 'Examine the claim that translating every new word into learners\' first language is the most effective vocabulary instruction.',
    options: [
      'The claim is undermined by evidence that vocabulary is retained better when taught with images, actions and context in the target language, since a translation supplies a form without building a usable meaning network.',
      'The claim is justified, because translation always produces retention.',
      'The claim is justified, because learners share a single first language.',
      'The claim is undermined only because dictionaries are unavailable in some regions.',
    ],
    correct: 0,
    rationale:
      'Dual coding and contextual elaboration strengthen the memory network more than a form-only pairing. Option 1 asserts an absolute retention guarantee, and option 2 assumes a uniform learner profile.',
  }),
];

export default withIds(SUBJECT, items);
