import mathStandard from './questions.math-standard.js';
import mathExtended from './questions.math-extended.js';
import sciences from './questions.sciences.js';
import langLit from './questions.langlit.js';
import indSoc from './questions.indsoc.js';
import langAcq from './questions.langacq.js';

export const QUESTION_BANK = [
  ...mathStandard,
  ...mathExtended,
  ...sciences,
  ...langLit,
  ...indSoc,
  ...langAcq,
];

/** Expected shape of the authored bank, asserted by the seeder. */
export const EXPECTED = Object.freeze({
  total: 300,
  per_subject: 50,
  criteria: ['A', 'B', 'C', 'D'],
  per_criterion: 75,
});

/**
 * Throws if the authored bank has drifted from the specification: wrong total,
 * uneven subject or criterion spread, duplicate ids, or a malformed question.
 */
export function validateQuestions(bank = QUESTION_BANK) {
  const errors = [];
  const ids = new Set();

  bank.forEach((q, index) => {
    const label = q?.id ?? `index ${index}`;
    for (const field of [
      'id',
      'subject_group',
      'target_criterion',
      'command_term',
      'question_text',
      'rubric_rationale',
    ]) {
      if (typeof q?.[field] !== 'string' || q[field].trim() === '') {
        errors.push(`${label}: missing or empty "${field}"`);
      }
    }
    if (ids.has(q?.id)) errors.push(`${label}: duplicate question id`);
    ids.add(q?.id);

    if (!Number.isInteger(q?.myp_phase_level) || q.myp_phase_level < 1 || q.myp_phase_level > 5) {
      errors.push(`${label}: myp_phase_level must be an integer from 1 to 5`);
    }
    if (!Array.isArray(q?.options) || q.options.length !== 4) {
      errors.push(`${label}: options must be an array of exactly 4 strings`);
    } else if (new Set(q.options).size !== 4) {
      errors.push(`${label}: options must be distinct`);
    }
    if (!Number.isInteger(q?.correct_option_index) || q.correct_option_index < 0 || q.correct_option_index > 3) {
      errors.push(`${label}: correct_option_index must be 0, 1, 2 or 3`);
    }
  });

  if (bank.length !== EXPECTED.total) {
    errors.push(`expected ${EXPECTED.total} questions, found ${bank.length}`);
  }

  const bySubject = new Map();
  const byCriterion = new Map();
  for (const q of bank) {
    bySubject.set(q.subject_group, (bySubject.get(q.subject_group) ?? 0) + 1);
    byCriterion.set(q.target_criterion, (byCriterion.get(q.target_criterion) ?? 0) + 1);
  }
  for (const [subject, n] of bySubject) {
    if (n !== EXPECTED.per_subject) {
      errors.push(`${subject}: expected ${EXPECTED.per_subject} questions, found ${n}`);
    }
  }
  for (const criterion of EXPECTED.criteria) {
    const n = byCriterion.get(criterion) ?? 0;
    if (n !== EXPECTED.per_criterion) {
      errors.push(`Criterion ${criterion}: expected ${EXPECTED.per_criterion} questions, found ${n}`);
    }
  }

  if (errors.length) {
    throw new Error(`Question bank validation failed:\n  - ${errors.join('\n  - ')}`);
  }
  return bank.length;
}

export default QUESTION_BANK;
