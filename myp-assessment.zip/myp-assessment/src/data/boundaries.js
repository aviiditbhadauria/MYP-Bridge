/**
 * Subject-bound grade boundaries and multi-board equivalency matrix.
 *
 * Two boundary profiles exist because IB MYP Mathematics (Extended) sets its
 * achievement levels against a higher raw-mark expectation than the Standard
 * profile. Every other subject group in this platform maps onto the Standard
 * profile.
 *
 * Percentages are stored as inclusive integer bounds so the boundary set is
 * exact and machine-checkable; `toGrade()` never has to guess from a float.
 */

export const PROFILE = {
  STANDARD: 'standard',
  EXTENDED: 'extended',
};

/** Subject groups exposed by the Subject Selector dropdown, in syllabus order. */
export const SUBJECT_GROUPS = [
  {
    id: 'Mathematics (Standard)',
    short: 'Math Std',
    profile: PROFILE.STANDARD,
    myp_codes: ['Year 4', 'Year 5'],
    note: 'IB MYP Mathematics Standard course, Years 4 and 5.',
  },
  {
    id: 'Mathematics (Extended)',
    short: 'Math Ext',
    profile: PROFILE.EXTENDED,
    myp_codes: ['Year 6', 'Year 7'],
    note: 'IB MYP Mathematics Extended course, Years 6 and 7. Higher raw-mark expectation per level.',
  },
  {
    id: 'Sciences',
    short: 'Sciences',
    profile: PROFILE.STANDARD,
    myp_codes: ['Integrated Science', 'Physics', 'Chemistry', 'Biology'],
    note: 'IB MYP Sciences: integrated, or discrete Physics / Chemistry / Biology.',
  },
  {
    id: 'Language & Literature',
    short: 'LangLit',
    profile: PROFILE.STANDARD,
    myp_codes: ['Language A', 'Language B', 'Literature'],
    note: 'IB MYP Language & Literature, including Literature courses.',
  },
  {
    id: 'Individuals & Societies',
    short: 'IndSoc',
    profile: PROFILE.STANDARD,
    myp_codes: ['Business', 'Geography', 'History', 'Psychology', 'Digital Design'],
    note: 'IB MYP Individuals & Societies: history, geography, business, psychology, digital design.',
  },
  {
    id: 'Language Acquisition',
    short: 'LangAcq',
    profile: PROFILE.STANDARD,
    myp_codes: ['Phases 1-6', 'Phases 7-10'],
    note: 'IB MYP Language Acquisition, covering Phases 1-10. Phase 1-6 supported.',
  },
];

/**
 * Per-grade boundary table.
 * `min`/`max` are the raw-mark percentage bounds for the Standard profile.
 * `extendedMin`/`extendedMax` apply to Mathematics (Extended).
 * `igcse`, `cbse`, `icse`, `stateBoard` drive the equivalency matrix.
 */
export const GRADE_BOUNDARIES = [
  {
    grade: 8,
    min: 88,
    max: 100,
    extendedMin: 82,
    extendedMax: 100,
    igcse: 'A* (9)',
    cbse: 'A1 (91% - 100%)',
    icse: '95% - 100%',
    stateBoard: '93% - 100% (Top Distinction)',
    band: 'High proficiency',
    criterionBand: 'Consistently demonstrated',
  },
  {
    grade: 7,
    min: 76,
    max: 87,
    extendedMin: 71,
    extendedMax: 81,
    igcse: 'A* / A (8)',
    cbse: 'A1 (81% - 90%)',
    icse: '88% - 94%',
    stateBoard: '85% - 92%',
    band: 'Good proficiency',
    criterionBand: 'Very good',
  },
  {
    grade: 6,
    min: 64,
    max: 75,
    extendedMin: 60,
    extendedMax: 70,
    igcse: 'B (7)',
    cbse: 'A2 (71% - 80%)',
    icse: '78% - 87%',
    stateBoard: '75% - 84%',
    band: 'Adequate proficiency',
    criterionBand: 'Good',
  },
  {
    grade: 5,
    min: 52,
    max: 63,
    extendedMin: 48,
    extendedMax: 59,
    igcse: 'C (6)',
    cbse: 'B1 (61% - 70%)',
    icse: '68% - 77%',
    stateBoard: '65% - 74%',
    band: 'Moderate proficiency',
    criterionBand: 'Moderate',
  },
  {
    grade: 4,
    min: 40,
    max: 51,
    extendedMin: 36,
    extendedMax: 47,
    igcse: 'D / E (4-5)',
    cbse: 'B2 (51% - 60%)',
    icse: '55% - 67%',
    stateBoard: '55% - 64%',
    band: 'Limited proficiency',
    criterionBand: 'Limited',
  },
  {
    grade: 3,
    min: 28,
    max: 39,
    extendedMin: 25,
    extendedMax: 35,
    igcse: 'F (3)',
    cbse: 'C1 (41% - 50%)',
    icse: '45% - 54%',
    stateBoard: '45% - 54%',
    band: 'Minimal proficiency',
    criterionBand: 'Some',
  },
  {
    grade: 2,
    min: 15,
    max: 27,
    extendedMin: 12,
    extendedMax: 24,
    igcse: 'G (2)',
    cbse: 'C2 (33% - 40%)',
    icse: '33% - 44%',
    stateBoard: '35% - 44%',
    band: 'Very limited proficiency',
    criterionBand: 'Minimal',
  },
  {
    grade: 1,
    min: 0,
    max: 14,
    extendedMin: 0,
    extendedMax: 11,
    igcse: 'U (1)',
    cbse: 'E (Below 33%)',
    icse: 'Below 33%',
    stateBoard: 'Below 35% (Fail)',
    band: 'Very limited proficiency',
    criterionBand: 'Very limited',
  },
];

/**
 * MYP grade descriptors. `focus` is the subject-facing application clause that
 * distinguishes a grade 7 from a grade 8 in a way a mark alone cannot.
 */
export const GRADE_DESCRIPTORS = {
  'Mathematics (Standard)': {
    8: 'Consistently applies mathematical concepts to unfamiliar, multi-step problems and selects an efficient strategy independently, justifying each step with precise algebraic or geometric reasoning.',
    7: 'Applies mathematical concepts to familiar and some unfamiliar contexts, choosing appropriate strategies and showing sound reasoning with occasional lapses in rigour.',
    6: 'Applies mathematical concepts in familiar contexts, selecting strategies from a taught repertoire with a generally consistent method and adequate justification.',
    5: 'Applies mathematical concepts in familiar contexts with partial success; reasoning is traceable but incomplete, and some notation or process errors occur.',
    4: 'Applies a limited range of mathematical concepts in familiar contexts, showing partial reasoning that is frequently interrupted by procedural gaps.',
    3: 'Demonstrates some mathematical understanding; applies concepts to a narrow range of simple contexts with repeated error patterns.',
    2: 'Demonstrates minimal mathematical understanding; applies isolated concepts with limited success and little supporting reasoning.',
    1: 'Demonstrates very limited mathematical understanding; rarely applies concepts and relies almost entirely on teacher direction.',
  },
  'Mathematics (Extended)': {
    8: 'As Grade 8 Standard, and additionally manipulates higher-degree algebra, trigonometric functions and formal proof techniques across compound multi-step problems with no scaffolded prompts.',
    7: 'As Grade 7 Standard, and additionally applies extended techniques such as trigonometric identities, logarithmic/exponential modelling and vector reasoning to most problems independently.',
    6: 'As Grade 6 Standard, and additionally selects between competing extended strategies and completes routine extended problems with consistent accuracy.',
    5: 'As Grade 5 Standard, and additionally demonstrates partial command of extended techniques, with conceptual gaps visible in modelling and manipulation.',
    4: 'As Grade 4 Standard, and additionally recognises extended techniques in worked examples but cannot reliably deploy them unaided.',
    3: 'As Grade 3 Standard, with sporadic recognition of extended notation and techniques.',
    2: 'As Grade 2 Standard, with almost no independent use of extended techniques.',
    1: 'As Grade 1 Standard, dependent on direct instruction for all extended content.',
  },
  Sciences: {
    8: 'Consistently demonstrates a strong understanding of key scientific concepts and applies them across a wide range of complex contexts, evaluating implications using PEESEM factors.',
    7: 'Demonstrates a strong understanding of key scientific concepts and applies them in a range of contexts, evaluating at least some implications of scientific solutions.',
    6: 'Demonstrates a reasonably good understanding of key scientific concepts and applies them in familiar contexts such as the local environment.',
    5: 'Demonstrates partial understanding of key scientific concepts and applies them in some familiar contexts with limited success.',
    4: 'Demonstrates limited understanding of key scientific concepts and applies them to a limited range of contexts with limited success.',
    3: 'Demonstrates some understanding of key scientific concepts and applies them to a narrow range of contexts, with limited success.',
    2: 'Demonstrates minimal understanding of key scientific concepts and rarely applies them beyond a single familiar context.',
    1: 'Demonstrates very limited understanding of key scientific concepts and applies them only when directly prompted.',
  },
  'Language & Literature': {
    8: 'Applies sophisticated stylistic and structural techniques to a range of text types and media, critically evaluating how language, content and context shape meaning and reader position.',
    7: 'Applies effective stylistic and structural techniques to most text types, critically evaluating how language and content shape meaning with occasional gaps in analytical depth.',
    6: 'Applies appropriate stylistic and structural techniques in familiar text types, demonstrating a sound grasp of how language, content and context interact.',
    5: 'Applies stylistic and structural techniques inconsistently, producing partially analytical responses supported by relevant textual evidence.',
    4: 'Applies a limited range of stylistic and structural techniques, producing descriptive rather than analytical responses with thin textual support.',
    3: 'Identifies basic stylistic features and offers limited analysis, with textual evidence only loosely connected to the response.',
    2: 'Identifies an occasional stylistic feature; analysis is minimal and largely paraphrased rather than interpreted.',
    1: 'Demonstrates very limited analysis of language, content or context and offers little or no textual evidence.',
  },
  'Individuals & Societies': {
    8: 'Engages with sources and concepts critically and with rigour, weighing perspectives and evaluating the impact of human activity across political, economic, environmental, social, ethical and moral dimensions.',
    7: 'Engages with sources and concepts critically, weighing perspectives and evaluating human activity across most PEESEM dimensions with occasional gaps in evidence.',
    6: 'Engages with sources and concepts with some critical perspective, weighing perspectives and evaluating human activity in familiar local and global contexts.',
    5: 'Engages with sources and concepts with limited critical perspective, showing partial ability to weigh perspectives and evaluate impacts.',
    4: 'Engages with sources and concepts with a limited range of critical perspectives and shows partial ability to evaluate impacts.',
    3: 'Engages with sources with minimal critical perspective and rarely weighs perspectives or evaluates impacts.',
    2: 'Engages with sources descriptively and demonstrates minimal ability to weigh perspectives or evaluate impacts.',
    1: 'Demonstrates very limited engagement with sources and almost no evaluation of perspectives or impacts.',
  },
  'Language Acquisition': {
    8: 'Understands a wide range of authentic texts and communicates with high accuracy, controlling a broad range of vocabulary, grammar and register, correcting most errors independently.',
    7: 'Understands a range of authentic texts and communicates with good accuracy, controlling substantial vocabulary and grammar, correcting most significant errors.',
    6: 'Understands a range of texts and communicates with reasonable accuracy, controlling taught vocabulary and grammar structures.',
    5: 'Understands a limited range of texts and communicates with partial accuracy, controlling taught structures with noticeable errors.',
    4: 'Understands simple texts and communicates with limited accuracy, relying heavily on taught structures and high scaffolding.',
    3: 'Understands simple texts on familiar topics and communicates with limited success, often resorting to memorised phrases.',
    2: 'Understands isolated words and short familiar phrases; communication is highly scaffolded and often inaccurate.',
    1: 'Demonstrates very limited receptive and productive ability; relies entirely on highly scaffolded support.',
  },
};

const byGrade = new Map(GRADE_BOUNDARIES.map((b) => [b.grade, b]));

export function resolveSubject(subjectId) {
  return (
    SUBJECT_GROUPS.find((s) => s.id === subjectId) ||
    SUBJECT_GROUPS.find((s) => s.short === subjectId) ||
    null
  );
}

/** Returns the full boundary + equivalency row for a grade under a subject. */
export function gradeRow(subjectId, grade) {
  const subject = resolveSubject(subjectId);
  const base = byGrade.get(Number(grade));
  if (!base) return null;
  const extended = subject?.profile === PROFILE.EXTENDED;
  const min = extended ? base.extendedMin : base.min;
  const max = extended ? base.extendedMax : base.max;
  return {
    grade: base.grade,
    profile: subject?.profile ?? PROFILE.STANDARD,
    percentMin: min,
    percentMax: max,
    percentRange: `${min}% - ${max}%`,
    igcse: base.igcse,
    cbse: base.cbse,
    icse: base.icse,
    stateBoard: base.stateBoard,
    band: base.band,
    criterionBand: base.criterionBand,
    descriptor:
      GRADE_DESCRIPTORS[subject?.id ?? 'Sciences']?.[base.grade] ?? '',
  };
}

/** Full 8-row matrix for a subject, ordered Grade 8 down to Grade 1. */
export function equivalencyMatrix(subjectId) {
  return [8, 7, 6, 5, 4, 3, 2, 1].map((g) => gradeRow(subjectId, g));
}

/** Reverse lookup: raw percentage -> MYP grade 1-8 for the subject's profile. */
export function toGrade(subjectId, percent) {
  const subject = resolveSubject(subjectId);
  const extended = subject?.profile === PROFILE.EXTENDED;
  const p = Math.max(0, Math.min(100, Number(percent)));
  for (const b of GRADE_BOUNDARIES) {
    const min = extended ? b.extendedMin : b.min;
    const max = extended ? b.extendedMax : b.max;
    if (p >= min && p <= max) return b.grade;
  }
  return p >= 82 ? 8 : 1;
}

/** Midpoint percentage for a grade, used to pre-position the slider. */
export function gradeMidpoint(subjectId, grade) {
  const row = gradeRow(subjectId, grade);
  if (!row) return 0;
  return Math.round((row.percentMin + row.percentMax) / 2);
}

/**
 * Raw-mark percentage a slider value implies, clamped to the grade's band so
 * the displayed percentage can never contradict the equivalency table.
 */
export function percentForGrade(subjectId, grade) {
  return gradeMidpoint(subjectId, grade);
}
