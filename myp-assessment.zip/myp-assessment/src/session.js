/**
 * Server-issued identity.
 *
 * Practice streaks must be server-side with no manual toggles, so the client is
 * given a signed, httpOnly session cookie on first contact and never supplies
 * its own user id. An explicit `x-myp-user` header is honoured only for local
 * tooling and integration tests.
 */
import { randomUUID, createHmac, timingSafeEqual } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const SECRET_PATH = resolve(here, '..', 'data', '.session-secret');
const COOKIE_NAME = 'myp_session';
const MAX_AGE_MS = 1000 * 60 * 60 * 24 * 365 * 2;

let secret = null;

function loadSecret() {
  if (secret) return secret;
  if (process.env.MYP_SESSION_SECRET) {
    secret = Buffer.from(process.env.MYP_SESSION_SECRET, 'utf8');
    return secret;
  }
  try {
    if (existsSync(SECRET_PATH)) {
      secret = Buffer.from(readFileSync(SECRET_PATH, 'utf8').trim(), 'hex');
      return secret;
    }
    secret = randomUUID().replace(/-/g, '');
    mkdirSync(dirname(SECRET_PATH), { recursive: true });
    writeFileSync(SECRET_PATH, secret, { mode: 0o600 });
    return secret;
  } catch {
    secret = randomUUID().replace(/-/g, '');
    return secret;
  }
}

function sign(userId) {
  return createHmac('sha256', loadSecret()).update(userId).digest('hex');
}

function verify(userId, mac) {
  if (!userId || !mac) return false;
  const expected = sign(userId);
  const a = Buffer.from(mac, 'utf8');
  const b = Buffer.from(expected, 'utf8');
  return a.length === b.length && timingSafeEqual(a, b);
}

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const k = part.slice(0, idx).trim();
    const v = part.slice(idx + 1).trim();
    if (k) out[k] = decodeURIComponent(v);
  }
  return out;
}

export function issueSession(res, userId = `usr_${randomUUID().slice(0, 8)}`) {
  const mac = sign(userId);
  res.cookie(COOKIE_NAME, `${userId}.${mac}`, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: MAX_AGE_MS,
  });
  return userId;
}

/** Attaches `req.userId` to every request, minting a session when absent. */
export function sessionMiddleware(req, res, next) {
  const header = req.headers['x-myp-user'];
  if (typeof header === 'string' && /^usr_[A-Za-z0-9_-]{1,32}$/.test(header)) {
    req.userId = header;
    return next();
  }

  const cookies = parseCookies(req.headers.cookie || '');
  const raw = cookies[COOKIE_NAME];
  if (raw && raw.includes('.')) {
    const idx = raw.lastIndexOf('.');
    const userId = raw.slice(0, idx);
    const mac = raw.slice(idx + 1);
    if (verify(userId, mac)) {
      req.userId = userId;
      return next();
    }
  }

  req.userId = issueSession(res);
  return next();
}

/** Best-effort local timezone offset in minutes east of UTC. */
export function resolveTimezoneOffset(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  if (!req_safeRange(n)) return 0;
  return Math.trunc(n);
}

function req_safeRange(n) {
  return n >= -14 * 60 && n <= 14 * 60;
}

export { COOKIE_NAME };
