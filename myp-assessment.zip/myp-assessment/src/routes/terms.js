import { Router } from 'express';
import { getDb } from '../db.js';
import { SUBJECT_GROUPS } from '../data/boundaries.js';

const router = Router();

function toResult(row, query) {
  return {
    term: row.term,
    category: row.category,
    subject_group: row.subject_group,
    criterion_association: row.criterion_association,
    formal_definition: row.formal_definition,
    myp_context_example: row.myp_context_example,
    related_terms: row.related_terms ? JSON.parse(row.related_terms) : [],
    ...(query === 'evaluate' || row.term === 'Evaluate'
      ? {}
      : { id: row.id }),
  };
}

function limitOf(value, fallback = 25, max = 100) {
  const n = Number.parseInt(value, 10);
  if (!Number.isFinite(n) || n < 1) return fallback;
  return Math.min(n, max);
}

/**
 * British and American spellings of the same command term both occur in MYP
 * coursework, so a query is expanded to its -ise/-ize and -yse/-yze variants
 * before it reaches SQL.
 */
function spellingVariants(raw) {
  const out = new Set([raw]);
  const lower = raw.toLowerCase();
  const swap = (s) =>
    s.replace(/ise\b/g, 'ize').replace(/isation\b/g, 'ization').replace(/yse\b/g, 'yze');
  for (const candidate of [swap(lower)]) {
    if (candidate !== lower) out.add(candidate);
  }
  for (const candidate of [...out]) {
    out.add(candidate.replace(/ize\b/g, 'ise').replace(/ization\b/g, 'isation').replace(/yze\b/g, 'yse'));
  }
  return [...out].filter(Boolean);
}

const escapeLike = (s) => s.replace(/[%_]/g, '');

/**
 * GET /api/v1/terms/search?q=evaluate
 * Exact matches rank first, then prefix matches, then infix matches. Searches
 * the term, related terms, formal definition and MYP context example.
 */
router.get('/terms/search', (req, res) => {
  const db = getDb();
  const raw = String(req.query.q ?? '').trim();
  const limit = limitOf(req.query.limit);

  if (!raw) {
    return res.status(400).json({
      status: 'error',
      message: 'Query parameter q is required, for example /api/v1/terms/search?q=evaluate',
    });
  }

  const variants = spellingVariants(raw).map(escapeLike);
  // One pair of binds per variant, reused across every LIKE in the statement.
  const likeBinds = variants.map((v) => `%${v}%`);
  const prefixBinds = variants.map((v) => `${v}%`);

  const primary = escapeLike(raw.toLowerCase());
  const primaryLike = `%${primary}%`;
  const primaryPrefix = `${primary}%`;

  // 5 rank placeholders, then 4 per variant in the WHERE clause, then LIMIT.
  const rankBinds = [raw, primaryPrefix, primaryLike, primaryLike, primaryLike];
  const whereBinds = variants.flatMap((v) => Array(4).fill(`%${v}%`));
  const whereClause = variants
    .map(
      () =>
        `(LOWER(term) LIKE ? OR LOWER(related_terms) LIKE ? OR LOWER(formal_definition) LIKE ? OR LOWER(myp_context_example) LIKE ?)`,
    )
    .join(' OR ');

  const rows = db
    .prepare(
      `SELECT *,
              CASE
                WHEN LOWER(term) = LOWER(?)              THEN 0
                WHEN LOWER(term) LIKE LOWER(?)          THEN 1
                WHEN LOWER(related_terms) LIKE LOWER(?)  THEN 2
                WHEN LOWER(formal_definition) LIKE LOWER(?) THEN 3
                WHEN LOWER(myp_context_example) LIKE LOWER(?) THEN 4
                ELSE 5
              END AS rank
       FROM key_terms
       WHERE ${whereClause}
       ORDER BY rank, term
       LIMIT ?`,
    )
    .all(...rankBinds, ...whereBinds, limit);

  // Fold duplicate rows produced by overlapping spelling variants.
  const seen = new Set();
  const deduped = rows.filter((row) => {
    const key = row.id ?? row.term.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const term = deduped;

  res.json({
    status: 'success',
    query: raw,
    count: term.length,
    results: term.map((row) => ({
      term: row.term,
      category: row.category,
      subject_group: row.subject_group,
      criterion_association: row.criterion_association,
      formal_definition: row.formal_definition,
      myp_context_example: row.myp_context_example,
      related_terms: row.related_terms ? JSON.parse(row.related_terms) : [],
      id: row.id,
    })),
  });
});

/** GET /api/v1/terms - browse or filter the whole glossary. */
router.get('/terms', (req, res) => {
  const db = getDb();
  const where = [];
  const params = {};

  if (req.query.subject_group) {
    where.push('subject_group = :subject_group');
    params.subject_group = String(req.query.subject_group);
  }
  if (req.query.category) {
    where.push('category = :category');
    params.category = String(req.query.category);
  }
  if (req.query.criterion) {
    where.push('criterion_association = :criterion');
    params.criterion = String(req.query.criterion).toUpperCase();
  }
  if (req.query.command_term) {
    where.push("category = 'Command Term' AND term = :command_term");
    params.command_term = String(req.query.command_term);
  }

  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const limit = limitOf(req.query.limit, 200, 500);
  const total = db
    .prepare(`SELECT COUNT(*) AS n FROM key_terms ${clause}`)
    .get(params).n;

  const rows = db
    .prepare(
      `SELECT * FROM key_terms ${clause} ORDER BY category, term LIMIT :limit`,
    )
    .all({ ...params, limit });

  res.json({
    status: 'success',
    count: rows.length,
    total,
    data: rows.map((row) => toResult(row, '')),
  });
});

/** GET /api/v1/terms/categories - the category index for filter controls. */
router.get('/terms/categories', (_req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT category, COUNT(*) AS count FROM key_terms
       GROUP BY category ORDER BY category`,
    )
    .all();
  const subjects = db
    .prepare(
      `SELECT subject_group, COUNT(*) AS count FROM key_terms
       GROUP BY subject_group ORDER BY subject_group`,
    )
    .all();
  res.json({ status: 'success', data: { categories: rows, subject_groups: subjects } });
});

/** GET /api/v1/terms/:term - exact lookup. */
router.get('/terms/:term', (req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM key_terms WHERE LOWER(term) = LOWER(?)')
    .get(String(req.params.term));
  if (!row) {
    return res.status(404).json({ status: 'error', message: 'Term not found.' });
  }
  res.json({ status: 'success', data: toResult(row, req.query.q) });
});

export default router;
