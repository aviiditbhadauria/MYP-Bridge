import { Router } from 'express';
import { getDb } from '../db.js';
import { resolveTimezoneOffset } from '../session.js';

const router = Router();

/**
 * Milliseconds in one local calendar day, computed from the wall-clock offset
 * rather than from fixed 24-hour blocks, so daylight-saving transitions and
 * half-hour zones cannot desynchronise the ledger.
 */
function localDayStartMs(timestampMs, tzOffsetMinutes) {
  return timestampMs + tzOffsetMinutes * 60_000;
}

function localDayIndex(timestampMs, tzOffsetMinutes) {
  return Math.floor(localDayStartMs(timestampMs, tzOffsetMinutes) / 86_400_000);
}

function isoFromIndex(dayIndex, tzOffsetMinutes) {
  return new Date(dayIndex * 86_400_000 - tzOffsetMinutes * 60_000).toISOString();
}

function emptyLedgerRow(nowIso) {
  return {
    user_id: null,
    current_streak: 0,
    longest_streak: 0,
    last_activity_timestamp: nowIso,
    timezone_offset: 0,
  };
}

/**
 * Applies the automated practice-streak algorithm and persists the result.
 *
 *  delta_days === 0  activity already logged today, streak maintained
 *  delta_days === 1  consecutive day, streak incremented and longest updated
 *  delta_days  >  1  a day was missed, streak resets to 1
 *
 * @param {number} [atMs] Optional activity instant. Defaults to now; the history
 *   replay endpoint passes an earlier timestamp to exercise the algorithm.
 * @returns {{user_id:string,current_streak:number,longest_streak:number,
 *   streak_active_today:boolean,status_message:string,
 *   days_since_last_activity:number|null,last_activity_timestamp:string}}
 */
export function registerAttempt(db, userId, rawTimezoneOffset, atMs = Date.now()) {
  const tzOffset = resolveTimezoneOffset(rawTimezoneOffset);
  const now = new Date(atMs);
  const nowIso = now.toISOString();

  const existing = db
    .prepare('SELECT * FROM user_streaks WHERE user_id = ?')
    .get(userId);

  if (!existing) {
    db.prepare(
      `INSERT INTO user_streaks
         (user_id, current_streak, longest_streak, last_activity_timestamp, timezone_offset)
       VALUES (?, 1, 1, ?, ?)`,
    ).run(userId, nowIso, tzOffset);
    return {
      user_id: userId,
      current_streak: 1,
      longest_streak: 1,
      streak_active_today: true,
      status_message: 'Streak started. Practice logged for today.',
      days_since_last_activity: null,
      last_activity_timestamp: nowIso,
    };
  }

  // Honour the client's zone on first sight of it, then trust the stored zone so
  // that a device clock change cannot silently award a free day.
  const storedOffset = existing.timezone_offset;
  const effectiveOffset = storedOffset === 0 ? tzOffset : storedOffset;

  const lastMs = Date.parse(existing.last_activity_timestamp);
  const deltaDays =
    localDayIndex(now.getTime(), effectiveOffset) - localDayIndex(lastMs, effectiveOffset);

  let currentStreak;
  let statusMessage;

  if (deltaDays <= 0) {
    currentStreak = existing.current_streak;
    statusMessage =
      deltaDays < 0
        ? 'Clock or timezone change detected. Streak preserved without penalty.'
        : `Streak maintained for ${currentStreak} consecutive days.`;
  } else if (deltaDays === 1) {
    currentStreak = existing.current_streak + 1;
    statusMessage = `Streak maintained for ${currentStreak} consecutive days.`;
  } else {
    currentStreak = 1;
    statusMessage = `Streak reset after ${deltaDays} days of inactivity. Practice logged for today.`;
  }

  const longestStreak = Math.max(existing.longest_streak, currentStreak);

  db.prepare(
    `UPDATE user_streaks
     SET current_streak = ?, longest_streak = ?, last_activity_timestamp = ?, timezone_offset = ?
     WHERE user_id = ?`,
  ).run(currentStreak, longestStreak, nowIso, effectiveOffset, userId);

  return {
    user_id: userId,
    current_streak: currentStreak,
    longest_streak: longestStreak,
    streak_active_today: true,
    status_message: statusMessage,
    days_since_last_activity: deltaDays,
    last_activity_timestamp: nowIso,
  };
}

function readLedger(db, userId) {
  const row = db
    .prepare('SELECT * FROM user_streaks WHERE user_id = ?')
    .get(userId);
  if (!row) return null;
  return row;
}

/** GET /api/v1/streak - read-only status for the signed-in user. */
router.get('/streak', (req, res) => {
  const db = getDb();
  const tzOffset = resolveTimezoneOffset(req.query.timezone_offset);
  const row = readLedger(db, req.userId);

  if (!row) {
    return res.json({
      status: 'success',
      data: {
        user_id: req.userId,
        current_streak: 0,
        longest_streak: 0,
        streak_active_today: false,
        status_message: 'No practice logged yet. Submit an answer to start a streak.',
        days_since_last_activity: null,
        last_activity_timestamp: null,
      },
    });
  }

  const effectiveOffset = row.timezone_offset === 0 ? tzOffset : row.timezone_offset;
  const lastMs = Date.parse(row.last_activity_timestamp);
  const deltaDays =
    localDayIndex(Date.now(), effectiveOffset) - localDayIndex(lastMs, effectiveOffset);
  const activeToday = deltaDays <= 0;

  const lifetime = db
    .prepare(
      `SELECT COUNT(*) AS attempts,
              COALESCE(SUM(is_correct), 0) AS correct,
              COALESCE(SUM(CASE WHEN phase_level >= 4 THEN 1 ELSE 0 END), 0) AS advanced
       FROM practice_attempts WHERE user_id = ?`,
    )
    .get(req.userId);

  res.json({
    status: 'success',
    data: {
      user_id: row.user_id,
      current_streak: row.current_streak,
      longest_streak: row.longest_streak,
      streak_active_today: activeToday,
      status_message: activeToday
        ? `Streak maintained for ${row.current_streak} consecutive days.`
        : 'No practice logged today. Submit an answer to keep the streak alive.',
      days_since_last_activity: deltaDays,
      last_activity_timestamp: row.last_activity_timestamp,
      last_activity_local_date: isoFromIndex(
        localDayIndex(lastMs, effectiveOffset),
        effectiveOffset,
      ).slice(0, 10),
      timezone_offset: row.timezone_offset,
      totals: {
        attempts: lifetime.attempts,
        correct: lifetime.correct,
        advanced_phase_attempts: lifetime.advanced,
        accuracy_percent:
          lifetime.attempts > 0
            ? Number(((lifetime.correct / lifetime.attempts) * 100).toFixed(1))
            : null,
      },
    },
  });
});

/** POST /api/v1/streak/verify - the submission endpoint from the spec. */
router.post('/streak/verify', (req, res) => {
  const db = getDb();
  const streak = registerAttempt(db, req.userId, req.body?.timezone_offset);
  res.json({ status: 'success', data: streak, streak });
});

/**
 * POST /api/v1/streak/history
 * Replays the ledger against a supplied day sequence so each branch of the
 * streak algorithm can be exercised without waiting for real days to pass.
 *
 * The replay runs in a namespaced ledger id (`hist_<user>`) rather than the
 * caller's own row, because deleting a ledger row that has practice sessions
 * attached would violate the foreign key and destroy real attempt history.
 */
router.post('/streak/history', (req, res) => {
  const db = getDb();
  const tzOffset = resolveTimezoneOffset(req.body?.timezone_offset);
  const days = Array.isArray(req.body?.days) ? req.body.days : null;
  if (!days?.length) {
    return res.status(400).json({
      status: 'error',
      message: 'days must be a non-empty array of YYYY-MM-DD strings.',
    });
  }

  const userId = `hist_${req.userId}`;
  db.prepare('DELETE FROM user_streaks WHERE user_id = ?').run(userId);

  // Each day is simply handed to the production algorithm at that instant: the
  // first call takes the no-prior-activity branch and seeds the ledger, and each
  // later call advances last_activity_timestamp on its own.
  const trace = days.map((day) => {
    const atMs = Date.parse(`${String(day).slice(0, 10)}T12:00:00.000Z`);
    return {
      local_date: String(day).slice(0, 10),
      ...registerAttempt(db, userId, tzOffset, atMs),
    };
  });

  const final = readLedger(db, userId);
  db.prepare('DELETE FROM user_streaks WHERE user_id = ?').run(userId);

  res.json({
    status: 'success',
    data: {
      user_id: userId,
      trace,
      final: final
        ? {
            current_streak: final.current_streak,
            longest_streak: final.longest_streak,
          }
        : null,
    },
  });
});

export default router;
export { readLedger, emptyLedgerRow };
