/**
 * Subject Guides and classroom-context API.
 *
 * Purely additive: the guides payload is authored JSON, validated at import time
 * and served read-only, so this module touches no existing table or route.
 *
 *   GET /api/v1/guides                  index of guides and dialogues
 *   GET /api/v1/guides/:id              one full guide
 *   GET /api/v1/guides/dialogue         classroom discussion transcripts
 *   GET /api/v1/guides/dialogue/:id     one transcript with resolved term links
 */
import { Router } from 'express';
import {
  BAND_KEYS,
  classroomDialogues,
  findDialogue,
  findGuide,
  guideSummaries,
  turnText,
  validateGuides,
} from '../data/subject_guides.js';
import keyTerms from '../data/terms.index.js';

const router = Router();

// Fail fast at boot rather than serving a malformed panel.
validateGuides();

const glossaryIndex = new Map(keyTerms.map((t) => [t.term.toLowerCase(), t]));

/** Attaches plain text and resolved glossary records to a transcript. */
function hydrateDialogue(dialogue) {
  return {
    ...dialogue,
    turns: dialogue.turns.map((turn) => ({
      ...turn,
      text: turnText(turn),
      segments: turn.segments.map((segment) =>
        segment.type === 'term'
          ? { ...segment, glossary_term: resolveTerm(segment.term) }
          : segment,
      ),
    })),
    term_map: dialogue.term_map.map((entry) => ({
      ...entry,
      glossary_term: resolveTerm(entry.term),
    })),
  };
}

/** Resolves a term anchor to its glossary record, or a null placeholder. */
function resolveTerm(term) {
  const hit = glossaryIndex.get(String(term).toLowerCase());
  if (!hit) return null;
  return {
    term: hit.term,
    category: hit.category,
    subject_group: hit.subject_group,
    criterion_association: hit.criterion_association,
    formal_definition: hit.formal_definition,
    myp_context_example: hit.myp_context_example,
    related_terms: hit.related_terms ?? [],
  };
}

router.get('/guides', (_req, res) => {
  res.json({
    status: 'success',
    count: guideSummaries().length,
    score_bands: BAND_KEYS,
    guides: guideSummaries(),
    dialogues: classroomDialogues.map((d) => ({
      id: d.id,
      title: d.title,
      year_group: d.year_group,
      // Authoritative subject-group association. The client matches on this
      // rather than inferring intent from display titles.
      guide_ids: d.guide_ids ?? [],
      subjects: d.subjects,
      criteria_demonstrated: d.criteria_demonstrated,
      turn_count: d.turns.length,
      term_count: d.term_map.length,
    })),
  });
});

/**
 * Classroom transcripts. Kept above /guides/:id so that "dialogue" is not
 * swallowed as a guide id.
 */
router.get('/guides/dialogue', (req, res) => {
  const id = req.query.id;
  if (id) {
    const single = findDialogue(id);
    if (!single) {
      return res.status(404).json({
        status: 'error',
        message: `Dialogue "${id}" not found.`,
        data: { valid_dialogues: classroomDialogues.map((d) => d.id) },
      });
    }
    return res.json({ status: 'success', data: hydrateDialogue(single) });
  }

  res.json({
    status: 'success',
    count: classroomDialogues.length,
    data: classroomDialogues.map(hydrateDialogue),
  });
});

router.get('/guides/dialogue/:id', (req, res) => {
  const dialogue = findDialogue(req.params.id);
  if (!dialogue) {
    return res.status(404).json({
      status: 'error',
      message: `Dialogue "${req.params.id}" not found.`,
      data: { valid_dialogues: classroomDialogues.map((d) => d.id) },
    });
  }
  res.json({ status: 'success', data: hydrateDialogue(dialogue) });
});

router.get('/guides/:id', (req, res) => {
  const guide = findGuide(req.params.id);
  if (!guide) {
    return res.status(404).json({
      status: 'error',
      message: `Subject guide "${req.params.id}" not found.`,
      data: { valid_guides: guideSummaries().map((g) => g.id) },
    });
  }

  res.json({
    status: 'success',
    data: {
      ...guide,
      score_bands: BAND_KEYS,
      criteria: guide.criteria.map((criterion) => ({
        ...criterion,
        terms: (criterion.term_anchors ?? []).map(resolveTerm).filter(Boolean),
      })),
    },
  });
});

export default router;
