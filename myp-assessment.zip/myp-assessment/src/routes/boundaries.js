import { Router } from 'express';
import { getDb } from '../db.js';
import {
  GRADE_BOUNDARIES,
  PROFILE,
  SUBJECT_GROUPS,
  equivalencyMatrix,
  gradeRow,
  gradeMidpoint,
  percentForGrade,
  resolveSubject,
  toGrade,
} from '../data/boundaries.js';

const router = Router();

/** GET /api/v1/subjects - the Subject Selector dropdown model. */
router.get('/subjects', (_req, res) => {
  res.json({
    status: 'success',
    count: SUBJECT_GROUPS.length,
    data: SUBJECT_GROUPS.map((s) => ({
      ...s,
      grades: [8, 7, 6, 5, 4, 3, 2, 1].map((g) => gradeRow(s.id, g)),
    })),
  });
});

/** GET /api/v1/boundaries - every subject with its full conversion matrix. */
router.get('/boundaries', (_req, res) => {
  res.json({
    status: 'success',
    profiles: [PROFILE.STANDARD, PROFILE.EXTENDED],
    data: SUBJECT_GROUPS.map((s) => ({
      subject_group: s.id,
      short: s.short,
      profile: s.profile,
      note: s.note,
      boundaries: equivalencyMatrix(s.id),
    })),
  });
});

/** GET /api/v1/boundaries/:subject - the matrix for one subject group. */
router.get('/boundaries/:subject', (req, res) => {
  const subject = resolveSubject(req.params.subject);
  if (!subject) {
    return res.status(400).json({
      status: 'error',
      message: `Unknown subject group "${req.params.subject}".`,
      data: { valid_subjects: SUBJECT_GROUPS.map((s) => s.id) },
    });
  }

  if (req.query.grade) {
    const grade = Number.parseInt(req.query.grade, 10);
    const row = gradeRow(subject.id, grade);
    if (!row) {
      return res.status(400).json({
        status: 'error',
        message: 'grade must be an integer from 1 to 8.',
      });
    }
    return res.json({
      status: 'success',
      data: { subject_group: subject.id, profile: subject.profile, row },
    });
  }

  const percent = Number.parseFloat(req.query.percent);
  if (Number.isFinite(percent)) {
    const grade = toGrade(subject.id, percent);
    return res.json({
      status: 'success',
      data: {
        subject_group: subject.id,
        profile: subject.profile,
        percent,
        grade,
        row: gradeRow(subject.id, grade),
      },
    });
  }

  res.json({
    status: 'success',
    subject_group: subject.id,
    short: subject.short,
    profile: subject.profile,
    note: subject.note,
    data: equivalencyMatrix(subject.id),
  });
});

/** GET /api/v1/boundaries/slider/:subject - initial slider payload. */
router.get('/boundaries/slider/:subject', (req, res) => {
  const subject = resolveSubject(req.params.subject);
  if (!subject) {
    return res.status(404).json({ status: 'error', message: 'Unknown subject group.' });
  }
  const grade = Number.parseInt(req.query.grade, 10);
  const chosen = Number.isInteger(grade) && grade >= 1 && grade <= 8 ? grade : 5;
  res.json({
    status: 'success',
    data: {
      subject_group: subject.id,
      profile: subject.profile,
      grade: chosen,
      percent: percentForGrade(subject.id, chosen),
      midpoint: gradeMidpoint(subject.id, chosen),
      row: gradeRow(subject.id, chosen),
      // The two remaining Standard-profile ranges shown alongside the active one.
      reference_profiles: GRADE_BOUNDARIES.map((b) => ({
        grade: b.grade,
        standard: `${b.min}% - ${b.max}%`,
        extended: `${b.extendedMin}% - ${b.extendedMax}%`,
      })),
    },
  });
});

export default router;
