import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { getDb } from '../db.js';
import { SUBJECT_GROUPS } from '../data/boundaries.js';
import { registerAttempt } from './streak.js';

const router = Router();

const SUBJECT_KEYS = new Map(
  SUBJECT_GROUPS.map((s) => [
    s.id.toLowerCase(),
    { id: s.id, short: s.short },
  ]),
);

function resolveSubject(raw) {
  if (!raw) return null;
  const key = String(raw).trim().toLowerCase();
  const hit = SUBJECT_KEYS.get(key);
  if (hit) return hit;
  const loose = SUBJECT_GROUPS.find(
    (s) =>
      s.id.toLowerCase().replace(/[^a-z]/g, '') ===
      key.replace(/[^a-z]/g, ''),
  );
  return loose ? { id: loose.id, short: loose.short } : null;
}

const VALID_CRITERIA = ['A', 'B', 'C', 'D'];

function toPublic(row, reveal) {
  const base = {
    id: row.id,
    subject_group: row.subject_group,
    target_criterion: row.target_criterion,
    myp_phase_level: row.myp_phase_level,
    command_term: row.command_term,
    question_text: row.question_text,
    options: JSON.parse(row.options),
  };
  if (reveal) {
    base.correct_option_index = row.correct_option_index;
    base.rubric_rationale = row.rubric_rationale;
  }
  return base;
}

function clampInt(value, min, max, fallback) {
  const n = Number.parseInt(value, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

router.get('/questions', (req, res) => {
  const db = getDb();
  const {
    subject,
    criterion,
    level,
    command_term: commandTerm,
    search,
    limit,
    offset,
    reveal,
  } = req.query;

  const where = [];
  const params = {};

  const resolved = resolveSubject(subject);
  if (subject && !resolved) {
    return res.status(400).json({
      status: 'error',
      message: `Unknown subject group "${subject}".`,
      data: { valid_subjects: SUBJECT_GROUPS.map((s) => s.id) },
    });
  }
  if (resolved) {
    where.push('subject_group = :subject');
    params.subject = resolved.id;
  }

  if (criterion) {
    const c = String(criterion).trim().toUpperCase();
    if (!VALID_CRITERIA.includes(c)) {
      return res.status(400).json({
        status: 'error',
        message: `Invalid criterion "${criterion}". Expected one of A, B, C, D.`,
      });
    }
    where.push('target_criterion = :criterion');
    params.criterion = c;
  }

  if (level) {
    where.push('myp_phase_level = :level');
    params.level = clampInt(level, 1, 5, 3);
  }

  if (commandTerm) {
    where.push('command_term = :commandTerm');
    params.commandTerm = String(commandTerm).trim();
  }

  if (search) {
    where.push(
      '(question_text LIKE :search OR rubric_rationale LIKE :search OR command_term LIKE :search)',
    );
    params.search = `%${String(search).trim()}%`;
  }

  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const take = clampInt(limit, 1, 100, 20);
  const skip = clampInt(offset, 0, 100000, 0);
  const showAnswers =
    reveal === undefined ? true : String(reveal) === 'true' || reveal === true;

  const total = db
    .prepare(`SELECT COUNT(*) AS n FROM questions ${clause}`)
    .get(params).n;

  const rows = db
    .prepare(
      `SELECT * FROM questions ${clause}
       ORDER BY subject_group, target_criterion, myp_phase_level, id
       LIMIT :take OFFSET :skip`,
    )
    .all({ ...params, take, skip });

  res.json({
    status: 'success',
    data: rows.map((r) => toPublic(r, showAnswers)),
    meta: {
      total,
      limit: take,
      offset: skip,
      returned: rows.length,
      answers_included: showAnswers,
      filters: {
        subject_group: resolved?.id ?? null,
        criterion: criterion ? String(criterion).toUpperCase() : null,
        myp_phase_level: level ? clampInt(level, 1, 5, null) : null,
        command_term: commandTerm ?? null,
        search: search ?? null,
      },
    },
  });
});

router.get('/questions/stats', (_req, res) => {
  const db = getDb();
  const bySubject = db
    .prepare(
      `SELECT subject_group,
              COUNT(*)                       AS total,
              SUM(CASE WHEN target_criterion='A' THEN 1 ELSE 0 END) AS criterion_a,
              SUM(CASE WHEN target_criterion='B' THEN 1 ELSE 0 END) AS criterion_b,
              SUM(CASE WHEN target_criterion='C' THEN 1 ELSE 0 END) AS criterion_c,
              SUM(CASE WHEN target_criterion='D' THEN 1 ELSE 0 END) AS criterion_d
       FROM questions GROUP BY subject_group ORDER BY subject_group`,
    )
    .all();
  const byLevel = db
    .prepare(
      `SELECT myp_phase_level AS level, COUNT(*) AS total
       FROM questions GROUP BY myp_phase_level ORDER BY myp_phase_level`,
    )
    .all();
  const total = bySubject.reduce((n, r) => n + r.total, 0);
  res.json({
    status: 'success',
    data: { total, by_subject: bySubject, by_phase_level: byLevel },
  });
});

router.get('/questions/:id', (req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM questions WHERE id = ?')
    .get(req.params.id);
  if (!row) {
    return res.status(404).json({ status: 'error', message: 'Question not found.' });
  }
  const reveal = String(req.query.reveal ?? 'true') !== 'false';
  res.json({ status: 'success', data: toPublic(row, reveal) });
});

/**
 * Grades one submitted answer and advances the caller's practice streak.
 * Returns the rubric rationale so the practice engine can show instant feedback.
 */
router.post('/questions/attempt', (req, res) => {
  const db = getDb();
  const { question_id: questionId, chosen_index: chosenIndex } = req.body ?? {};

  const question = db
    .prepare('SELECT * FROM questions WHERE id = ?')
    .get(String(questionId ?? ''));
  if (!question) {
    return res.status(404).json({ status: 'error', message: 'Question not found.' });
  }

  const chosen = Number(chosenIndex);
  if (!Number.isInteger(chosen) || chosen < 0 || chosen > 3) {
    return res.status(400).json({
      status: 'error',
      message: 'chosen_index must be an integer between 0 and 3.',
    });
  }

  const isCorrect = chosen === question.correct_option_index ? 1 : 0;
  const sessionId = String(req.body?.session_id ?? '') || `ses_${randomUUID().slice(0, 8)}`;

  // The ledger row must exist first: practice_sessions.user_id is a foreign key.
  const streak = registerAttempt(db, req.userId, req.body?.timezone_offset);

  db.prepare(
    `INSERT INTO practice_sessions (id, user_id, subject_group, criterion, questions_served, correct_count)
     VALUES (?, ?, ?, ?, 1, ?)
     ON CONFLICT(id) DO UPDATE SET
       questions_served = questions_served + 1,
       correct_count = correct_count + excluded.correct_count`,
  ).run(
    sessionId,
    req.userId,
    question.subject_group,
    question.target_criterion,
    isCorrect,
  );

  db.prepare(
    `INSERT INTO practice_attempts
       (id, session_id, user_id, question_id, chosen_index, is_correct, phase_level)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    `att_${randomUUID().slice(0, 12)}`,
    sessionId,
    req.userId,
    question.id,
    chosen,
    isCorrect,
    question.myp_phase_level,
  );

  res.json({
    status: 'success',
    data: {
      question_id: question.id,
      subject_group: question.subject_group,
      target_criterion: question.target_criterion,
      myp_phase_level: question.myp_phase_level,
      command_term: question.command_term,
      chosen_index: chosen,
      correct_option_index: question.correct_option_index,
      is_correct: Boolean(isCorrect),
      rubric_rationale: question.rubric_rationale,
      session_id: sessionId,
    },
    streak,
  });
});

router.get('/questions/session/:sessionId', (req, res) => {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT id, user_id, subject_group, criterion,
              questions_served, correct_count, started_at
       FROM practice_sessions WHERE id = ?`,
    )
    .get(req.params.sessionId);
  if (!row) {
    return res.status(404).json({ status: 'error', message: 'Session not found.' });
  }
  if (row.user_id !== req.userId) {
    return res.status(403).json({ status: 'error', message: 'Session does not belong to this user.' });
  }
  const accuracy =
    row.questions_served > 0
      ? Number(((row.correct_count / row.questions_served) * 100).toFixed(1))
      : null;
  res.json({ status: 'success', data: { ...row, accuracy_percent: accuracy } });
});

export default router;
