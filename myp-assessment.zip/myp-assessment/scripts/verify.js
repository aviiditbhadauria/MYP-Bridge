/**
 * End-to-end verification. Boots the real HTTP server, then asserts the
 * behaviour specified for the API, the streak ledger and the equivalency engine.
 * Exits non-zero on the first failing assertion.
 */
import { spawn } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import { existsSync, readFileSync, rmSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

import { GRADE_BOUNDARIES, SUBJECT_GROUPS, toGrade, gradeMidpoint } from '../src/data/boundaries.js';
import { QUESTION_BANK, validateQuestions } from '../src/data/questions.index.js';
import keyTerms, { validateTerms } from '../src/data/terms.index.js';
// Imported statically so the browser-surface stub is available to every
// section that drives a real renderer, not just the first one that needs it.
import { installDom, StubElement } from './dom-stub.js';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const TEST_DB = resolve(root, 'data', 'verify.db');
const PORT = 3457;
const BASE = `http://127.0.0.1:${PORT}`;

let passed = 0;
const failures = [];

function check(label, condition, detail = '') {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${label}`);
  } else {
    failures.push(label);
    console.log(`  FAIL  ${label}${detail ? ` -> ${detail}` : ''}`);
  }
}

function section(name) {
  console.log(`\n${name}`);
}

/**
 * Parses top-level CSS rules, skipping any nested inside at-rules.
 *
 * Selector-based assertions need to look at the declarations a selector
 * actually receives. A naive regex over the whole file would also pick up
 * rules inside @media, and a match on the first `.button {` block would miss
 * declarations the browser applies from a later block.
 *
 * Comments are removed first, otherwise a block comment immediately above a
 * grouped selector becomes part of that selector and the lookup misses.
 *
 * @param {string} css
 * @returns {{selectors: string[], body: string}[]}
 */
function topLevelRules(css) {
  const sheet = css.replace(/\/\*[\s\S]*?\*\//g, '');
  const rules = [];
  let depth = 0;
  let buffer = '';
  let selector = '';

  for (const ch of sheet) {
    if (ch === '{') {
      if (depth === 0) selector = buffer.trim();
      depth += 1;
      buffer = '';
    } else if (ch === '}') {
      depth -= 1;
      if (depth === 0) {
        rules.push({ selectors: selector.split(',').map((s) => s.trim()), body: buffer });
      }
      buffer = '';
    } else {
      buffer += ch;
    }
  }
  return rules;
}

/** Every declaration that applies to `selector` at the top level. */
function declarationsFor(css, selector) {
  return topLevelRules(css)
    .filter((r) => r.selectors.includes(selector))
    .map((r) => r.body)
    .join('\n');
}

// Isolated database so verification never disturbs development data.
for (const suffix of ['', '-wal', '-shm']) {
  rmSync(`${TEST_DB}${suffix}`, { force: true });
}

console.log('Seeding isolated verification database...');
await new Promise((res, rej) => {
  const child = spawn(
    process.execPath,
    ['--no-warnings', resolve(root, 'scripts', 'seed.js')],
    { cwd: root, env: { ...process.env, MYP_DB_PATH: TEST_DB }, stdio: 'ignore' },
  );
  child.on('exit', (code) => (code === 0 ? res() : rej(new Error(`seed exited ${code}`))));
});

console.log('Booting server...');
const server = spawn(process.execPath, ['--no-warnings', resolve(root, 'server.js')], {
  cwd: root,
  env: { ...process.env, MYP_DB_PATH: TEST_DB, PORT: String(PORT), HOST: '127.0.0.1' },
  stdio: 'ignore',
});

async function waitForServer(attempts = 60) {
  for (let i = 0; i < attempts; i += 1) {
    try {
      const res = await fetch(`${BASE}/api/v1/health`);
      if (res.ok) return true;
    } catch {
      /* not up yet */
    }
    await sleep(250);
  }
  return false;
}

if (!(await waitForServer())) {
  console.error('Server failed to start.');
  server.kill();
  process.exit(1);
}

// A cookie jar keeps the session stable across the streak scenarios.
let cookie = '';

async function api(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      ...(options.body ? { 'content-type': 'application/json' } : {}),
      ...(cookie ? { cookie } : {}),
      ...options.headers,
    },
  });
  const setCookie = res.headers.getSetCookie?.() ?? [];
  for (const c of setCookie) {
    const pair = c.split(';')[0];
    if (pair.startsWith('myp_session=')) cookie = pair;
  }
  const body = await res.json().catch(() => null);
  return { status: res.status, body };
}

async function cleanup() {
  const exited = new Promise((res) => server.once('exit', res));
  server.kill();
  // The database file stays locked until the child has actually exited.
  await Promise.race([exited, sleep(5000)]);
  for (const suffix of ['', '-wal', '-shm']) rmSync(`${TEST_DB}${suffix}`, { force: true });
}

try {
  // ---------------------------------------------------------------- data ----
  section('Seed data integrity');
  check('300 questions validate', validateQuestions(QUESTION_BANK) === 300);
  check('glossary validates', validateTerms(keyTerms) === keyTerms.length);
  check(
    'question ids are unique',
    new Set(QUESTION_BANK.map((q) => q.id)).size === QUESTION_BANK.length,
  );
  check(
    'every question has a rationale',
    QUESTION_BANK.every((q) => q.rubric_rationale.trim().length > 0),
  );
  check(
    'every question has a known command term',
    QUESTION_BANK.every((q) => keyTerms.some((t) => t.term === q.command_term)),
  );

  // ------------------------------------------------------------- health ----
  section('Health and session');
  const health = await api('/api/v1/health');
  check('health responds 200', health.status === 200, `got ${health.status}`);
  check('health reports 300 questions', health.body?.data?.questions === 300);
  check('health reports the glossary size', health.body?.data?.key_terms === keyTerms.length);

  const session = await api('/api/v1/session');
  check('session issues a user id', /^usr_/.test(session.body?.data?.user_id ?? ''));
  check('session cookie was set', cookie.startsWith('myp_session='));

  // ---------------------------------------------------------- questions ----
  section('Questions API');
  const all = await api('/api/v1/questions?limit=5');
  check('lists questions', all.status === 200 && all.body.data.length === 5);
  check('reports full total', all.body.meta.total === 300);
  check('includes answer key by default', typeof all.body.data[0].correct_option_index === 'number');
  check('includes rubric rationale', all.body.data[0].rubric_rationale.length > 0);
  check('meta reports limit and offset', all.body.meta.limit === 5 && all.body.meta.offset === 0);

  const hidden = await api('/api/v1/questions?limit=3&reveal=false');
  check('reveal=false withholds answers', hidden.body.data[0].correct_option_index === undefined);
  check('reveal=false still returns question text', hidden.body.data[0].question_text.length > 0);

  const mathQ = await api('/api/v1/questions?subject=Mathematics%20(Standard)&limit=100');
  check('filters by subject group', mathQ.body.meta.total === 50, `got ${mathQ.body.meta.total}`);

  const critA = await api('/api/v1/questions?criterion=A&limit=1');
  check('filters by criterion', critA.body.meta.total === 75, `got ${critA.body.meta.total}`);

  const combined = await api('/api/v1/questions?subject=Sciences&criterion=B&limit=100');
  check(
    'combines subject and criterion filters',
    combined.body.meta.total > 0 && combined.body.meta.total <= 50,
    `got ${combined.body.meta.total}`,
  );
  check(
    'combined filter returns only matching rows',
    combined.body.data.every((q) => q.subject_group === 'Sciences' && q.target_criterion === 'B'),
  );

  const byCommand = await api('/api/v1/questions?command_term=Evaluate&limit=1');
  check('filters by command term', byCommand.body.data[0].command_term === 'Evaluate');

  const paginated = await api('/api/v1/questions?limit=10&offset=290');
  check('pagination returns final page', paginated.body.data.length === 10);
  check('pagination reports offset', paginated.body.meta.offset === 290);

  const badSubject = await api('/api/v1/questions?subject=Nonsense');
  check('rejects unknown subject with 400', badSubject.status === 400);
  check('unknown subject lists valid options', Array.isArray(badSubject.body?.data?.valid_subjects));

  const badCriterion = await api('/api/v1/questions?criterion=Z');
  check('rejects invalid criterion with 400', badCriterion.status === 400);

  const missing = await api('/api/v1/questions/does-not-exist');
  check('unknown question id returns 404', missing.status === 404);

  const byId = await api(`/api/v1/questions/${all.body.data[0].id}`);
  check('fetches single question by id', byId.body?.data?.id === all.body.data[0].id);

  const stats = await api('/api/v1/questions/stats');
  check('stats total is 300', stats.body.data.total === 300);
  check('stats cover six subject groups', stats.body.data.by_subject.length === 6);
  check('stats cover five phase levels', stats.body.data.by_phase_level.length === 5);

  // --------------------------------------------------------- boundaries ----
  section('Boundaries and equivalency API');
  const subjects = await api('/api/v1/subjects');
  check('lists six subject groups', subjects.body.data.length === 6);
  check('each subject carries eight grades', subjects.body.data[0].grades.length === 8);

  const std = await api('/api/v1/boundaries/Mathematics%20(Standard)');
  check('returns standard matrix rows', std.body.data.length === 8);
  check(
    'standard grade 7 is 76-87',
    std.body.data.find((r) => r.grade === 7)?.percentRange === '76% - 87%',
  );
  check(
    'standard grade 8 is 88-100',
    std.body.data.find((r) => r.grade === 8)?.percentRange === '88% - 100%',
  );

  const ext = await api('/api/v1/boundaries/Mathematics%20(Extended)');
  check('extended profile differs from standard', ext.body.profile === 'extended');
  check(
    'extended grade 7 is 71-81',
    ext.body.data.find((r) => r.grade === 7)?.percentRange === '71% - 81%',
  );
  check(
    'extended grade 5 is 48-59',
    ext.body.data.find((r) => r.grade === 5)?.percentRange === '48% - 59%',
  );
  check(
    'every row carries a descriptor',
    ext.body.data.every((r) => typeof r.descriptor === 'string' && r.descriptor.length > 40),
  );
  check(
    'every row carries all four board equivalencies',
    ext.body.data.every((r) => r.igcse && r.cbse && r.icse && r.stateBoard),
  );

  const allBounds = await api('/api/v1/boundaries');
  check('all-subjects matrix returns six entries', allBounds.body.data.length === 6);

  const byPercent = await api('/api/v1/boundaries/Sciences?percent=92');
  check('percentage 92 maps to grade 8', byPercent.body.data.grade === 8);
  const byPercentMid = await api('/api/v1/boundaries/Sciences?percent=42');
  check('percentage 42 maps to grade 4', byPercentMid.body.data.grade === 4);
  const extPercent = await api('/api/v1/boundaries/Mathematics%20(Extended)?percent=75');
  check('extended profile resolves 75 to grade 7', extPercent.body.data.grade === 7);
  const stdPercent = await api('/api/v1/boundaries/Mathematics%20(Standard)?percent=75');
  check('standard profile resolves 75 to grade 6', stdPercent.body.data.grade === 6);
  check(
    'the same percentage can resolve differently across profiles',
    extPercent.body.data.grade !== stdPercent.body.data.grade,
  );
  const extDiverge = await api('/api/v1/boundaries/Mathematics%20(Extended)?percent=82');
  check('extended profile resolves 82 to grade 8', extDiverge.body.data.grade === 8);
  const stdDiverge = await api('/api/v1/boundaries/Mathematics%20(Standard)?percent=82');
  check('standard profile resolves 82 to grade 7', stdDiverge.body.data.grade === 7);

  const badBounds = await api('/api/v1/boundaries/NotASubject');
  check('unknown subject in boundaries returns 400', badBounds.status === 400);

  const slider = await api('/api/v1/boundaries/slider/Sciences?grade=6');
  check('slider payload has a row', slider.body.data.row?.grade === 6);
  check('slider payload has a percent', typeof slider.body.data.percent === 'number');
  check('slider payload has reference profiles', slider.body.data.reference_profiles.length === 8);

  // Boundary arithmetic invariants. Rows are ordered grade 8 down to grade 1, so
  // each row's min is one above the next row's max.
  const rows = GRADE_BOUNDARIES;
  check('boundaries are ordered grade 8 down to grade 1', rows[0].grade === 8 && rows[rows.length - 1].grade === 1);
  check(
    'standard boundaries are contiguous 0-100',
    rows[rows.length - 1].min === 0 &&
      rows[0].max === 100 &&
      rows.every((b, i) => i === rows.length - 1 || b.min - rows[i + 1].max === 1),
  );
  check(
    'extended boundaries are contiguous 0-100',
    rows[rows.length - 1].extendedMin === 0 &&
      rows[0].extendedMax === 100 &&
      rows.every((b, i) => i === rows.length - 1 || b.extendedMin - rows[i + 1].extendedMax === 1),
  );
  check(
    'no band is inverted within either profile',
    rows.every((b) => b.min <= b.max && b.extendedMin <= b.extendedMax),
  );
  check(
    'extended bounds never exceed standard bounds',
    rows.every((b) => b.extendedMin <= b.min && b.extendedMax <= b.max),
  );
  check(
    'toGrade maps standard thresholds correctly',
    toGrade('Sciences', 100) === 8 &&
      toGrade('Sciences', 88) === 8 &&
      toGrade('Sciences', 87) === 7 &&
      toGrade('Sciences', 76) === 7 &&
      toGrade('Sciences', 75) === 6 &&
      toGrade('Sciences', 0) === 1,
  );
  check(
    'toGrade clamps out-of-range percentages',
    toGrade('Sciences', 140) === 8 && toGrade('Sciences', -20) === 1,
  );
  check(
    'every grade is reachable by toGrade on both profiles',
    SUBJECT_GROUPS.every((s) => {
      const band = gradeMidpoint(s.id, 5);
      return toGrade(s.id, band) === 5;
    }),
  );

  // -------------------------------------------------------------- terms ----
  section('Terms API');
  const search = await api('/api/v1/terms/search?q=evaluate');
  check('search returns results', search.body.count > 0);
  check('search echoes the query', search.body.query === 'evaluate');
  check(
    'search result has all four fields',
    ['term', 'formal_definition', 'myp_context_example', 'category'].every(
      (k) => k in search.body.results[0],
    ),
  );
  check('exact match ranks first', search.body.results[0].term === 'Evaluate');

  const partial = await api('/api/v1/terms/search?q=photo');
  check('substring search works', partial.body.count > 0);

  const american = await api('/api/v1/terms/search?q=Analyze');
  check('american spelling finds the british term', american.body.count > 0);
  check('british spelling is returned for american query', american.body.results[0]?.term === 'Analyse');

  const british = await api('/api/v1/terms/search?q=analyse');
  check('british spelling returns the term', british.body.results[0]?.term === 'Analyse');

  const caseInsensitive = await api('/api/v1/terms/search?q=EVALUATE');
  check('search is case insensitive', caseInsensitive.body.results[0]?.term === 'Evaluate');

  const singleLetter = await api('/api/v1/terms/search?q=a');
  check('single-letter query still returns matches', singleLetter.body.count > 0);

  const byDefinition = await api('/api/v1/terms/search?q=unreliable%20narrator');
  check('search covers definitions', byDefinition.body.count > 0);

  const noQuery = await api('/api/v1/terms/search');
  check('search without q returns 400', noQuery.status === 400);

  const termList = await api('/api/v1/terms?limit=5');
  check('terms list paginates', termList.body.data.length === 5);
  check('terms list reports total', termList.body.total === keyTerms.length);

  const single = await api('/api/v1/terms/Evaluate');
  check('exact term lookup works', single.body.data.term === 'Evaluate');
  check('term has related terms', Array.isArray(single.body.data.related_terms));

  const missingTerm = await api('/api/v1/terms/NotARealTerm');
  check('unknown term returns 404', missingTerm.status === 404);

  const cats = await api('/api/v1/terms/categories');
  check('category index is populated', cats.body.data.categories.length > 0);

  // ------------------------------------------------------------- streak ----
  section('Streak ledger');
  const SHARED_SESSION = 'ses_verification_run';
  const tz = () => -new Date().getTimezoneOffset();
  const fresh = await api('/api/v1/streak');
  check('new user starts at zero', fresh.body.data.current_streak === 0);
  check('new user has no activity timestamp', fresh.body.data.last_activity_timestamp === null);
  check('new user streak not active', fresh.body.data.streak_active_today === false);

  const attempt1 = await api('/api/v1/questions/attempt', {
    method: 'POST',
    body: JSON.stringify({
      question_id: all.body.data[0].id,
      chosen_index: all.body.data[0].correct_option_index,
      session_id: SHARED_SESSION,
      timezone_offset: tz(),
    }),
  });
  check('attempt graded as correct', attempt1.body.data.is_correct === true);
  check('first attempt sets streak to 1', attempt1.body.streak.current_streak === 1);
  check('first attempt sets longest to 1', attempt1.body.streak.longest_streak === 1);
  check('streak message is returned', typeof attempt1.body.streak.status_message === 'string');
  check('attempt echoes the session id', attempt1.body.data.session_id === SHARED_SESSION);

  const attempt2 = await api('/api/v1/questions/attempt', {
    method: 'POST',
    body: JSON.stringify({
      question_id: all.body.data[1].id,
      chosen_index: all.body.data[1].correct_option_index,
      session_id: SHARED_SESSION,
      timezone_offset: tz(),
    }),
  });
  check('same-day attempt holds streak at 1', attempt2.body.streak.current_streak === 1);
  check('same-day delta reported as 0', attempt2.body.streak.days_since_last_activity === 0);

  const afterToday = await api('/api/v1/streak');
  check('streak endpoint reflects attempt', afterToday.body.data.current_streak === 1);
  check('streak active today is true', afterToday.body.data.streak_active_today === true);
  check('lifetime attempt total is 2', afterToday.body.data.totals.attempts === 2);
  check('lifetime accuracy is 100', afterToday.body.data.totals.accuracy_percent === 100);

  const verify = await api('/api/v1/streak/verify', {
    method: 'POST',
    body: JSON.stringify({ timezone_offset: tz() }),
  });
  check('verify endpoint does not increment same-day streak', verify.body.streak.current_streak === 1);

  // A wrong answer still logs practice, matching the spec: the streak tracks
  // submission, not correctness.
  const attemptWrong = await api('/api/v1/questions/attempt', {
    method: 'POST',
    body: JSON.stringify({
      question_id: all.body.data[2].id,
      chosen_index: (all.body.data[2].correct_option_index + 1) % 4,
      session_id: SHARED_SESSION,
      timezone_offset: tz(),
    }),
  });
  check('incorrect answer graded incorrect', attemptWrong.body.data.is_correct === false);
  check('incorrect answer still holds streak', attemptWrong.body.streak.current_streak === 1);
  check('incorrect answer explains the correct option', attemptWrong.body.data.correct_option_index === all.body.data[2].correct_option_index);
  check('incorrect answer returns a rationale', attemptWrong.body.data.rubric_rationale.length > 0);

  // Day-sequence replay exercises increment, maintain and reset branches.
  const consecutive = await api('/api/v1/streak/history', {
    method: 'POST',
    body: JSON.stringify({
      days: ['2026-03-01', '2026-03-02', '2026-03-03'],
      timezone_offset: 0,
    }),
  });
  const seq = consecutive.body.data.trace;
  check('day 1 starts the streak at 1', seq[0].current_streak === 1);
  check('day 2 increments to 2', seq[1].current_streak === 2);
  check('day 3 increments to 3', seq[2].current_streak === 3);
  check('longest streak tracks the maximum', seq[2].longest_streak === 3);

  const broken = await api('/api/v1/streak/history', {
    method: 'POST',
    body: JSON.stringify({
      days: ['2026-03-01', '2026-03-02', '2026-03-03', '2026-03-07'],
      timezone_offset: 0,
    }),
  });
  const brk = broken.body.data.trace;
  check('missed days reset the streak to 1', brk[3].current_streak === 1);
  check('longest streak is preserved after a reset', brk[3].longest_streak === 3);
  check('gap is reported as 4 days', brk[3].days_since_last_activity === 4);
  check('reset message explains why', /reset/i.test(brk[3].status_message));

  const repeated = await api('/api/v1/streak/history', {
    method: 'POST',
    body: JSON.stringify({
      days: ['2026-04-01', '2026-04-01', '2026-04-01'],
      timezone_offset: 0,
    }),
  });
  const rep = repeated.body.data.trace;
  check('repeating the same day holds at 1', rep.every((t) => t.current_streak === 1));
  check('repeating the same day reports delta 0', rep[2].days_since_last_activity === 0);

  // A half-hour timezone must not desynchronise the day boundary.
  const halfHour = await api('/api/v1/streak/history', {
    method: 'POST',
    body: JSON.stringify({
      days: ['2026-05-10', '2026-05-10', '2026-05-11'],
      timezone_offset: 330,
    }),
  });
  const hz = halfHour.body.data.trace;
  check('IST offset keeps same-day activity at 1', hz[1].current_streak === 1);
  check('IST offset increments on the next local day', hz[2].current_streak === 2);

  const finalEcho = consecutive.body.data.final;
  check('history reports the final ledger state', finalEcho.current_streak === 3 && finalEcho.longest_streak === 3);

  const badHistory = await api('/api/v1/streak/history', { method: 'POST', body: JSON.stringify({}) });
  check('history without days returns 400', badHistory.status === 400);

  // -------------------------------------------------------- attribution ----
  section('Session attribution');
  const sessionInfo = await api(`/api/v1/questions/session/${SHARED_SESSION}`);
  check('session records three served questions', sessionInfo.body.data.questions_served === 3);
  check('session records two correct', sessionInfo.body.data.correct_count === 2);
  check('session accuracy computed', sessionInfo.body.data.accuracy_percent === 66.7);

  const otherUser = await fetch(`${BASE}/api/v1/questions/session/${SHARED_SESSION}`, {
    headers: { 'x-myp-user': 'usr_someoneelse' },
  });
  check('another user cannot read the session', otherUser.status === 403);

  // ---------------------------------------------------------------- 404 ----
  section('Error handling');
  const unknownApi = await api('/api/v1/nope');
  check('unknown api route returns 404', unknownApi.status === 404);
  check('unknown api route returns error status', unknownApi.body.status === 'error');

  // ---------------------------------------------------------- frontend ----
  section('Frontend assets');
  const html = await (await fetch(`${BASE}/`)).text();
  check('index document is served', html.includes('<!doctype html>'));
  for (const id of [
    'panel-equivalency',
    'panel-practice',
    'panel-glossary',
    'grade-slider',
    'subject-select',
    'streak',
  ]) {
    check(`markup exposes #${id}`, html.includes(`id="${id}"`));
  }
  check('slider is a range input 1-8', /type="range"[\s\S]{0,200}min="1"[\s\S]{0,200}max="8"/.test(html));
  check('markup declares the streak region live', /id="streak"[^>]*aria-live="polite"/.test(html));

  const css = await (await fetch(`${BASE}/css/styles.css`)).text();
  for (const token of ['--canvas', '--surface', '--line', '--plum-900', '--r-md']) {
    check(`stylesheet defines ${token}`, css.includes(token));
  }
  check('stylesheet avoids oversized corner radii', !/border-radius:\s*(1\.5|2|3)rem/.test(css));

  // Branding is asserted across every shipped surface, not just the page.
  const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
  const serverMod = readFileSync(resolve(root, 'server.js'), 'utf8');
  check('stylesheet header names the brand', /^\s+MYP Bridge\s*$/m.test(css));
  check('stylesheet no longer names the old product', !/MYP eAssessment/.test(css));
  check('server banner names the brand', serverMod.includes('MYP Bridge running at'));
  check('server banner no longer names the old product', !serverMod.includes('MYP eAssessment'));
  check('package name is the brand', pkg.name === 'myp-bridge', pkg.name);
  check('package description names the brand', /MYP Bridge/.test(pkg.description));
  check('the favicon ships with the app', existsSync(resolve(root, 'public', 'favicon.svg')));
  check('stylesheet avoids pill-shaped cards', !/rounded-3xl/.test(css));

  const modules = [
    'app.js',
    'api.js',
    'equivalency.js',
    'practice.js',
    'glossary.js',
    'streak.js',
    'guides.js',
    'termcard.js',
  ];
  for (const name of modules) {
    const res = await fetch(`${BASE}/js/${name}`);
    const body = await res.text();
    check(`module ${name} is served`, res.ok && res.headers.get('content-type').includes('javascript'));
    check(`module ${name} is not empty`, body.length > 200);
  }

  const equiv = await (await fetch(`${BASE}/js/equivalency.js`)).text();
  check('slider uses requestAnimationFrame', equiv.includes('requestAnimationFrame'));
  check('slider listens for input', /addEventListener\('input'/.test(equiv));
  check('slider listens for change', /addEventListener\('change'/.test(equiv));
  check('slider marks the active equivalency row', equiv.includes('is-active'));

  const streakMod = await (await fetch(`${BASE}/js/streak.js`)).text();
  check('streak module exposes no mutating control', !/addEventListener\('click'/.test(streakMod));

  const wholeApp = html + css + await (await fetch(`${BASE}/js/app.js`)).text();
  const emoji = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u;
  check('no emoji in shipped frontend', !emoji.test(wholeApp));

  // ------------------------------------------------- subject guide data ----
  section('Subject guides');

  const guideIndex = await api('/api/v1/guides');
  check('guides index succeeds', guideIndex.body.status === 'success');
  check('guides index returns six guides', guideIndex.body.count === 6);
  check(
    'guide ids are unique',
    new Set(guideIndex.body.guides.map((g) => g.id)).size === 6,
  );
  for (const id of [
    'design',
    'physical-and-health-education',
    'visual-arts',
    'interdisciplinary-units',
    'service-as-action',
    'core-pathways',
  ]) {
    check(`guides index includes ${id}`, guideIndex.body.guides.some((g) => g.id === id));
  }
  check(
    'guides index advertises four score bands',
    JSON.stringify(guideIndex.body.score_bands) === JSON.stringify(['1-2', '3-4', '5-6', '7-8']),
  );
  check('guides index lists every classroom transcript', guideIndex.body.dialogues.length === 4);

  // Every subject group must own a transcript. The panel is required to tailor
  // the conversation to the selected group, so a gap is a content defect.
  const guideIds = guideIndex.body.guides.map((g) => g.id);
  const dlgSummaries = guideIndex.body.dialogues;
  for (const id of guideIds) {
    const owners = dlgSummaries.filter((d) => (d.guide_ids ?? []).includes(id));
    check(`guide ${id} has a classroom transcript`, owners.length > 0, owners.map((o) => o.id).join(', '));
  }
  check(
    'no transcript is orphaned from every guide',
    dlgSummaries.every((d) => (d.guide_ids ?? []).some((id) => guideIds.includes(id))),
  );
  check(
    'transcript summaries expose guide_ids for client matching',
    dlgSummaries.every((d) => Array.isArray(d.guide_ids) && d.guide_ids.length > 0),
  );
  check(
    'each transcript annotates at least ten glossary terms',
    dlgSummaries.every((d) => d.term_count >= 10),
    dlgSummaries.map((d) => `${d.id}=${d.term_count}`).join(' '),
  );

  const designDetail = await api('/api/v1/guides/design');
  const design = designDetail.body.data;
  check('guide declares a framework overview', (design.framework_overview ?? '').length >= 80);
  check('guide declares assessment objectives', (design.assessment_objectives ?? []).length >= 3);
  check(
    'guide declares eAssessment expectations',
    (design.eassessment_expectations ?? []).length >= 3,
  );
  check('guide lists global contexts', (design.global_contexts ?? []).length > 0);
  check('guide names its pathway and levels', Boolean(design.pathway && design.levels));

  // Criteria are keyed by id, not mark, and anchors must be canonical terms.
  check(
    'criterion keys are id, not mark',
    design.criteria.every((c) => typeof c.id === 'string' && c.mark === undefined),
  );
  check(
    'no guide reintroduces a non-canonical Analyze entry',
    !keyTerms.some((t) => t.term.toLowerCase() === 'analyze'),
  );

  const EXPECTED_CRITERIA = {
    design: 4,
    'physical-and-health-education': 4,
    'visual-arts': 4,
    'interdisciplinary-units': 4,
    'service-as-action': 3,
    'core-pathways': 4,
  };
  const glossaryNames = new Set(keyTerms.map((t) => t.term));

  for (const [id, count] of Object.entries(EXPECTED_CRITERIA)) {
    const res = await api(`/api/v1/guides/${id}`);
    const guide = res.body.data;
    check(`guide ${id} loads`, res.status === 200 && guide.id === id);
    check(`guide ${id} has ${count} criteria`, guide.criteria.length === count);

    const marks = guide.criteria.map((c) => c.mark).join('');
    check(
      `guide ${id} criteria are A to ${String.fromCharCode(64 + count)}`,
      guide.criteria.map((c) => c.id).join('') ===
        Array.from({ length: count }, (_, i) => String.fromCharCode(65 + i)).join(''),
    );

    for (const criterion of guide.criteria) {
      const ranges = Object.keys(criterion.bands);
      check(
        `guide ${id} criterion ${criterion.id} has four bands`,
        ranges.length === 4,
        `found ${ranges.join(', ')}`,
      );
      check(
        `guide ${id} criterion ${criterion.id} bands are 1-2/3-4/5-6/7-8`,
        JSON.stringify(ranges) === JSON.stringify(['1-2', '3-4', '5-6', '7-8']),
      );
      for (const [range, text] of Object.entries(criterion.bands)) {
        check(
          `guide ${id} criterion ${criterion.id} band ${range} is substantive`,
          typeof text === 'string' && text.length >= 60,
          `length ${typeof text === 'string' ? text.length : 'n/a'}`,
        );
      }

      check(
        `guide ${id} criterion ${criterion.id} resolves every term anchor`,
        (criterion.term_anchors ?? []).length > 0 &&
          (criterion.term_anchors ?? []).every((t) => glossaryNames.has(t)),
        (criterion.term_anchors ?? []).filter((t) => !glossaryNames.has(t)).join(', '),
      );
      check(
        `guide ${id} criterion ${criterion.id} terms are hydrated`,
        (criterion.terms ?? []).length === (criterion.term_anchors ?? []).length &&
          (criterion.terms ?? []).every((t) => t?.formal_definition),
      );
    }
  }

  const missingGuide = await api('/api/v1/guides/not-a-guide');
  check('unknown guide returns 404', missingGuide.status === 404);
  check('unknown guide names valid ids', missingGuide.body.data.valid_guides.length === 6);

  // ------------------------------------------------ classroom dialogue ----
  section('Classroom dialogue');

  const dlgIndex = await api('/api/v1/guides/dialogue');
  check('dialogue index succeeds', dlgIndex.body.count === 4);
  const dialogue = dlgIndex.body.data.find((d) => d.id === 'grade10-idu-design-visual-arts');
  check('dialogue has turns', dialogue.turns.length > 0);
  check('dialogue turns carry plain text', dialogue.turns.every((t) => typeof t.text === 'string' && t.text.length > 0));
  check(
    'turn text is exactly the concatenation of its segments',
    dialogue.turns.every((t) => t.text === t.segments.map((s) => s.value).join('')),
  );
  check(
    'turn text preserves the authored transcript wording',
    dialogue.turns[0].text.startsWith(
      'To begin your design brief, how do you plan to inquire into user requirements',
    ),
  );
  check('dialogue has a term map', dialogue.term_map.length >= 10);
  check(
    'every term map entry resolves to a glossary record',
    dialogue.term_map.every((e) => e.glossary_term?.formal_definition),
  );
  check(
    'every term map entry carries a contextual definition',
    dialogue.term_map.every((e) => (e.contextual_definition ?? '').length > 10),
  );
  check(
    'every annotated span resolves to a glossary record',
    dialogue.turns
      .flatMap((t) => t.segments)
      .filter((s) => s.type === 'term')
      .every((s) => s.glossary_term?.formal_definition),
  );
  check(
    'annotated spans keep their surface wording distinct from the glossary key',
    dialogue.turns
      .flatMap((t) => t.segments)
      .filter((s) => s.type === 'term')
      .every((s) => typeof s.value === 'string' && s.value.length > 0),
  );
  check('dialogue states a didactic note', (dialogue.didactic_note ?? '').length >= 40);
  check(
    'every turn declares a speaker role',
    dialogue.turns.every((t) => t.speaker && t.speaker_role),
  );

  const oneDialogue = await api(`/api/v1/guides/dialogue/${dialogue.id}`);
  check('dialogue detail loads', oneDialogue.body.data.id === dialogue.id);
  const missingDialogue = await api('/api/v1/guides/dialogue/nope');
  check('unknown dialogue returns 404', missingDialogue.status === 404);

  // ---------------------------------------------------- palette contrast ----
  section('Palette and contrast');

  for (const token of [
    '--canvas: #f6f3ed',
    '--surface: #faf8f5',
    '--line: #d8b4fe',
    '--container-tint: #efeadf',
    '--plum-900: #2a0835',
    '--violet-700: #4c1d95',
    '--amethyst-600: #7e22ce',
    '--lavender-500: #a855f7',
    '--lilac-100: #f3e8ff',
    '--plum-mono: #3b0764',
    '--ink-body: #1e293b',
  ]) {
    check(`stylesheet sets ${token}`, css.includes(token));
  }

  const channel = (value) => {
    const v = value / 255;
    return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  };
  const luminance = (hex) => {
    const clean = hex.replace('#', '');
    const [r, g, b] = [0, 2, 4].map((i) => channel(parseInt(clean.slice(i, i + 2), 16)));
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  };
  const contrast = (a, b) => {
    const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
    return (hi + 0.05) / (lo + 0.05);
  };

  const TEXT_PAIRS = [
    ['body ink on canvas', '#1e293b', '#f6f3ed'],
    ['body ink on surface', '#1e293b', '#faf8f5'],
    ['body ink on container tint', '#1e293b', '#efeadf'],
    ['body ink on selected lilac', '#1e293b', '#f3e8ff'],
    ['muted ink on canvas', '#5a5470', '#f6f3ed'],
    ['muted ink on surface', '#5a5470', '#faf8f5'],
    ['muted ink on container tint', '#5a5470', '#efeadf'],
    ['faint ink on surface', '#6b6480', '#faf8f5'],
    ['plum heading on canvas', '#2a0835', '#f6f3ed'],
    ['plum heading on selected lilac', '#2a0835', '#f3e8ff'],
    ['mono score token on surface', '#3b0764', '#faf8f5'],
    ['mono score token on selected lilac', '#3b0764', '#f3e8ff'],
    ['inverted text on imperial violet', '#fdfcfe', '#4c1d95'],
    ['inverted text on amethyst', '#fdfcfe', '#7e22ce'],
    ['inverted text on plum', '#fdfcfe', '#2a0835'],
    ['violet term link on selected lilac', '#4c1d95', '#f3e8ff'],
    ['success ink on success tint', '#145c43', '#e3f3ec'],
    ['danger ink on danger tint', '#8f1f38', '#f9e6eb'],
  ];
  for (const [label, fg, bg] of TEXT_PAIRS) {
    const ratio = contrast(fg, bg);
    check(
      `${label} meets WCAG AA (${ratio.toFixed(2)}:1)`,
      ratio >= 4.5,
      `required 4.5:1`,
    );
  }

  // Palette-level guarantees for the accessible tokens. The select border is
  // handled separately below because the explicit spec overrides this token.
  const UI_PAIRS = [
    ['line-input token on ivory surface', '#a855f7', '#faf8f5'],
    ['line-input token on cream canvas', '#a855f7', '#f6f3ed'],
    ['slider thumb on cream canvas', '#7e22ce', '#f6f3ed'],
    ['focus ring on cream canvas', '#7e22ce', '#f6f3ed'],
  ];
  for (const [label, fg, bg] of UI_PAIRS) {
    const ratio = contrast(fg, bg);
    check(`${label} meets non-text contrast (${ratio.toFixed(2)}:1)`, ratio >= 3, 'required 3:1');
  }

  // The user specified #D8B4FE for select borders. It measures 1.67:1 against
  // the ivory surface, which is below the 3:1 that WCAG 1.4.11 asks of a
  // non-text control boundary, so it is recorded as a known deviation rather
  // than asserted as accessible.
  check(
    'select border follows the specified lilac',
    /select\s*\{[^}]*border:\s*1px solid var\(--line\)/.test(css),
  );
  check(
    'the specified lilac border token is declared',
    /--line:\s*#d8b4fe/i.test(css),
  );
  const selectBorder = css.match(/--line:\s*(#[0-9a-f]{6})/i)?.[1] ?? null;
  if (selectBorder) {
    const ratio = contrast(selectBorder, '#faf8f5');
    check(
      `select border contrast recorded as a documented deviation (${ratio.toFixed(2)}:1)`,
      ratio < 3,
      'expected below 3:1; the explicit spec was followed over the guideline',
    );
  }
  check(
    'the stronger --line-input token is retained for future opt-in',
    /--line-input:\s*#a855f7/i.test(css),
  );
  check(
    'the focus ring still meets non-text contrast',
    contrast('#7e22ce', '#f6f3ed') >= 3,
  );
  check('stylesheet has no hardcoded legacy palette token', !/--(primary|ink)-900/.test(css));

  // ------------------------------------------------------- guide frontend ----
  // ---------------------------------------------------------- branding ----
  section('Branding');

  check('the document title is MYP Bridge', /<title>\s*MYP Bridge\s*<\/title>/.test(html));
  check('the header shows MYP Bridge', /<h1 class="masthead__title">\s*MYP Bridge\s*<\/h1>/.test(html));
  check(
    'the brand subtitle is retained',
    html.includes('Grade equivalency, criterion practice and assessment vocabulary'),
  );
  check(
    'the tab icon points at the SVG favicon',
    /<link rel="icon" type="image\/svg\+xml" href="\/favicon\.svg" \/>/.test(html),
  );
  check('the header reuses the same mark', /class="masthead__mark" src="\/favicon\.svg"/.test(html));
  check('the header mark is decorative, since the h1 names the brand', /masthead__mark" src="\/favicon\.svg" alt=""/.test(html));

  // The IB concept "eAssessment" is subject vocabulary and must survive the
  // rebrand; only the application name changes.
  check(
    'the old product name is gone from the page',
    !/MYP eAssessment/.test(html),
  );
  check(
    'eAssessment vocabulary is still taught in the guides copy',
    html.includes('eAssessment expectations'),
  );
  check('eAssessment remains a glossary term', keyTerms.some((t) => t.term === 'eAssessment'));

  const faviconRes = await fetch(`${BASE}/favicon.svg`);
  const favicon = await faviconRes.text();
  check('the favicon is served', faviconRes.ok, `HTTP ${faviconRes.status}`);
  check(
    'the favicon is served as an SVG',
    (faviconRes.headers.get('content-type') ?? '').includes('image/svg+xml'),
    faviconRes.headers.get('content-type') ?? '(none)',
  );
  check('the favicon is valid XML markup', /^<svg[\s\S]*<\/svg>\s*$/.test(favicon.trim()));
  check('the favicon scales without a fixed raster size', favicon.includes('viewBox="0 0 32 32"'));
  check('the favicon uses the deep purple brand colour', /#4C1D95/i.test(favicon));
  check('the favicon uses the amethyst brand colour', /#7E22CE/i.test(favicon));
  check('the favicon carries an accessible name', /<title>MYP Bridge<\/title>/.test(favicon));
  check('the favicon is small enough to stay crisp', /width="32"|viewBox/.test(favicon));

  section('Guides frontend');

  for (const id of ['panel-guides', 'guide-index-list', 'guide-panel', 'guide-context']) {
    check(`markup exposes #${id}`, html.includes(`id="${id}"`));
  }
  check('nav links to the guides panel', html.includes('data-panel="guides"'));

  const guidesMod = await (await fetch(`${BASE}/js/guides.js`)).text();
  const cardMod = await (await fetch(`${BASE}/js/termcard.js`)).text();
  check('guides module renders score bands', guidesMod.includes('bandRows'));
  check('guides module renders criteria marks', guidesMod.includes('criterion__mark'));
  check('guides module renders dialogue turns', guidesMod.includes('turn__text'));
  check('guides module resolves terms from the API payload', guidesMod.includes('data-record'));

  /*
   * The renderer is data-driven, so a field-name drift between the JSON payload
   * and the template would render silently empty sections. Assert the exact
   * payload keys the module reads.
   */
  for (const [field, re] of [
    ['criterion id', /criterion\.id/],
    ['framework overview', /guide\.framework_overview/],
    ['assessment objectives', /guide\.assessment_objectives/],
    ['eAssessment expectations', /guide\.eassessment_expectations/],
    ['global contexts', /guide\.global_contexts/],
    ['pathway note', /p\.note/],
    ['pathway criteria focus', /p\.criteria_focus/],
    ['contextual definition', /entry\.contextual_definition/],
    ['didactic note', /dialogue\.didactic_note/],
    ['segment value', /seg\.value/],
    ['speaker role', /turn\.speaker_role/],
  ]) {
    check(`guides module reads the payload ${field} field`, re.test(guidesMod));
  }
  for (const stale of ['criterion.mark', 'guide.overview', 'didactic_point', 'contextual_meaning', 'seg.text']) {
    check(`guides module no longer reads ${stale}`, !guidesMod.includes(stale));
  }
  check('term dialog uses a native modal dialog', cardMod.includes('<dialog') || cardMod.includes('createElement'));
  check('term dialog uses showModal for focus trapping', cardMod.includes('showModal'));
  check('term dialog returns focus to the trigger', cardMod.includes('lastFocus'));

  const appMod = await (await fetch(`${BASE}/js/app.js`)).text();
  check('app bootstraps the guides panel', appMod.includes('initGuides'));
  check('app wires cross-tab glossary navigation', appMod.includes('searchTerm'));

  // ------------------------------------------------ native select styling ----
  section('Native select styling');

  const selectRule = (() => {
    // The bare `select { ... }` block, not any descendant compound rule.
    const m = css.match(/(?:^|\n)select\s*\{([^}]*)\}/);
    return m ? m[1] : '';
  })();

  check('select rule exists', selectRule.length > 0);
  for (const prop of ['appearance: none', '-webkit-appearance: none', '-moz-appearance: none']) {
    check(`select sets ${prop}`, selectRule.includes(prop));
  }
  check(
    'select paints an inline SVG chevron',
    selectRule.includes('background-image') && selectRule.includes('data:image/svg+xml'),
  );
  check(
    'select chevron uses the primary purple',
    selectRule.includes('%234C1D95') || selectRule.includes('#4C1D95'),
  );
  check('select chevron is positioned right 12px center', /background-position:\s*right 12px center/.test(selectRule));
  check('select reserves a 36px chevron gutter', /padding:[^;]*36px/.test(selectRule));
  check('select uses the ivory surface', /background-color:\s*var\(--surface\)/.test(selectRule));
  check('select uses the lilac border', /border:\s*1px solid var\(--line\)/.test(selectRule));
  check('select radius is 6px', /border-radius:\s*6px/.test(selectRule));
  check('select font-size is 14px', /font-size:\s*14px/.test(selectRule));
  check('select line-height is 1.5', /line-height:\s*1\.5/.test(selectRule));
  check('select text colour is the body ink', /color:\s*var\(--ink-body\)/.test(selectRule));

  const selectFocus = css.match(/select:focus-visible\s*\{([^}]*)\}/);
  check('select has a focus-visible rule', Boolean(selectFocus));
  check('select focus clears the default outline', /outline:\s*none/.test(selectFocus?.[1] ?? ''));
  check('select focus border is amethyst', /border-color:\s*var\(--amethyst-600\)/.test(selectFocus?.[1] ?? ''));
  check(
    'select focus ring is the 3px amethyst halo',
    /box-shadow:\s*0 0 0 3px rgba\(126, 34, 206, 0\.15\)/.test(selectFocus?.[1] ?? ''),
  );
  check('legacy IE arrow is suppressed', /select::-ms-expand\s*\{[^}]*display:\s*none/.test(css));
  check('dropdown options follow the surface', /select option\s*\{[^}]*background-color/.test(css));

  // Every select in the markup must be covered by the element selector.
  const selectCount = (html.match(/<select/g) ?? []).length;
  check('markup contains native selects', selectCount >= 5, `found ${selectCount}`);

  // ------------------------------------------------ form control alignment ----
  const sharedHeight = declarationsFor(css, '.searchbar__input');
  const buttonDecls = declarationsFor(css, '.button');
  const searchbarDecls = declarationsFor(css, '.searchbar');
  const searchButtonDecls = declarationsFor(css, '.searchbar .button');

  check('button height is 40px', /height:\s*40px/.test(buttonDecls));

  // The glossary search pair is its own 42px rhythm, independent of the 40px
  // form controls used elsewhere.
  check('search input height is 42px', /height:\s*42px/.test(sharedHeight));
  check('search button height is 42px', /height:\s*42px/.test(searchButtonDecls));

  check('search input uses a 6px radius', /border-radius:\s*6px/.test(sharedHeight));
  check('search input uses 14px type', /font-size:\s*14px/.test(sharedHeight));
  check('search input line-height is 1.5', /line-height:\s*1\.5/.test(sharedHeight));
  check('search input has a focus-visible ring', /box-shadow:\s*0 0 0 3px rgba\(126, 34, 206, 0\.15\)/.test(css));

  check('button uses a 6px radius', /border-radius:\s*6px/.test(buttonDecls));
  check('button centres its label', /align-items:\s*center/.test(buttonDecls));
  check('button uses 14px type', /font-size:\s*14px/.test(buttonDecls));
  check('button uses horizontal padding only', /padding:\s*0 16px/.test(buttonDecls));

  // ----------------------------------------------- glossary full-width bar ----
  section('Glossary search layout');

  check('searchbar is a flex container', /display:\s*flex/.test(searchbarDecls));
  check('searchbar spans the container width', /width:\s*100%/.test(searchbarDecls));
  check('searchbar uses a 12px gap', /gap:\s*12px/.test(searchbarDecls));
  check('searchbar aligns items on one axis', /align-items:\s*center/.test(searchbarDecls));
  check('search input flexes to fill the row', /flex:\s*1 1 auto/.test(sharedHeight));
  check('search input declares full width', /width:\s*100%/.test(sharedHeight));
  // Without this the input refuses to shrink below its intrinsic size and the
  // row collapses back to the cramped fixed-width box.
  check('search input may shrink below its intrinsic width', /min-width:\s*0/.test(sharedHeight));
  check('search button keeps its intrinsic width', /flex:\s*0 0 auto/.test(searchButtonDecls));
  check('search input keeps the ivory surface', /background-color:\s*var\(--surface\)/.test(sharedHeight));
  check('search input keeps the 1px lavender border', /border:\s*1px solid var\(--line\)/.test(sharedHeight));

  // A control must not be declared twice with conflicting values.
  const buttonBlocks = topLevelRules(css).filter((r) => r.selectors.includes('.button'));
  check('.button is declared in a small number of rules', buttonBlocks.length <= 3, `${buttonBlocks.length} blocks`);
  const radiusValues = [...buttonDecls.matchAll(/border-radius:\s*([^;]+);/g)].map((m) => m[1].trim());
  check(
    '.button never declares conflicting radii',
    new Set(radiusValues).size <= 1,
    radiusValues.join(' | '),
  );

  // ------------------------------------------------------- slider engine ----
  section('Slider engine');

  check('slider seeds a placeholder progress', /\.slider\s*\{[^}]*--slider-progress:\s*50%/.test(css));

  const webkitTrack = css.match(/\.slider::-webkit-slider-runnable-track\s*\{([^}]*)\}/);
  const mozTrack = css.match(/\.slider::-moz-range-track\s*\{([^}]*)\}/);
  check('webkit track is styled', Boolean(webkitTrack));
  check('moz track is styled', Boolean(mozTrack));
  for (const [label, rule] of [['webkit', webkitTrack], ['moz', mozTrack]]) {
    check(`${label} track height is 8px`, /height:\s*8px/.test(rule?.[1] ?? ''));
    check(`${label} track radius is 4px`, /border-radius:\s*4px/.test(rule?.[1] ?? ''));
    check(`${label} track uses a left-to-right gradient`, /linear-gradient\(\s*to right/.test(rule?.[1] ?? ''));
    check(`${label} fill stops at the progress variable`, /--slider-progress\)/.test(rule?.[1] ?? ''));
    check(
      `${label} unfilled stop is the container tint`,
      /var\(--container-tint\)\s+var\(--slider-progress\),\s*var\(--container-tint\)\s+100%/.test(rule?.[1] ?? ''),
    );
  }

  const webkitThumb = css.match(/\.slider::-webkit-slider-thumb\s*\{([^}]*)\}/);
  const mozThumb = css.match(/\.slider::-moz-range-thumb\s*\{([^}]*)\}/);
  for (const [label, rule] of [['webkit', webkitThumb], ['moz', mozThumb]]) {
    check(`${label} thumb is 18px wide`, /width:\s*18px/.test(rule?.[1] ?? ''));
    check(`${label} thumb is 18px tall`, /height:\s*18px/.test(rule?.[1] ?? ''));
    check(`${label} thumb is circular`, /border-radius:\s*50%/.test(rule?.[1] ?? ''));
    check(`${label} thumb is imperial violet`, /background:\s*var\(--violet-700\)/.test(rule?.[1] ?? ''));
    check(
      `${label} thumb animates transform and background only`,
      /transition:\s*transform 0\.15s ease, background-color 0\.15s ease/.test(rule?.[1] ?? ''),
    );
    check(
      `${label} thumb avoids layout-triggering transitions`,
      !/transition:[^;]*(width|height|margin)/.test(rule?.[1] ?? ''),
    );
  }

  check(
    'hover and active scale the thumb',
    /\.slider:hover::-webkit-slider-thumb[\s\S]*?transform:\s*scale\(1\.15\)/.test(css),
  );
  check(
    'hover thumb turns amethyst',
    /\.slider:hover::-webkit-slider-thumb[\s\S]*?background:\s*var\(--amethyst-600\)/.test(css),
  );

  const equivNow = await (await fetch(`${BASE}/js/equivalency.js`)).text();
  check('slider progress is written as a CSS variable', /setProperty\('--slider-progress'/.test(equivNow));
  check('slider progress reads the input min and max', /els\.slider\.min/.test(equivNow) && /els\.slider\.max/.test(equivNow));
  check('slider progress accounts for thumb width', /full - 18/.test(equivNow));
  check('slider re-renders through requestAnimationFrame', /requestAnimationFrame/.test(equivNow));
  check('slider input is scheduled, not rendered directly', /addEventListener\('input', schedule\)/.test(equivNow));
  check('slider change flushes the pending frame', /addEventListener\('change', flush\)/.test(equivNow));
  check('slider recomputes progress on resize', /ResizeObserver/.test(equivNow));
  check('slider guards a zero-width layout', /if \(!full\)/.test(equivNow));

  // The gradient is a function of layout width, so string matching cannot prove
  // it is correct. Drive the real module and read the value it writes.
  section('Slider progress engine');

  const sliderEls = Object.fromEntries(
    ['subject-select', 'subject-note', 'grade-slider', 'grade-output', 'grade-band-label', 'equivalency-readout'].map(
      (id) => [id, new StubElement()],
    ),
  );
  const dom = installDom(sliderEls, { raf: 'manual' });

  const gradeSlider = sliderEls['grade-slider'];
  gradeSlider.min = '1';
  gradeSlider.max = '8';
  gradeSlider.value = '5';
  gradeSlider.clientWidth = 418;

  const equivModule = await import('../public/js/equivalency.js');
  equivModule.__setMatrix([
    {
      grade: 5,
      percentRange: '62.5-68.75',
      band: 'B',
      profile: 'MYP',
      descriptor: 'x',
      criterionBand: 'y',
      igcse: '-',
      cbse: '-',
      icse: '-',
      stateBoard: '-',
    },
  ]);
  equivModule.__setSubjects([{ id: 'sciences', short: 'Sciences' }]);

  const progressOf = () => gradeSlider.style.getPropertyValue('--slider-progress');

  equivModule.__setProgress();
  /*
   * A range of 1-8 has seven intervals, not eight, so grade 5 sits 4/7 along
   * the track. On 418px that is 4/7 of the 400px usable span plus the 9px
   * half-thumb inset: (228.57 + 9) / 418 = 56.84%.
   */
  check('mid-range grade fills proportionally to the range', progressOf() === '56.84%', progressOf());

  gradeSlider.value = '1';
  equivModule.__setProgress();
  check('minimum grade fills one half-thumb', progressOf() === '2.15%', progressOf());

  gradeSlider.value = '8';
  equivModule.__setProgress();
  check('maximum grade fills to the other half-thumb', progressOf() === '97.85%', progressOf());

  gradeSlider.clientWidth = 0;
  gradeSlider.value = '4';
  equivModule.__setProgress();
  check('unlaid-out slider falls back to the raw ratio', progressOf() === '42.86%', progressOf());
  gradeSlider.clientWidth = 418;

  // A burst of input events must collapse into a single frame.
  equivModule.__renderReadout();
  gradeSlider.value = '2';
  equivModule.__schedule();
  gradeSlider.value = '3';
  equivModule.__schedule();
  gradeSlider.value = '4';
  equivModule.__schedule();
  gradeSlider.value = '5';
  equivModule.__schedule();
  check('a drag burst queues exactly one frame', dom.pendingFrames() === 1, `${dom.pendingFrames()} frames`);

  dom.flushFrames();
  check('the queued frame clears after rendering', dom.pendingFrames() === 0);
  check('the flush renders the final slider value', sliderEls['grade-output'].textContent === '5');

  equivModule.__schedule();
  equivModule.__flush();
  check('flush cancels a frame still in flight', dom.pendingFrames() === 0);
  check('flush leaves the readout rendered', sliderEls['equivalency-readout'].innerHTML.includes('matrix'));

  // ------------------------------------------------------- guides runtime ----
  section('Guides runtime');

  const responses = new Map();
  const guideDomIds = [
    'guide-index-list',
    'guide-panel',
    'guide-context',
    'guide-empty',
    'glossary-form',
    'glossary-input',
    'glossary-status',
    'glossary-results',
  ];
  installDom(Object.fromEntries(guideDomIds.map((id) => [id, new StubElement()])));
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    const body = responses.get(String(url).split('?')[0]);
    if (!body) return { ok: false, status: 404, json: async () => ({ status: 'error' }) };
    return { ok: true, status: 200, json: async () => body };
  };

  const guidePayload = (id, abbr, criteria = 1) => ({
    status: 'success',
    data: {
      id,
      name: `${abbr} subject`,
      abbreviation: abbr,
      pathway: 'Core pathway',
      levels: 'MYP Years 1-5',
      framework_overview: 'x'.repeat(90),
      global_contexts: ['Human Ingenuity'],
      assessment_objectives: ['Objective one'],
      eassessment_expectations: ['Expectation one'],
      criteria: Array.from({ length: criteria }, (_, i) => ({
        id: String.fromCharCode(65 + i),
        name: `Criterion ${String.fromCharCode(65 + i)}`,
        term_anchors: ['Anatomy'],
        bands: Object.fromEntries(['1-2', '3-4', '5-6', '7-8'].map((b) => [b, 'x'.repeat(80)])),
        terms: [{ term: 'Anatomy', formal_definition: 'Structure of the body.' }],
      })),
    },
  });

  const stubGuides = [
    ['design', 'DES'],
    ['physical-and-health-education', 'PHE'],
    ['interdisciplinary-units', 'IDU'],
    ['visual-arts', 'VA'],
    ['service-as-action', 'SAA'],
    ['core-pathways', 'CORE'],
  ];

  for (const [id, abbr] of stubGuides) {
    responses.set(`/api/v1/guides/${id}`, guidePayload(id, abbr, abbr === 'SAA' ? 3 : 4));
  }

  // The index the controller reads on mount, deliberately out of alphabetical
  // order so a "first element wins" implementation cannot pass by accident.
  responses.set('/api/v1/guides', {
    status: 'success',
    count: stubGuides.length,
    guides: [...stubGuides]
      .reverse()
      .map(([id, abbr]) => ({ id, abbreviation: abbr, name: `${abbr} subject` })),
  });
  // Transcripts resolve after the guide renders, so the mount only needs a
  // well-formed (if minimal) dialogue envelope here.
  responses.set('/api/v1/guides/dialogue', {
    status: 'success',
    count: 1,
    dialogues: ['grade9-phe-fitness-laboratory'],
    data: [],
  });

  const guideModule = await import('../public/js/guides.js');

  for (const [id, abbr] of stubGuides) {
    let rendered = null;
    let threw = null;
    try {
      await guideModule.__selectGuide(id);
      rendered = guideModule.__els.panel.innerHTML;
    } catch (err) {
      threw = err;
    }
    check(`${abbr} tab renders without throwing`, threw === null, threw?.message ?? '');
    check(
      `${abbr} tab renders the guide body`,
      Boolean(rendered) && rendered.includes('guide__title'),
    );
    check(`${abbr} tab renders its bands`, Boolean(rendered) && rendered.includes('bands__range'));
    check(
      `${abbr} tab renders every criterion`,
      rendered === null || (rendered.match(/class="criterion"/g) ?? []).length === (abbr === 'SAA' ? 3 : 4),
    );
    check(
      `${abbr} tab does not fall back to an error`,
      rendered === null || !rendered.includes('class="error"'),
    );
  }

  check(
    'guide renderer no longer double-unwraps the response envelope',
    !/guideView\(guide\.data\)/.test(guidesMod),
  );

  // ------------------------------------------------ guides initial state ----
  section('Guides initial state');

  // The crash under repair: init called a setDialogues helper that never existed.
  check(
    'no call to an undefined setDialogues remains',
    !/(?<!__)\bsetDialogues\s*\(/i.test(guidesMod),
  );
  check(
    'dialogues are cached through the declared module state',
    /allDialogues\s*=\s*res\.data\s*\?\?\s*\[\]/.test(guidesMod),
  );

  // Default landing view.
  const defaultId = guideModule.__defaultGuideId([
    { id: 'visual-arts' },
    { id: 'core-pathways' },
    { id: 'design' },
  ]);
  check('CORE is chosen regardless of payload order', defaultId === 'core-pathways', String(defaultId));
  check(
    'the default falls back to the first guide when CORE is absent',
    guideModule.__defaultGuideId([{ id: 'design' }, { id: 'visual-arts' }]) === 'design',
  );
  check('an empty guide list yields no default', guideModule.__defaultGuideId([]) === null);
  check(
    'the CORE default is declared as a named constant, not a sort accident',
    /const DEFAULT_GUIDE_ID = 'core-pathways'/.test(guidesMod),
  );

  // Overview landing card.
  guideModule.__showOverview();
  const overview = guideModule.__els.empty.innerHTML;
  check('overview card is revealed when nothing is selected', guideModule.__els.empty.hidden === false);
  check(
    'overview card carries the required prompt',
    overview.includes(
      'Select a subject group from the left menu to explore criterion performance bands and classroom dialogue examples.',
    ),
  );
  check('overview card clears any stale guide body', guideModule.__els.panel.innerHTML === '');
  check('overview card clears any stale transcript', guideModule.__els.context.innerHTML === '');

  guideModule.__showOverview('Dialogue service unavailable.');
  check('overview card can surface a load failure', guideModule.__els.empty.innerHTML.includes('class="error"'));

  // Transcripts are enhancement only: a failing dialogue endpoint must not
  // destroy the already-rendered guide panel.
  check(
    'transcripts load after the guide renders, not before',
    guidesMod.indexOf('await selectGuide(first)') < guidesMod.indexOf('await loadDialogues()'),
  );
  check('a transcript failure is caught and does not throw', /catch \(err\)[\s\S]{0,200}console\.warn/.test(guidesMod));

  // init() itself must complete cleanly against the stubbed API.
  const beforeOverview = guideModule.__els.empty.innerHTML;
  guideModule.__setDialogues([]);
  let initThrew = null;
  try {
    await guideModule.__initGuides();
  } catch (err) {
    initThrew = err;
  }
  check('initGuides completes without throwing', initThrew === null, initThrew?.message ?? '');
  check(
    'mounting the tab renders the default guide rather than an error',
    guideModule.__els.panel.innerHTML.includes('guide__title'),
  );
  check(
    'mounting the tab does not leave the overview card showing',
    guideModule.__els.empty.hidden === true || guideModule.__els.empty.innerHTML !== beforeOverview,
  );

  // markActive writes onto the selected button, so this has to assert against
  // the live selection: setAttribute does not alter the innerHTML text.
  const menuButtons = guideModule.__els.index.querySelectorAll('.guide-index__btn');
  check('the subject menu renders one button per guide', menuButtons.length === 6, `${menuButtons.length} buttons`);
  const markedCurrent = menuButtons.filter((b) => b.getAttribute('aria-current') === 'true');
  check('exactly one group is marked current', markedCurrent.length === 1, `${markedCurrent.length} marked`);
  check(
    'CORE is the current group after mount',
    markedCurrent[0]?.dataset.guide === 'core-pathways',
    markedCurrent[0]?.dataset.guide ?? '(none)',
  );
  check(
    'every other group is marked not-current',
    menuButtons.filter((b) => b.getAttribute('aria-current') === 'false').length === 5,
  );

  // A malformed envelope must produce a message, never a blank panel.
  responses.set('/api/v1/guides/broken', { status: 'success', data: null });
  let broke = null;
  try {
    await guideModule.__selectGuide('broken');
    broke = guideModule.__els.panel.innerHTML;
  } catch (err) {
    broke = `threw ${err.message}`;
  }
  check('malformed guide payload renders an error, not a throw', broke.includes('class="error"'));

  responses.set('/api/v1/guides/notfound', { status: 'error', message: 'Subject guide not found.' });
  await guideModule.__selectGuide('notfound');
  check(
    'failed guide lookup surfaces the API message',
    guideModule.__els.panel.innerHTML.includes('Subject guide not found.'),
  );

  check('guides module shows a skeleton while loading', guidesMod.includes('skeleton'));
  check('loading skeleton is announced as busy', guidesMod.includes('aria-busy'));
  check('guide view reads abbreviation defensively', /guide\.abbreviation \?/.test(guidesMod));
  check('guide view tolerates a missing criteria array', guidesMod.includes('Array.isArray(guide.criteria)'));
  check(
    'guide view tolerates an empty transcript',
    guidesMod.includes('No transcript is available'),
  );

  // ------------------------------------------------- transcript tailoring ----
  const dialoguePayload = {
    status: 'success',
    data: [
      {
        id: 'd-iau',
        title: 'Individuals and Societies transcript',
        year_group: 'Grade 9',
        guide_ids: ['interdisciplinary-units'],
        subjects: ['Individuals & Societies'],
        setting: 'Seminar',
        context: 'A seminar on urban change.',
        didactic_note: 'x'.repeat(50),
        turns: [
          {
            id: 't1',
            speaker: 'Teacher',
            speaker_role: 'teacher',
            text: 'How does the source bias the account?',
            segments: [{ type: 'text', value: 'How does the source bias the account?' }],
          },
        ],
        term_map: [],
      },
      {
        id: 'd-physics',
        title: 'Sciences transcript',
        year_group: 'Grade 10',
        guide_ids: ['core-pathways'],
        subjects: ['Sciences'],
        setting: 'Lab',
        context: 'A practical investigation debrief.',
        didactic_note: 'x'.repeat(50),
        turns: [
          {
            id: 't1',
            speaker: 'Teacher',
            speaker_role: 'teacher',
            text: 'How reliable is the measurement?',
            segments: [{ type: 'text', value: 'How reliable is the measurement?' }],
          },
        ],
        term_map: [],
      },
    ],
  };
  responses.set('/api/v1/guides/dialogue', dialoguePayload);
  guideModule.__setDialogues(dialoguePayload.data);

  await guideModule.__selectGuide('core-pathways');
  const coreContext = guideModule.__els.context.innerHTML;
  check('transcript is scoped to the selected group', coreContext.includes('Sciences transcript'));
  check('transcript excludes unrelated groups', !coreContext.includes('Individuals and Societies transcript'));
  check(
    'a matched transcript carries no fallback warning',
    !coreContext.includes('No transcript is recorded'),
  );

  await guideModule.__selectGuide('interdisciplinary-units');
  const iduContext = guideModule.__els.context.innerHTML;
  check('switching group swaps the transcript', iduContext !== coreContext);
  check(
    'the selected group sees its own transcript',
    iduContext.includes('Individuals and Societies transcript') && !iduContext.includes('Sciences transcript'),
  );

  // An unrelated group must say so rather than silently borrow another subject.
  responses.set('/api/v1/guides/design', guidePayload('design', 'DES'));
  await guideModule.__selectGuide('design');
  check(
    'a group with no transcript is told so explicitly',
    guideModule.__els.context.innerHTML.includes('No transcript is recorded'),
  );

  // Label matching remains as a fallback for payloads without guide_ids.
  guideModule.__setDialogues([
    {
      id: 'legacy',
      title: 'Legacy transcript',
      subjects: ['Physical & Health Education'],
      turns: [
        {
          id: 't1',
          speaker: 'Teacher',
          speaker_role: 'teacher',
          segments: [{ type: 'text', value: 'How did you control the variables?' }],
        },
      ],
      term_map: [],
    },
  ]);
  await guideModule.__selectGuide('physical-and-health-education');
  check(
    'payloads without guide_ids still match on normalised labels',
    guideModule.__els.context.innerHTML.includes('Legacy transcript'),
  );
  check('ampersand subject labels normalise to "and"', guidesMod.includes("replace(/&/g, 'and')"));
  check('guide_ids is the authoritative dialogue match', guidesMod.includes('declared.includes(guide.id)'));

  // The stub fetch only answers the guide endpoints. Restore the real client so
  // the remaining static-file checks still reach the running server.
  globalThis.fetch = realFetch;

  const glossaryMod = await (await fetch(`${BASE}/js/glossary.js`)).text();
  check('glossary exposes a programmatic entry point', glossaryMod.includes('export async function searchTerm'));

  const noGuideEmoji = emoji.test(html + css + guidesMod + cardMod);
  check('no emoji in guide frontend', !noGuideEmoji);
} finally {
  await cleanup();
}

console.log(`\n${passed} passed, ${failures.length} failed`);
if (failures.length) {
  console.error('\nFailed assertions:');
  for (const f of failures) console.error(`  - ${f}`);
  process.exit(1);
}
console.log('All verification checks passed.');
