/**
 * Reproduction for the Subject Guides crash, and a check that every subject tab
 * now renders with its own classroom transcript.
 *
 * Feeds the real API payload through the real renderer and reports the outcome.
 * Run directly: node --no-warnings scripts/repro-guides.mjs
 */
import { readFileSync, readdirSync } from 'node:fs';

import { installDom, StubElement } from './dom-stub.js';

const ids = [
  'guide-index-list',
  'guide-panel',
  'guide-context',
  'guide-empty',
  'glossary-form',
  'glossary-input',
  'glossary-status',
  'glossary-results',
];
installDom(Object.fromEntries(ids.map((id) => [id, new StubElement()])));

/** Stands in for the api client so no server is needed. */
const RESPONSES = new Map();
globalThis.fetch = async (url) => {
  const key = String(url).split('?')[0];
  const body = RESPONSES.get(key);
  if (!body) return { ok: false, status: 404, json: async () => ({ status: 'error' }) };
  return { ok: true, status: 200, json: async () => body };
};

/**
 * Loads the authored payload from disk rather than inventing one, so this
 * script exercises the data that actually ships.
 */
function loadPayloads() {
  const guides = new Map();
  const dialogues = [];

  for (const file of readdirSync('src/data/guides').filter((f) => f.endsWith('.json'))) {
    const doc = JSON.parse(readFileSync(`src/data/guides/${file}`, 'utf8'));
    if (Array.isArray(doc?.turns)) dialogues.push(doc);
    else guides.set(doc.id, doc);
  }
  return { guides, dialogues };
}

const { guides, dialogues } = loadPayloads();

for (const [id, guide] of guides) {
  RESPONSES.set(`/api/v1/guides/${id}`, { status: 'success', data: guide });
}
RESPONSES.set('/api/v1/guides/dialogue', { status: 'success', data: dialogues });

const { __selectGuide, __setDialogues, __els } = await import('../public/js/guides.js');
__setDialogues(dialogues);

let failures = 0;

console.log('guide rendering');
for (const [id, guide] of guides) {
  try {
    await __selectGuide(id);
    const html = __els.panel.innerHTML;
    const ok = html.includes('guide__title') && !html.includes('class="error"');
    console.log(`${ok ? 'OK  ' : 'BAD '} ${guide.abbreviation.padEnd(5)} ${html.length} bytes`);
    if (!ok) failures++;
  } catch (err) {
    failures++;
    console.log(`THREW ${guide.abbreviation.padEnd(5)} ${err.constructor.name}: ${err.message}`);
  }
}

console.log('\ntranscript tailoring');
for (const [id, guide] of guides) {
  await __selectGuide(id);
  const html = __els.context.innerHTML;
  const expected = dialogues.filter((d) => d.guide_ids.includes(id));
  const foreign = dialogues.filter((d) => !d.guide_ids.includes(id));
  const showsOwn = expected.every((d) => html.includes(d.title));
  const leaks = foreign.filter((d) => html.includes(d.title));
  const ok = showsOwn && leaks.length === 0;
  console.log(`${ok ? 'OK  ' : 'BAD '} ${guide.abbreviation.padEnd(5)} ${expected.length} transcript(s)`);
  if (!ok) {
    failures++;
    if (!showsOwn) console.log(`       missing: ${expected.map((d) => d.id).join(', ') || '(none)'}`);
    if (leaks.length) console.log(`       leaked : ${leaks.map((d) => d.id).join(', ')}`);
  }
}

console.log(failures ? `\n${failures} failing` : '\nall tabs render with their own transcript');
process.exit(failures ? 1 : 0);
