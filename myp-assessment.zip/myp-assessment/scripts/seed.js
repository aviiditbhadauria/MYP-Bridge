/**
 * Seeds the question bank, glossary and grade boundaries.
 *
 * Idempotent: re-running updates seeded content in place without touching user
 * streaks, sessions or attempts. Pass --reset to clear those ledgers as well.
 */
import { randomUUID } from 'node:crypto';
import { getDb, truncateAll, closeDb, DB_PATH } from '../src/db.js';
import { QUESTION_BANK, validateQuestions } from '../src/data/questions.index.js';
import keyTerms, { validateTerms } from '../src/data/terms.index.js';

const reset = process.argv.includes('--reset');
const db = getDb();

console.log(`Seeding ${DB_PATH}`);
if (reset) {
  truncateAll(db);
  console.log('  cleared all existing rows (--reset)');
}

// Questions -----------------------------------------------------------------
validateQuestions(QUESTION_BANK);

/*
 * Upsert rather than DELETE-then-INSERT. Question ids are stable across runs,
 * so replacing rows in place keeps every practice_attempts foreign key valid.
 * Deleting the bank wholesale would break re-seeding a database that already
 * holds attempts, which the idempotency guarantee above promises is allowed.
 */
const upsertQuestion = db.prepare(`
  INSERT INTO questions (
    id, subject_group, target_criterion, myp_phase_level,
    question_text, command_term, options,
    correct_option_index, rubric_rationale
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(id) DO UPDATE SET
    subject_group        = excluded.subject_group,
    target_criterion     = excluded.target_criterion,
    myp_phase_level      = excluded.myp_phase_level,
    question_text        = excluded.question_text,
    command_term         = excluded.command_term,
    options              = excluded.options,
    correct_option_index = excluded.correct_option_index,
    rubric_rationale     = excluded.rubric_rationale
`);

db.exec('BEGIN');
for (const q of QUESTION_BANK) {
  upsertQuestion.run(
    q.id,
    q.subject_group,
    q.target_criterion,
    q.myp_phase_level,
    q.question_text,
    q.command_term,
    JSON.stringify(q.options),
    q.correct_option_index,
    q.rubric_rationale,
  );
}
/*
 * Retire questions and terms that have left the source data. Rows referenced by
 * practice_attempts are kept so historic attempts stay readable.
 */
/*
 * `value` is the column json_each exposes for array elements. Its own `id`
 * column is an internal element identifier, not the string payload.
 */
const prune = db.prepare(`
  DELETE FROM questions
   WHERE id NOT IN (SELECT value FROM json_each(?))
     AND id NOT IN (SELECT question_id FROM practice_attempts)
`);
prune.run(JSON.stringify(QUESTION_BANK.map((q) => q.id)));
db.exec('COMMIT');
console.log(`  questions : ${QUESTION_BANK.length}`);

// Key terms -----------------------------------------------------------------
validateTerms(keyTerms);

/*
 * Terms are keyed by name so a redefinition updates the existing row instead of
 * colliding with the UNIQUE(term) constraint.
 */
const upsertTerm = db.prepare(`
  INSERT INTO key_terms (
    id, term, subject_group, criterion_association, category,
    formal_definition, myp_context_example, related_terms
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(term) DO UPDATE SET
    subject_group         = excluded.subject_group,
    criterion_association = excluded.criterion_association,
    category              = excluded.category,
    formal_definition     = excluded.formal_definition,
    myp_context_example   = excluded.myp_context_example,
    related_terms         = excluded.related_terms
`);

db.exec('BEGIN');
for (const t of keyTerms) {
  upsertTerm.run(
    `trm_${randomUUID().slice(0, 8)}`,
    t.term,
    t.subject_group,
    t.criterion_association ?? null,
    t.category,
    t.formal_definition,
    t.myp_context_example,
    JSON.stringify(t.related_terms ?? []),
  );
}
db.prepare(
  `DELETE FROM key_terms
    WHERE term NOT IN (SELECT value FROM json_each(?))`,
).run(JSON.stringify(keyTerms.map((t) => t.term)));
db.exec('COMMIT');
console.log(`  key terms : ${keyTerms.length}`);

// Report --------------------------------------------------------------------
const bySubject = db
  .prepare(
    `SELECT subject_group, COUNT(*) AS n FROM questions
     GROUP BY subject_group ORDER BY subject_group`,
  )
  .all();
const byCriterion = db
  .prepare(
    `SELECT target_criterion AS c, COUNT(*) AS n FROM questions
     GROUP BY target_criterion ORDER BY target_criterion`,
  )
  .all();

console.log('\n  Distribution by subject group');
for (const row of bySubject) {
  console.log(`    ${row.subject_group.padEnd(28)} ${row.n}`);
}
console.log('\n  Distribution by criterion');
for (const row of byCriterion) {
  console.log(`    ${`Criterion ${row.c}`.padEnd(32)} ${row.n}`);
}

closeDb();
console.log('\nSeed complete.');
