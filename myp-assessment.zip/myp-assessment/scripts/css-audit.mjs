/**
 * Reports class names referenced by markup or scripts but absent from the
 * stylesheet. Run directly: node --no-warnings scripts/css-audit.mjs
 */
import { readFileSync } from 'node:fs';

const css = readFileSync('public/css/styles.css', 'utf8');
const html = readFileSync('public/index.html', 'utf8');

const scripts = [
  'public/js/app.js',
  'public/js/api.js',
  'public/js/equivalency.js',
  'public/js/practice.js',
  'public/js/glossary.js',
  'public/js/guides.js',
  'public/js/termcard.js',
  'public/js/streak.js',
]
  .map((f) => readFileSync(f, 'utf8'))
  .join('\n');

/*
 * The audit only reads `class` attributes. Tokens picked up from other
 * attributes, such as aria-selected or an element id, are not class names and
 * must not be reported, so scanning is deliberately narrow.
 */
const CLASS_ATTR = /\sclass\s*=\s*(?:"([^"]*)"|'([^']*)'|`([^`]*)`)/g;

const used = new Set();

function collect(source) {
  for (const m of source.matchAll(CLASS_ATTR)) {
    const value = m[1] ?? m[2] ?? m[3] ?? '';
    // Drop ${...} interpolations; only literal class names can be checked here.
    const literal = value.replace(/\$\{[^}]*\}/g, ' ');
    for (const c of literal.split(/\s+/)) {
      // A trailing hyphen is a partial token, e.g. `turn--${kind}`, whose real
      // class is resolved at runtime. Those are checked as prefixes instead.
      if (c && !c.endsWith('-') && /^[A-Za-z][\w-]*$/.test(c)) used.add(c);
    }
  }
}

collect(html);
collect(scripts);

/*
 * Classes built by interpolating a variant prefix, such as `turn--${kind}`,
 * never appear whole in a literal. The prefix itself is checked separately.
 */
const variantPrefixes = [
  ...new Set([...scripts.matchAll(/["'`]([a-z][a-z0-9-]*--)["'`]/gi)].map((m) => m[1])),
];
const missingPrefixes = variantPrefixes
  .filter((prefix) => !new RegExp(`\\.${prefix}`, 'i').test(css))
  .sort();

const defined = new Set([...css.matchAll(/\.([A-Za-z][\w-]*)/g)].map((m) => m[1]));
const missing = [...used].filter((c) => !defined.has(c)).sort();

/*
 * A class used only as a grouping or naming hook carries no declarations of its
 * own, which is legitimate as long as its BEM block is styled. Those are
 * reported apart from genuine missing rules so the output stays actionable.
 */
const blockOf = (c) => c.split(/--|__/)[0];
const hooks = missing.filter((c) => defined.has(blockOf(c)));
const absent = missing.filter((c) => !hooks.includes(c));

console.log(`referenced classes : ${used.size}`);
console.log(`styled             : ${used.size - missing.length}`);
console.log(`unstyled hooks     : ${hooks.length ? hooks.join(', ') : '(none)'}`);
console.log(`missing rules      : ${absent.length ? absent.join(', ') : '(none)'}`);
console.log(`variant prefixes   : ${variantPrefixes.join(', ') || '(none)'}`);
console.log(
  `missing prefixes   : ${missingPrefixes.length ? missingPrefixes.join(', ') : '(none)'}`,
);

process.exit(absent.length || missingPrefixes.length ? 1 : 0);
