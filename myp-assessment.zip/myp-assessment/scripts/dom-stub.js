/**
 * Minimal DOM stub.
 *
 * Enough of the browser surface for the guide renderer to run under Node, which
 * is how the Subject Guides crash was reproduced without a browser. Deliberately
 * tiny: it is a test harness, not a DOM implementation.
 */

/** `data-guide-id` becomes `dataset.guideId`, as in the real DOM. */
function datasetOf(attrs) {
  const out = {};
  for (const [name, value] of Object.entries(attrs)) {
    if (!name.startsWith('data-')) continue;
    out[name.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = value;
  }
  return out;
}

const TAG_RE = /<([a-zA-Z][\w-]*)((?:\s+[^<>]*?)?)\/?>/g;
const ATTR_RE = /([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g;

/**
 * Reads the opening tags out of rendered markup into element-like objects.
 * Only attributes are modelled; there is no tree, so this cannot answer
 * `closest()` for an ancestor, only for the matched element itself.
 *
 * Returned nodes carry the members the app actually calls on a selection
 * (attribute writes, classList, scrollIntoView). Returning bare descriptors made
 * `searchTerm` throw on `node.classList`, which is exactly the kind of untested
 * path this harness exists to surface.
 */
function parseFragment(html) {
  const nodes = [];
  for (const [, tag, rawAttrs = ''] of String(html).matchAll(TAG_RE)) {
    const attrs = {};
    for (const m of rawAttrs.matchAll(ATTR_RE)) {
      attrs[m[1]] = m[2] ?? m[3] ?? m[4] ?? '';
    }

    const node = {
      tagName: tag.toUpperCase(),
      attrs,
      dataset: datasetOf(attrs),
      scrollIntoView() {},
      focus() {},
      // Real elements are live: code under test writes back to the node it just
      // selected, e.g. markActive setting aria-current on the chosen guide.
      setAttribute(name, value) {
        this.attrs[name] = String(value);
        if (name.startsWith('data-')) this.dataset = datasetOf(this.attrs);
      },
      getAttribute(name) {
        return name in this.attrs ? this.attrs[name] : null;
      },
      get className() {
        return this.attrs.class ?? '';
      },
      matches(selector) {
        return matchesSelector(this, selector);
      },
      closest: null,
    };

    // classList is a live view over class="", so a class written here is visible
    // to both the test and any later re-parse of the same markup. The arrow
    // functions need an explicit receiver: `this` inside parseFragment is not
    // the node.
    const self = node;
    const classes = () => (self.attrs.class ?? '').split(/\s+/).filter(Boolean);
    node.classList = {
      add: (...names) => {
        self.attrs.class = [...new Set([...classes(), ...names])].join(' ');
      },
      remove: (...names) => {
        self.attrs.class = classes()
          .filter((c) => !names.includes(c))
          .join(' ');
      },
      contains: (name) => classes().includes(name),
    };

    node.closest = (selector) => (node.matches(selector) ? node : null);
    nodes.push(node);
  }
  return nodes;
}

/** Matches `tag`, `.class`, `.a.b`, `tag.class`, `[attr]`, `[attr="v"]`. */
function matchesSelector(node, selector) {
  return String(selector)
    .split(',')
    .some((part) => {
      const sel = part.trim();
      if (!sel) return false;

      const classes = [...sel.matchAll(/\.([\w-]+)/g)].map((m) => m[1]);
      const attrTests = [...sel.matchAll(/\[([\w:-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
      const tag = sel.match(/^[a-zA-Z][\w-]*/)?.[0];

      if (tag && node.tagName !== tag.toUpperCase()) return false;
      if (classes.length) {
        const own = (node.attrs.class ?? '').split(/\s+/).filter(Boolean);
        if (!classes.every((c) => own.includes(c))) return false;
      }
      for (const [, name, value] of attrTests) {
        if (!(name in node.attrs)) return false;
        if (value !== undefined && node.attrs[name] !== value) return false;
      }
      return Boolean(tag || classes.length || attrTests.length);
    });
}

class StubClassList {
  #set = new Set();
  add(...names) {
    for (const n of names) this.#set.add(n);
  }
  remove(...names) {
    for (const n of names) this.#set.delete(n);
  }
  toggle(name, on) {
    if (on === undefined) this.#set.has(name) ? this.#set.delete(name) : this.#set.add(name);
    else if (on) this.#set.add(name);
    else this.#set.delete(name);
  }
  contains(name) {
    return this.#set.has(name);
  }
}

class StubElement {
  constructor(tag = 'div') {
    this.tagName = tag.toUpperCase();
    this.children = [];
    this.classList = new StubClassList();
    this.dataset = {};
    // setProperty is the only part of style the slider engine uses.
    this.style = {
      props: new Map(),
      setProperty(name, value) {
        this.props.set(name, value);
      },
      getPropertyValue(name) {
        return this.props.get(name) ?? '';
      },
    };
    this.listeners = new Map();
    this._innerHTML = '';
    this.textContent = '';
    this.hidden = false;
    this.value = '';
    // Overridable by tests that need a laid-out element.
    this.clientWidth = 0;
  }

  set innerHTML(html) {
    this._innerHTML = String(html);
    this.children = [];
    // Drop the node cache: new markup means new elements, as in the real DOM.
    this._parsed = null;
  }

  get innerHTML() {
    return this._innerHTML;
  }

  addEventListener(type, fn) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(fn);
  }

  removeEventListener() {}

  /**
   * Minimal selector support over the markup this element actually rendered.
   *
   * Returning an empty list would silently skip the code under test, and
   * `markActive` is exactly the kind of code that depends on this: a stubbed
   * empty result makes "highlight the selected guide" look like it works while
   * nothing is ever highlighted. Supports the selector shapes the app uses:
   * tag, .class, .a.b, tag.class, [attr], [attr="value"] and comma lists.
   */
  querySelectorAll(selector) {
    // Nodes are cached per markup string so repeated queries hand back the same
    // objects. In a real DOM, `setAttribute` on a selected node is observable by
    // the next query; re-parsing here would silently discard those writes and
    // make markActive look like a no-op.
    if (this._parsed?.html !== this._innerHTML) {
      this._parsed = { html: this._innerHTML, nodes: parseFragment(this._innerHTML) };
    }
    return this._parsed.nodes.filter((node) => node.matches(selector));
  }

  querySelector(selector) {
    return this.querySelectorAll(selector)[0] ?? null;
  }

  /** Delegation stand-in: the event target is the element that was matched. */
  closest(selector) {
    return this.matches(selector) ? this : null;
  }

  matches(selector) {
    const attrs = this._attributes ?? {};
    return matchesSelector({ tagName: this.tagName, attrs, dataset: datasetOf(attrs) }, selector);
  }

  setAttribute(name, value) {
    this._attributes = { ...(this._attributes ?? {}), [name]: String(value) };
  }

  getAttribute(name) {
    return this._attributes?.[name] ?? null;
  }

  dispatch(type, event = {}) {
    for (const fn of this.listeners.get(type) ?? []) fn(event);
  }

  scrollIntoView() {}

  focus() {}

  append(child) {
    this.children.push(child);
    return child;
  }

  get isConnected() {
    return true;
  }
}

/**
 * Installs the globals the feature modules touch at import time.
 *
 * @param {Record<string, StubElement>} byId element ids to expose
 * @param {{raf?: 'sync'|'manual'}} [options] `manual` queues frames so a test
 *   can assert how many renders a burst of input actually produced.
 */
export function installDom(byId = {}, options = {}) {
  const registry = new Map(Object.entries(byId));

  const document = {
    getElementById: (id) => registry.get(id) ?? new StubElement(),
    querySelectorAll: () => [],
    querySelector: () => null,
    createElement: (tag) => {
      const el = new StubElement(tag);
      registry.set(el.tagName, el);
      return el;
    },
    body: new StubElement('body'),
    addEventListener() {},
  };

  globalThis.document = document;
  globalThis.window = {
    addEventListener() {},
    location: { hash: '' },
    matchMedia: () => ({ matches: false, addEventListener() {} }),
  };

  // The manual queue lets a test count how many frames a drag produced, which
  // is the whole point of coalescing input through rAF. Frames are keyed by the
  // handle they were given, so cancelling an older frame cannot cancel a newer.
  const pending = new Map();
  let nextHandle = 1;

  globalThis.requestAnimationFrame = (fn) => {
    const handle = nextHandle++;
    if (options.raf === 'manual') {
      pending.set(handle, fn);
      return handle;
    }
    fn(0);
    return handle;
  };
  globalThis.cancelAnimationFrame = (handle) => {
    pending.delete(handle);
  };
  globalThis.history = { replaceState() {} };

  return {
    registry,
    StubElement,
    /** Runs every queued frame, as the browser would at the next tick. */
    flushFrames() {
      const queued = [...pending.entries()];
      pending.clear();
      for (const [, fn] of queued) fn(0);
    },
    /** How many frames are waiting, i.e. renders still owed to the user. */
    pendingFrames: () => pending.size,
  };
}

export { StubElement };
