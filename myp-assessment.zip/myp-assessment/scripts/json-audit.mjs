import { readFileSync, readdirSync } from 'node:fs';

let bad = 0;
for (const file of readdirSync('src/data/guides').filter((f) => f.endsWith('.json'))) {
  try {
    const doc = JSON.parse(readFileSync(`src/data/guides/${file}`, 'utf8'));
    const kind = Array.isArray(doc?.turns) ? 'dialogue' : 'guide';
    console.log(`ok   ${file.padEnd(32)} ${kind} ${doc.id}`);
  } catch (err) {
    bad += 1;
    console.log(`FAIL ${file}: ${err.message}`);
  }
}
process.exit(bad ? 1 : 0);
