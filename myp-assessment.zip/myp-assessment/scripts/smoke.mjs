/**
 * Boots the real server against a throwaway database and exercises the browser
 * surface exactly as app.js does: load the page, run every module, mount the
 * guides tab, and resolve the glossary. Any console warning, thrown error or
 * unresolved request is reported and fails the run.
 *
 * Run directly: node --no-warnings scripts/smoke.mjs
 */
import { rmSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';

import { installDom, StubElement } from './dom-stub.js';

const ROOT = resolve(import.meta.dirname, '..');
const DB = resolve(ROOT, 'data', 'smoke.db');
const PORT = 4319;
const BASE = `http://127.0.0.1:${PORT}`;

for (const suffix of ['', '-wal', '-shm']) rmSync(`${DB}${suffix}`, { force: true });

const run = (args, env) =>
  new Promise((res, rej) => {
    const child = spawn(process.execPath, args, { cwd: ROOT, env: { ...process.env, ...env } });
    child.on('exit', (code) => (code === 0 ? res() : rej(new Error(`exited ${code}`))));
  });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ------------------------------------------------------- console capture ---- */
const problems = [];
for (const level of ['error', 'warn']) {
  const original = console[level];
  console[level] = (...args) => {
    problems.push(`console.${level}: ${args.join(' ')}`);
    original(...args);
  };
}

let failures = 0;
const check = (label, ok, detail = '') => {
  if (!ok) failures++;
  console.log(`${ok ? 'OK  ' : 'BAD '} ${label}${detail && !ok ? ` -> ${detail}` : ''}`);
};

/* ------------------------------------------------------------------ boot ---- */
await run(['--no-warnings', 'scripts/seed.js'], { MYP_DB_PATH: DB });
const server = spawn(process.execPath, ['--no-warnings', 'server.js'], {
  cwd: ROOT,
  env: { ...process.env, MYP_DB_PATH: DB, PORT: String(PORT), HOST: '127.0.0.1' },
  stdio: ['ignore', 'inherit', 'inherit'],
});

try {
  for (let i = 0; i < 40; i++) {
    try {
      const r = await fetch(`${BASE}/api/v1/health`);
      if (r.ok) break;
    } catch {
      /* not up yet */
    }
    await sleep(150);
  }

  const page = await (await fetch(`${BASE}/`)).text();

  /* ------------------------------------------------------------ branding ---- */
  console.log('\nbranding');
  check('page title is MYP Bridge', /<title>\s*MYP Bridge\s*<\/title>/.test(page));
  check('header shows MYP Bridge', /<h1 class="masthead__title">\s*MYP Bridge\s*<\/h1>/.test(page));
  check('subtitle retained', page.includes('Grade equivalency, criterion practice and assessment vocabulary'));

  const icon = await fetch(`${BASE}/favicon.svg`);
  const svg = await icon.text();
  check('favicon link present', page.includes('<link rel="icon" type="image/svg+xml" href="/favicon.svg" />'));
  check('favicon returns 200', icon.ok, `HTTP ${icon.status}`);
  check(
    'favicon served as image/svg+xml',
    (icon.headers.get('content-type') ?? '').includes('image/svg+xml'),
    icon.headers.get('content-type') ?? '(none)',
  );
  check('favicon parses as XML', /^<svg[\s\S]*<\/svg>\s*$/.test(svg.trim()));
  check('favicon uses deep purple #4C1D95', /#4C1D95/i.test(svg));
  check('favicon uses amethyst #7E22CE', /#7E22CE/i.test(svg));
  check('favicon has no raster fallback dependency', !/\.png|\.jpg/.test(svg));

  /* --------------------------------------------------------------- assets ---- */
  console.log('\nfrontend assets');
  for (const asset of ['/css/styles.css', '/js/app.js', '/js/guides.js', '/js/equivalency.js']) {
    const res = await fetch(BASE + asset);
    check(`${asset} loads`, res.ok, `HTTP ${res.status}`);
  }

  /* ------------------------------------------------- guides tab from mount ---- */
  console.log('\nguides tab mounts');
  installDom(
    Object.fromEntries(
      [
        'guide-index-list',
        'guide-panel',
        'guide-context',
        'guide-empty',
        'glossary-form',
        'glossary-input',
        'glossary-status',
        'glossary-results',
      ].map((id) => [id, new StubElement()]),
    ),
  );

  // api.js is written for a browser and uses root-relative paths, which Node's
  // fetch cannot resolve. Rewriting them against the live origin keeps the real
  // HTTP path, the real JSON and the real error handling in play.
  const browserFetch = globalThis.fetch;
  globalThis.fetch = (url, init) =>
    browserFetch(String(url).startsWith('/') ? BASE + url : url, init);

  const { initGuides, __els } = await import('../public/js/guides.js');
  await initGuides();

  const panel = __els.panel.innerHTML;
  check('mount renders a guide, not a blank panel', panel.includes('guide__title'));
  check('mount does not render an error', !panel.includes('class="error"'), panel.slice(0, 120));
  check('mount hides the overview card', __els.empty.hidden === true);
  check('overview card is cleared once a guide renders', !__els.empty.innerHTML.includes('class="error"'));
  check('criteria render on mount', (panel.match(/class="criterion"/g) ?? []).length > 0);
  check('score bands render on mount', panel.includes('bands__range'));
  check('a transcript is attached on mount', __els.context.innerHTML.includes('turn__text'));

  // markActive writes aria-current onto the selected button, so this has to be
  // asserted against the live selection rather than the markup string.
  const buttons = __els.index.querySelectorAll('.guide-index__btn');
  check('subject menu is populated', buttons.length === 6, `${buttons.length} buttons`);
  const active = buttons.filter((b) => b.getAttribute('aria-current') === 'true');
  check('exactly one group is marked active', active.length === 1, `${active.length} active`);
  check('CORE is the active group on mount', active[0]?.dataset.guide === 'core-pathways', active[0]?.dataset.guide ?? '(none)');
  check(
    'every other group is marked inactive',
    buttons.filter((b) => b.getAttribute('aria-current') === 'false').length === 5,
  );

  /* --------------------------------------------------------- glossary search ---- */
  console.log('\nglossary search');
  const { searchTerm } = await import('../public/js/glossary.js');
  const results = document.getElementById('glossary-results');
  const status = document.getElementById('glossary-status');
  await searchTerm('Analyse');
  check('a query returns term results', results.innerHTML.includes('term__name'));
  check('results are announced to screen readers', status.textContent.length > 0);
} finally {
  // Wait for the server to actually exit, otherwise its open database handle
  // makes the cleanup delete fail with EPERM.
  const exited = new Promise((res) => server.once('exit', res));
  server.kill();
  await Promise.race([exited, sleep(3000)]);
  if (server.exitCode === null) server.kill('SIGKILL');
  for (const suffix of ['', '-wal', '-shm']) {
    try {
      rmSync(`${DB}${suffix}`, { force: true });
    } catch {
      /* OneDrive may hold the handle briefly; not worth failing the run over. */
    }
  }
}

console.log('\nconsole output');
if (problems.length) {
  failures += problems.length;
  for (const p of problems) console.log(`BAD  ${p}`);
} else {
  console.log('OK   no console errors or warnings');
}

console.log(failures ? `\n${failures} failing` : '\nsmoke test clean');
process.exit(failures ? 1 : 0);
