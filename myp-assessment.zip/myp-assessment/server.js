import express from 'express';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { existsSync } from 'node:fs';

import { getDb, closeDb, DB_PATH } from './src/db.js';
import { sessionMiddleware } from './src/session.js';
import questionsRouter from './src/routes/questions.js';
import termsRouter from './src/routes/terms.js';
import streakRouter from './src/routes/streak.js';
import boundariesRouter from './src/routes/boundaries.js';
import guidesRouter from './src/routes/guides.js';

const here = dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = resolve(here, 'public');
const PORT = Number.parseInt(process.env.PORT ?? '3000', 10);
const HOST = process.env.HOST ?? '127.0.0.1';

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(express.json({ limit: '256kb' }));
app.use(express.urlencoded({ extended: false, limit: '256kb' }));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  next();
});

app.use(sessionMiddleware);

// Warm the database early so a schema error surfaces at boot, not mid-request.
const db = getDb();
const seeded = db.prepare('SELECT COUNT(*) AS n FROM questions').get().n;
const terms = db.prepare('SELECT COUNT(*) AS n FROM key_terms').get().n;

app.get('/api/v1/health', (_req, res) => {
  res.json({
    status: 'success',
    data: {
      ok: true,
      uptime_seconds: Math.round(process.uptime()),
      database: DB_PATH,
      questions: seeded,
      key_terms: terms,
      node: process.version,
    },
  });
});

app.get('/api/v1/session', (req, res) => {
  res.json({ status: 'success', data: { user_id: req.userId } });
});

app.use('/api/v1', questionsRouter);
app.use('/api/v1', termsRouter);
app.use('/api/v1', streakRouter);
app.use('/api/v1', boundariesRouter);
app.use('/api/v1', guidesRouter);

app.use('/api', (_req, res) => {
  res.status(404).json({ status: 'error', message: 'Unknown API endpoint.' });
});

if (existsSync(PUBLIC_DIR)) {
  app.use(
    express.static(PUBLIC_DIR, {
      etag: true,
      maxAge: '1h',
      setHeaders: (res, path) => {
        if (path.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
      },
    }),
  );
  app.get('*splat', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    res.sendFile(resolve(PUBLIC_DIR, 'index.html'));
  });
}

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  console.error('[error]', err);
  res.status(500).json({
    status: 'error',
    message: 'Unexpected server error.',
    ...(process.env.NODE_ENV === 'development' ? { detail: String(err?.message ?? err) } : {}),
  });
});

const server = app.listen(PORT, HOST, () => {
  console.log(`MYP Bridge running at http://${HOST}:${PORT}`);
  console.log(`  database : ${DB_PATH}`);
  console.log(`  questions: ${seeded}`);
  console.log(`  key terms: ${terms}`);
  if (!seeded || !terms) {
    console.warn('  warning: run "npm.cmd run seed" to populate questions and glossary terms');
  }
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    server.close(() => {
      closeDb();
      process.exit(0);
    });
  });
}

export default app;
