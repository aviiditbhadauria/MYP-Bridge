/**
 * Shared term definition overlay.
 *
 * Any interactive term anchor across the app (guide criteria, classroom
 * dialogue, glossary) opens the same dialog, so the definition a student reads
 * never depends on which panel they clicked from.
 *
 * The dialog is a real <dialog> element, which gives focus trapping, Escape to
 * close, and backdrop dismissal from the browser rather than from hand-rolled
 * keyboard handling.
 */
import { api, esc } from './api.js';

let el = null;
let lastFocus = null;

function ensureEl() {
  if (el?.isConnected) return el;

  el = document.createElement('dialog');
  el.className = 'termcard';
  el.innerHTML = `
    <form method="dialog" class="termcard__panel">
      <div class="termcard__head">
        <h2 class="termcard__name" data-field="term"></h2>
        <button class="termcard__close" value="close" type="submit">Close</button>
      </div>
      <div class="termcard__meta" data-field="meta"></div>
      <p class="termcard__definition" data-field="definition"></p>
      <p class="termcard__example" data-field="example"></p>
      <div class="termcard__actions">
        <button class="button button--ghost" type="button" data-action="glossary">
          Open in glossary
        </button>
      </div>
    </form>`;
  document.body.append(el);
  return el;
}

function setField(name, value, html = false) {
  const target = el.querySelector(`[data-field="${name}"]`);
  if (!target) return;
  if (html) target.innerHTML = value;
  else target.textContent = value ?? '';
}

/** Renders an already-resolved glossary record into the dialog. */
export function showTermRecord(term) {
  const dialog = ensureEl();

  setField('term', term.term);
  setField('meta', '');
  el.querySelector('[data-field="meta"]').innerHTML = [
    `<span class="tag">${esc(term.category)}</span>`,
    term.criterion_association
      ? `<span class="tag tag--muted">Criterion ${esc(term.criterion_association)}</span>`
      : '',
    term.subject_group
      ? `<span class="tag tag--muted">${esc(term.subject_group)}</span>`
      : '',
  ]
    .filter(Boolean)
    .join('');
  setField('definition', term.formal_definition);
  setField(
    'example',
    `In MYP: ${term.myp_context_example ?? ''}`,
  );

  dialog.dataset.term = term.term;
  if (!dialog.open) {
    lastFocus = document.activeElement;
    dialog.showModal();
  }
}

/**
 * Looks a term up and opens the dialog. Callers that already have a resolved
 * record from the guides API should prefer showTermRecord.
 */
export async function openTerm(term) {
  try {
    const res = await api.terms({ q: term, limit: 1 });
    const hit = res.data?.[0] ?? res.results?.[0];
    if (!hit) throw new Error(`No glossary entry for "${term}".`);
    showTermRecord(hit);
  } catch (err) {
    ensureEl();
    setField('term', term);
    setField('meta', '');
    setField('definition', err.message);
    setField('example', '');
    if (!el.open) el.showModal();
  }
}

let onGlossaryRequest = () => {};

/** Registered by app.js so the dialog can hand off to the glossary tab. */
export function setGlossaryNavigator(fn) {
  onGlossaryRequest = fn;
}

export function initTermCard() {
  const dialog = ensureEl();

  dialog.querySelector('[data-action="glossary"]').addEventListener('click', () => {
    const term = dialog.dataset.term;
    dialog.close();
    if (term) onGlossaryRequest(term);
  });

  dialog.addEventListener('close', () => {
    dialog.dataset.term = '';
    // Returning focus to the anchor keeps keyboard position intact.
    lastFocus?.focus?.();
    lastFocus = null;
  });

  // A click that lands on the dialog element itself, outside the sheet, hits
  // the backdrop. The inner form never bubbles that target up to here.
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close();
  });
}
