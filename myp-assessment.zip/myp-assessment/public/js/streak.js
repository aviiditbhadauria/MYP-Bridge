/**
 * Practice streak panel.
 *
 * The streak is derived entirely from the server ledger: this module only
 * renders it. There is deliberately no control here that can set, reset or
 * otherwise hand-edit a streak.
 */
import { api } from './api.js';

const els = {
  panel: document.getElementById('streak'),
  current: document.getElementById('streak-current'),
  message: document.getElementById('streak-message'),
};

let last = null;

/** Applies a streak object returned by any endpoint without a refetch. */
export function applyStreak(streak) {
  if (!streak || !els.current) return;
  last = streak;
  els.current.textContent = String(streak.current_streak ?? 0);

  const active = streak.streak_active_today ?? true;
  els.panel.classList.toggle('is-inactive', !active);

  const parts = [streak.status_message];
  if (streak.totals?.attempts > 0) {
    const { attempts, accuracy_percent: accuracy } = streak.totals;
    parts.push(`${attempts} logged, ${accuracy}% accuracy.`);
  }
  els.message.textContent = parts.filter(Boolean).join(' ');
}

export async function loadStreak() {
  try {
    const res = await api.streak();
    applyStreak(res.data);
  } catch {
    if (els.message) {
      els.message.textContent = 'Practice record unavailable. Answers will still be graded.';
    }
  }
  return last;
}
