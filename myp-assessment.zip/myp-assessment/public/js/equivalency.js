/**
 * Grade equivalency engine.
 *
 * The eight-row matrix for the selected subject is fetched once and cached, so
 * moving the slider is a synchronous local lookup rather than a network round
 * trip. Pointer input is coalesced through requestAnimationFrame so the readout
 * tracks the thumb at display refresh rate, and the `change` event flushes any
 * frame that is still pending.
 */
import { api, esc } from './api.js';

const els = {
  subject: document.getElementById('subject-select'),
  subjectNote: document.getElementById('subject-note'),
  slider: document.getElementById('grade-slider'),
  output: document.getElementById('grade-output'),
  bandLabel: document.getElementById('grade-band-label'),
  readout: document.getElementById('equivalency-readout'),
};

let subjects = [];
let matrix = [];
let activeGrade = 5;
let frame = null;

/**
 * Tracks which matrix row the pointer is over, so hovering and dragging read as
 * one continuous interaction instead of a jump between rows.
 */
let hoverGrade = null;

function subjectName(id) {
  return subjects.find((s) => s.id === id)?.short ?? id;
}

/**
 * Writes the filled portion of the track as a CSS custom property.
 *
 * The thumb is 18px wide, so a percentage measured across the full input would
 * overshoot by half a thumb at each end. Inset the track by half the thumb and
 * scale into the remaining span, which makes the fill meet the thumb centre
 * exactly at both extremes.
 */
function setProgress() {
  const min = Number(els.slider.min || 1);
  const max = Number(els.slider.max || 8);
  const value = Number(els.slider.value);

  const span = max - min;
  const ratio = span === 0 ? 0 : (value - min) / span;

  const full = els.slider.clientWidth;
  if (!full) {
    // Not laid out yet, so the pixel width is unknowable. Fall back to the
    // nominal 8-step ratio rather than writing a bogus gradient.
    els.slider.style.setProperty('--slider-progress', `${(ratio * 100).toFixed(2)}%`);
    return ratio;
  }

  const track = full - 18;
  const px = ratio * track + 9;
  const percent = (px / full) * 100;

  els.slider.style.setProperty(
    '--slider-progress',
    `${Math.max(0, Math.min(100, percent)).toFixed(2)}%`,
  );
  return ratio;
}

/**
 * Builds the readout markup.
 *
 * The matrix is eight static rows, so the whole card is one template rather
 * than eight incremental patches. Rebuilding it inside requestAnimationFrame
 * keeps every dependent DOM write in a single frame with no interleaved layout
 * thrash during a drag.
 */
function readoutMarkup(grade) {
  const row = matrix.find((r) => r.grade === grade);

  if (!row) {
    return `<p class="readout__empty">No boundary data for grade ${esc(String(grade))}</p>`;
  }

  const rowClass = (g) => (g === grade ? ' class="is-active"' : '');

  return `
    <div class="gradecard">
      <div class="gradecard__head">
        <p class="gradecard__mark">${esc(row.grade)}</p>
        <p class="gradecard__band">${esc(row.percentRange)} &middot; ${esc(row.band)}</p>
        <p class="gradecard__profile">${esc(row.profile)} profile</p>
      </div>
      <p class="gradecard__descriptor">${esc(row.descriptor)}</p>
      <div class="table-scroll">
        <table class="matrix">
          <caption>Equivalency matrix &middot; ${esc(subjectName(els.subject.value))}</caption>
          <thead>
            <tr>
              <th scope="col">Grade</th>
              <th scope="col">Raw mark band</th>
              <th scope="col">Criterion band</th>
              <th scope="col">IGCSE</th>
              <th scope="col">CBSE</th>
              <th scope="col">ICSE</th>
              <th scope="col">State board</th>
            </tr>
          </thead>
          <tbody>
            ${matrix
              .map(
                (r) => `
              <tr${rowClass(r.grade)}>
                <th scope="row" class="matrix__grade">${esc(r.grade)}</th>
                <td class="matrix__num">${esc(r.percentRange)}</td>
                <td class="matrix__criterion">${esc(r.criterionBand)}</td>
                <td>${esc(r.igcse)}</td>
                <td>${esc(r.cbse)}</td>
                <td>${esc(r.icse)}</td>
                <td>${esc(r.stateBoard)}</td>
              </tr>`,
              )
              .join('')}
          </tbody>
        </table>
      </div>
    </div>`;
}

/** One frame: track fill, output label, band caption, active row. */
function renderReadout() {
  const grade = Number(els.slider.value);

  setProgress();

  // A pending hover row wins for one frame so the highlight tracks the pointer
  // before the slider value itself catches up.
  const shown = hoverGrade ?? grade;
  const row = matrix.find((r) => r.grade === shown);

  if (hoverGrade === null || hoverGrade === grade) activeGrade = grade;

  els.output.textContent = String(shown);
  els.bandLabel.textContent = row
    ? `Grade ${shown}: raw marks ${row.percentRange}`
    : 'No boundary data for this grade';

  els.readout.innerHTML = readoutMarkup(shown);
}

/** Applies the slider value now, cancelling any frame still in flight. */
function flush() {
  if (frame !== null) {
    cancelAnimationFrame(frame);
    frame = null;
  }
  hoverGrade = null;
  renderReadout();
}

/**
 * Coalesces pointer input into a single frame.
 *
 * A drag emits far more input events than the display can present. Scheduling
 * at most one render per frame means every dependent write, the gradient stop
 * and the boundary lookup, lands in the same frame as the value it reflects.
 */
function schedule() {
  if (frame === null) {
    frame = requestAnimationFrame(() => {
      frame = null;
      renderReadout();
    });
  }
}

async function loadSubject(id) {
  els.readout.classList.add('is-busy');
  els.readout.innerHTML = '<p class="readout__empty">Loading equivalency data</p>';
  try {
    const res = await api.boundaries(id);
    matrix = res.data ?? [];
    els.subjectNote.textContent = `${matrix.length} grade bands, ${res.profile} profile`;
    // A pending frame from the previous subject would paint stale rows.
    if (frame !== null) {
      cancelAnimationFrame(frame);
      frame = null;
    }
    hoverGrade = null;
    renderReadout();
  } catch (err) {
    els.readout.innerHTML = `<p class="error">${esc(err.message)}</p>`;
    els.subjectNote.textContent = 'Boundary data unavailable';
  } finally {
    els.readout.classList.remove('is-busy');
  }
}

export async function initEquivalency() {
  try {
    const res = await api.subjects();
    subjects = res.data ?? [];
  } catch {
    els.readout.innerHTML =
      '<p class="error">Could not reach the equivalency service. Start the server and reload.</p>';
    return;
  }

  els.subject.innerHTML = subjects
    .map((s) => `<option value="${esc(s.id)}">${esc(s.short)} &middot; ${esc(s.id)}</option>`)
    .join('');

  // Keep the practice subject selector in step with the equivalency selector.
  const practiceSubject = document.getElementById('practice-subject');
  if (practiceSubject && !practiceSubject.options.length) {
    practiceSubject.innerHTML =
      '<option value="">All subject groups</option>' +
      subjects.map((s) => `<option value="${esc(s.id)}">${esc(s.id)}</option>`).join('');
  }

  els.slider.addEventListener('input', schedule);
  els.slider.addEventListener('change', flush);
  els.slider.addEventListener('pointerdown', () => {
    hoverGrade = null;
    schedule();
  });
  els.slider.addEventListener('pointerup', flush);
  els.subject.addEventListener('change', (e) => loadSubject(e.target.value));

  // The gradient stop is a percentage of layout width, so it must be recomputed
  // whenever that width changes rather than only on user input.
  if (typeof ResizeObserver === 'function') {
    const ro = new ResizeObserver(() => setProgress());
    ro.observe(els.slider);
  } else {
    window.addEventListener('resize', setProgress);
  }

  setProgress();
  await loadSubject(els.subject.value);
}

export function currentGrade() {
  return activeGrade;
}

/* ------------------------------------------------------------ test seams -- */

export const __els = els;
export const __renderReadout = renderReadout;
export const __setProgress = setProgress;
export const __schedule = schedule;
export const __flush = flush;
export const __setMatrix = (rows) => {
  matrix = rows ?? [];
};
export const __setSubjects = (list) => {
  subjects = list ?? [];
};
