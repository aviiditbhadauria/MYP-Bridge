/**
 * Practice engine.
 *
 * Fetches one question at a time from the bank, grades the submission against
 * the server, shows the rubric rationale, and reports the resulting streak.
 * The answer key is never sent to the browser for the graded request, so the
 * grade shown is the server's decision rather than the client's.
 */
import { api, esc, timezoneOffset } from './api.js';
import { applyStreak, loadStreak } from './streak.js';

const LETTERS = ['A', 'B', 'C', 'D'];

const els = {
  card: document.getElementById('question-card'),
  subject: document.getElementById('practice-subject'),
  criterion: document.getElementById('practice-criterion'),
  level: document.getElementById('practice-level'),
  command: document.getElementById('practice-command'),
  load: document.getElementById('practice-load'),
};

let sessionId = `ses_${Math.random().toString(36).slice(2, 10)}`;
let inFlight = null;
let awaitingAnswer = false;

function filters() {
  return {
    subject: els.subject.value,
    criterion: els.criterion.value,
    level: els.level.value,
    command_term: els.command.value,
    limit: 1,
    offset: Math.floor(Math.random() * 300),
    reveal: 'false',
  };
}

function renderEmpty(message) {
  els.card.innerHTML = `<p class="question__empty">${esc(message)}</p>`;
}

async function loadCommandTerms() {
  try {
    const res = await api.terms({ category: 'Command Term', limit: 100 });
    const names = (res.data ?? []).map((t) => t.term).sort();
    els.command.innerHTML =
      '<option value="">All command terms</option>' +
      names.map((t) => `<option value="${esc(t)}">${esc(t)}</option>`).join('');
  } catch {
    /* the filter is optional; leave the default in place */
  }
}

async function loadQuestion() {
  inFlight?.abort();
  inFlight = new AbortController();
  awaitingAnswer = false;
  els.load.disabled = true;
  els.card.classList.add('is-busy');
  renderEmpty('Loading question');

  try {
    const res = await api.questions(filters(), inFlight.signal);
    const question = res.data?.[0];

    if (!question) {
      renderEmpty('No questions match these filters. Try a wider selection.');
      return;
    }

    awaitingAnswer = true;
    els.card.innerHTML = `
      <div class="question__meta">
        <span class="tag">${esc(question.subject_group)}</span>
        <span class="tag">Criterion ${esc(question.target_criterion)}</span>
        <span class="tag">Phase level ${esc(question.myp_phase_level)}</span>
        <span class="tag tag--muted">${esc(question.command_term)}</span>
      </div>
      <p class="question__text">${esc(question.question_text)}</p>
      <ul class="options">
        ${question.options
          .map(
            (option, index) => `
          <li>
            <label class="option" data-option="${index}">
              <input type="radio" name="answer" value="${index}" />
              <span class="option__key">${LETTERS[index]}</span>
              <span>${esc(option)}</span>
            </label>
          </li>`,
          )
          .join('')}
      </ul>
      <div class="question__actions">
        <button class="button" type="button" id="submit-answer" disabled>Submit answer</button>
        <button class="button button--ghost" type="button" id="next-question">Next question</button>
      </div>`;

    const submit = els.card.querySelector('#submit-answer');
    const next = els.card.querySelector('#next-question');

    els.card.querySelectorAll('.option').forEach((label) => {
      label.addEventListener('change', () => {
        els.card.querySelectorAll('.option').forEach((l) => l.classList.remove('is-selected'));
        label.classList.add('is-selected');
        submit.disabled = false;
      });
    });

    submit.addEventListener('click', () => {
      const chosen = els.card.querySelector('input[name="answer"]:checked');
      if (chosen) grade(question, Number(chosen.value), submit);
    });
    next.addEventListener('click', loadQuestion);
  } catch (err) {
    if (err.name !== 'AbortError') {
      els.card.innerHTML = `<p class="error">${esc(err.message)}</p>`;
    }
  } finally {
    els.card.classList.remove('is-busy');
    els.load.disabled = false;
  }
}

async function grade(question, chosen, submitButton) {
  submitButton.disabled = true;
  awaitingAnswer = false;

  try {
    const res = await api.submitAttempt({
      question_id: question.id,
      chosen_index: chosen,
      session_id: sessionId,
      timezone_offset: timezoneOffset(),
    });
    const result = res.data;
    const correct = result.is_correct;

    els.card.querySelectorAll('.option').forEach((label) => {
      const index = Number(label.dataset.option);
      label.classList.add('is-locked');
      const input = label.querySelector('input');
      input.disabled = true;
      if (index === result.correct_option_index) label.classList.add('is-correct');
      else if (index === chosen) label.classList.add('is-incorrect');
    });

    const feedback = document.createElement('div');
    feedback.className = `feedback ${correct ? 'feedback--correct' : 'feedback--incorrect'}`;
    feedback.innerHTML = `
      <p class="feedback__verdict">${
        correct ? 'Correct' : `Not quite. The answer is ${LETTERS[result.correct_option_index]}`
      }</p>
      <p class="feedback__rationale">${esc(result.rubric_rationale)}</p>
      <p class="feedback__streak">${esc(res.streak?.status_message ?? '')}</p>`;
    els.card.querySelector('.question__actions').before(feedback);

    if (res.streak) applyStreak(res.streak);
  } catch (err) {
    const feedback = document.createElement('div');
    feedback.className = 'feedback feedback--incorrect';
    feedback.innerHTML = `<p class="feedback__verdict">Could not record this answer</p>
      <p class="feedback__rationale">${esc(err.message)}</p>`;
    els.card.querySelector('.question__actions').before(feedback);
    await loadStreak();
  }
}

export function initPractice() {
  els.load.addEventListener('click', loadQuestion);
  els.subject.addEventListener('change', () => renderEmpty('Filters changed. Select Load question.'));
  for (const el of [els.criterion, els.level, els.command]) {
    el.addEventListener('change', () =>
      renderEmpty('Filters changed. Select Load question.'),
    );
  }
  loadCommandTerms();

  // Exposed for the optional service worker cache-warming path.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') loadStreak();
  });
}
