/**
 * Subject Guides panel.
 *
 * Renders the six server-authored guides (criteria, score bands, assessment
 * objectives, eAssessment expectations) plus the classroom discussion context.
 *
 * Every term in the guides is an activatable anchor. The guides API resolves
 * anchors and dialogue spans to full glossary records in the same response, so
 * clicking one opens the shared term dialog without an extra round trip.
 */
import { api, esc } from './api.js';
import { openTerm, showTermRecord } from './termcard.js';

const els = {
  index: document.getElementById('guide-index-list'),
  panel: document.getElementById('guide-panel'),
  context: document.getElementById('guide-context'),
  empty: document.getElementById('guide-empty'),
};

let current = null;
let currentGuide = null;
let allDialogues = [];
let selectionTicket = 0;

/**
 * The group rendered on mount. Named explicitly rather than relying on whatever
 * the payload happens to sort to first, so adding a guide file cannot silently
 * change the landing view.
 */
const DEFAULT_GUIDE_ID = 'core-pathways';

/**
 * Renders a term anchor carrying its already-resolved glossary record.
 *
 * The record rides along in a data attribute so clicking needs no network call.
 * `esc` keeps the JSON inert inside the attribute, and the parsed value is
 * re-escaped by the dialog before it reaches innerHTML.
 */
function termPill(term) {
  const payload = esc(JSON.stringify(term));
  return `<button class="termlink" type="button" data-term="${esc(term.term)}" data-record="${payload}">${esc(term.term)}</button>`;
}

function bandRows(bands) {
  return Object.entries(bands)
    .map(
      ([range, descriptor]) => `
      <tr>
        <th scope="row" class="bands__range">${esc(range)}</th>
        <td class="bands__descriptor">${esc(descriptor)}</td>
      </tr>`,
    )
    .join('');
}

function criterionCard(criterion) {
  // Anchors arrive pre-resolved, so unlinked terms are skipped rather than
  // rendered as dead chips.
  const terms = (criterion.terms ?? [])
    .map((t) => t && termPill(t.term))
    .filter(Boolean)
    .join('');

  return `
    <article class="criterion">
      <header class="criterion__head">
        <span class="criterion__mark">${esc(criterion.id)}</span>
        <h4 class="criterion__name">${esc(criterion.name)}</h4>
      </header>
      <table class="bands">
        <caption>Band descriptors for criterion ${esc(criterion.id)}</caption>
        <tbody>${bandRows(criterion.bands)}</tbody>
      </table>
      ${
        terms
          ? `<div class="termlist">
               <p class="guide__section-title" style="margin:0 0.35rem 0 0">Key terms</p>
               ${terms}
             </div>`
          : ''
      }
    </article>`;
}

function list(items) {
  return (items ?? []).map((i) => `<li>${esc(i)}</li>`).join('');
}

function pathwayCards(pathways = []) {
  if (!pathways.length) return '';
  return `
    <section class="guide__section">
      <h3 class="guide__section-title">Pathways in this group</h3>
      <div class="pathways">
        ${pathways
          .map(
            (p) => `
          <div class="pathway">
            <p class="pathway__name">${esc(p.name)}</p>
            <p class="pathway__focus">${esc(p.note)}</p>
            <p class="pathway__focus">
              ${(p.criteria_focus ?? []).map((f) => `<span>${esc(f)}</span>`).join('')}
            </p>
          </div>`,
          )
          .join('')}
      </div>
    </section>`;
}

function guideView(guide) {
  // Optional chaining throughout: a partially populated guide should render a
  // thinner card, not throw and blank the panel.
  const meta = [
    guide.abbreviation ? `<span class="tag">${esc(guide.abbreviation)}</span>` : '',
    guide.pathway ? `<span class="tag tag--muted">${esc(guide.pathway)}</span>` : '',
    guide.levels ? `<span class="tag tag--muted">${esc(guide.levels)}</span>` : '',
  ]
    .filter(Boolean)
    .join('');

  const criteria = Array.isArray(guide.criteria) ? guide.criteria : [];

  const contexts = list(guide.global_contexts);

  return `
    <div class="guide">
      <header class="guide__head">
        <p class="guide__eyebrow">${esc(guide.abbreviation ?? 'Subject')} guide</p>
        <h3 class="guide__title">${esc(guide.name ?? 'Untitled subject guide')}</h3>
        <div class="guide__facts">${meta}</div>
        <p class="guide__overview">${esc(guide.framework_overview ?? '')}</p>
      </header>

      ${pathwayCards(guide.pathways)}

      ${
        contexts
          ? `<section class="guide__section">
               <h3 class="guide__section-title">Global contexts in play</h3>
               <ul class="bulletlist">${contexts}</ul>
             </section>`
          : ''
      }

      <section class="guide__section">
        <h3 class="guide__section-title">Assessment objectives</h3>
        <ul class="bulletlist">${list(guide.assessment_objectives)}</ul>
      </section>

      <section class="guide__section">
        <h3 class="guide__section-title">eAssessment expectations</h3>
        <ul class="bulletlist">${list(guide.eassessment_expectations)}</ul>
      </section>

      <div>${criteria.map(criterionCard).join('')}</div>
    </div>`;
}

/* ----------------------------------------------------- classroom context -- */

function termMapRows(dialogue) {
  return (dialogue.term_map ?? [])
    .map((entry) => {
      // Each row is itself an anchor so the contextual definition opens the
      // same shared dialog as the inline transcript spans.
      const g = entry.glossary_term;
      const inner = `<p class="termmap__term">${esc(entry.term ?? '')}</p>
        <p class="termmap__def">${esc(entry.contextual_definition ?? '')}</p>`;

      if (!g) {
        return `<div class="termmap__row">${inner}</div>`;
      }
      const payload = esc(JSON.stringify(g));
      return `
      <div class="termmap__row">
        <button class="termmap__btn" type="button" data-term="${esc(entry.term ?? '')}" data-record="${payload}">
          ${inner}
        </button>
      </div>`;
    })
    .join('');
}

function dialogueView(dialogue) {
  const turnList = dialogue?.turns;
  if (!Array.isArray(turnList) || turnList.length === 0) {
    return `
    <div class="dialogue">
      <p class="empty">No transcript is available for this subject group yet.</p>
    </div>`;
  }

  const turns = turnList
    .map((turn) => {
      // Segments let each annotated term render as its own anchor rather than
      // relying on fragile string matching over the plain text.
      const body = (turn.segments ?? [])
        .map((seg) => {
          if (seg.type !== 'term' || !seg.glossary_term) return esc(seg.value);
          const payload = esc(JSON.stringify(seg.glossary_term));
          return `<button class="cterm" type="button" data-term="${esc(seg.term)}" data-record="${payload}">${esc(seg.value)}</button>`;
        })
        .join('');

      const kind = turn.speaker_role === 'teacher' ? 'teacher' : 'student';
      return `
      <div class="turn turn--${kind}">
        <p class="turn__speaker">${esc(turn.speaker)}</p>
        <p class="turn__text">${body}</p>
      </div>`;
    })
    .join('');

  return `
    <div class="dialogue">
      <header class="dialogue__head">
        <p class="dialogue__eyebrow">Classroom context</p>
        <h3 class="dialogue__title">${esc(dialogue.title ?? 'Classroom transcript')}</h3>
        ${dialogue.year_group ? `<p class="dialogue__setting">${esc(dialogue.year_group)}</p>` : ''}
        <p class="dialogue__context">${esc(dialogue.context ?? '')}</p>
        ${dialogue.setting ? `<p class="dialogue__setting">${esc(dialogue.setting)}</p>` : ''}
      </header>
      ${turns}
      <div class="dialogue__terms">
        <h3 class="guide__section-title">
          Annotated terms (${(dialogue.term_map ?? []).length}) click to define
        </h3>
        <div class="termmap">${termMapRows(dialogue)}</div>
        ${dialogue.didactic_note ? `<p class="didactic">${esc(dialogue.didactic_note)}</p>` : ''}
      </div>
    </div>`;
}

/**
 * Loading placeholder for the guide panel.
 *
 * Marked aria-busy so assistive tech announces the region as pending rather
 * than reading a half-built table.
 */
function skeleton() {
  return `
    <div class="guide__head" aria-busy="true">
      <p class="guide__eyebrow">Loading</p>
      <p class="skeleton skeleton--title"></p>
      <p class="skeleton skeleton--line"></p>
      <p class="skeleton skeleton--line skeleton--short"></p>
    </div>
    <div class="guide__section" aria-busy="true">
      ${[0, 1, 2]
        .map(
          () => `
        <p class="skeleton skeleton--block"></p>`,
        )
        .join('')}
    </div>`;
}

/** Normalises a subject label so "Individuals & Societies" matches "Individuals and Societies". */
function subjectKey(value) {
  return String(value ?? '')
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

/**
 * Decides whether a transcript belongs to a subject group.
 *
 * `guide_ids` is authoritative because it is authored alongside the transcript
 * and validated at boot. The label comparison is only a fallback for payloads
 * that predate that field.
 */
function dialogueMatchesGuide(dialogue, guide) {
  if (!guide) return false;

  const declared = dialogue?.guide_ids;
  if (Array.isArray(declared) && declared.length > 0) {
    return declared.includes(guide.id) || declared.includes(guide.abbreviation);
  }

  const targets = [guide.name, guide.abbreviation, guide.pathway, guide.id]
    .map(subjectKey)
    .filter(Boolean);

  return (dialogue?.subjects ?? []).some((s) => {
    const key = subjectKey(s);
    return targets.some((t) => t.includes(key) || key.includes(t));
  });
}

function renderContext(dialogues, guide) {
  // Tailor the transcript to the selected subject group, falling back to the
  // full set only when nothing matches so the panel is never silently empty.
  const matching = (dialogues ?? []).filter((d) => dialogueMatchesGuide(d, guide));
  const shown = matching.length ? matching : (dialogues ?? []);

  if (!shown.length) {
    els.context.innerHTML = '';
    return;
  }

  const note = matching.length
    ? ''
    : '<p class="field__hint">No transcript is recorded for this group yet, so the closest available is shown.</p>';

  els.context.innerHTML = `
    <div class="panel__head" style="margin-top:2rem">
      <h3>See the vocabulary in context</h3>
      <p class="panel__lede">
        The bands above only matter when the language shows up in real work.
        These transcripts show how command terms and concepts are used together,
        and every highlighted term opens its formal definition.
      </p>
      ${note}
    </div>
    ${shown.map(dialogueView).join('')}`;
}

/* ------------------------------------------------------------- rendering -- */

function markActive(id) {
  for (const btn of els.index.querySelectorAll('.guide-index__btn')) {
    btn.setAttribute('aria-current', String(btn.dataset.guide === id));
  }
}

/**
 * The landing card shown whenever no subject group is selected, so the tab is
 * never blank or mid-load. `note` covers the degraded cases: no guides in the
 * payload, or a request that failed outright.
 */
const OVERVIEW_PROMPT =
  'Select a subject group from the left menu to explore criterion performance bands and classroom dialogue examples.';

function showOverview(note = '') {
  els.panel.innerHTML = '';
  els.context.innerHTML = '';
  els.empty.innerHTML = `
    <p class="empty__eyebrow">Subject guides</p>
    <h2 class="empty__title">Choose a subject group to begin</h2>
    <p class="empty__body">${esc(OVERVIEW_PROMPT)}</p>
    ${note ? `<p class="error">${esc(note)}</p>` : ''}`;
  els.empty.hidden = false;
}

/** The guide to show on mount: CORE when present, else whatever comes first. */
function defaultGuideId(guides) {
  const list = guides ?? [];
  return list.some((g) => g.id === DEFAULT_GUIDE_ID) ? DEFAULT_GUIDE_ID : (list[0]?.id ?? null);
}

function renderIndex(guides) {
  els.index.innerHTML = guides
    .map(
      (g) => `
      <li>
        <button class="guide-index__btn" type="button" data-guide="${esc(g.id)}" data-abbr="${esc(g.abbreviation ?? '')}">
          <span class="guide-index__abbr">${esc(g.abbreviation ?? '—')}</span>${esc(g.name)}
        </button>
      </li>`,
    )
    .join('');
}

function renderGuide(guide) {
  current = guide.id;
  currentGuide = guide;
  markActive(guide.id);
  els.empty.hidden = true;
  // `guide` is already the payload; reading guide.data here previously
  // double-unwrapped the envelope and passed undefined into the view.
  els.panel.innerHTML = guideView(guide);
  els.panel.scrollIntoView({ block: 'start', behavior: 'smooth' });
}

/**
 * Renders one guide from the API envelope.
 *
 * The response nests the guide under `data`, so unwrap defensively: a malformed
 * or error envelope must render a message, never a blank panel or a throw.
 */
function renderGuideResponse(res) {
  const guide = res?.data;
  if (!guide || typeof guide !== 'object') {
    throw new TypeError('Guide response did not include a data payload');
  }
  if (!Array.isArray(guide.criteria) || guide.criteria.length === 0) {
    throw new TypeError(`Guide "${guide.id ?? 'unknown'}" has no criteria to render`);
  }
  return guide;
}

async function selectGuide(id) {
  // Every request records its own ticket. Comparing the response against the
  // newest ticket, rather than against its own id, is what actually discards a
  // slow earlier request whose answer arrives after a faster later one.
  const ticket = ++selectionTicket;
  els.panel.innerHTML = skeleton();
  els.empty.hidden = true;

  try {
    const res = await api.guide(id);
    const guide = renderGuideResponse(res);

    if (ticket !== selectionTicket) return;

    renderGuide(guide);
    renderContext(allDialogues, guide);
  } catch (err) {
    if (ticket !== selectionTicket) return;
    els.panel.innerHTML = `<p class="error">${esc(err.message)}</p>`;
    markActive(current);
  }
}

/**
 * Transcripts are supplementary, not required: they load after the guide panel
 * is already populated and are applied when they arrive. A slow or failing
 * dialogue endpoint therefore leaves criteria and bands intact instead of
 * replacing them with an error.
 */
async function loadDialogues() {
  try {
    const res = await api.dialogues();
    allDialogues = res.data ?? [];
    if (currentGuide) renderContext(allDialogues, currentGuide);
  } catch (err) {
    console.warn('Classroom transcripts unavailable:', err.message);
  }
}

export function initGuides() {
  els.index.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-guide]');
    if (btn) selectGuide(btn.dataset.guide);
  });

  // One delegated listener serves guide pills and dialogue spans alike.
  const onTermClick = (e) => {
    const btn = e.target.closest('button[data-term]');
    if (!btn) return;

    // Prefer the record the API already resolved; fall back to a lookup only
    // if the attribute is missing or unparseable.
    if (btn.dataset.record) {
      try {
        showTermRecord(JSON.parse(btn.dataset.record));
        return;
      } catch {
        /* fall through to a lookup */
      }
    }
    openTerm(btn.dataset.term);
  };
  els.panel.addEventListener('click', onTermClick);
  els.context.addEventListener('click', onTermClick);

  // The returned promise resolves once the default group is on screen, so
  // callers (and the verification suite) can await the mounted state instead of
  // racing the first render. Returning it is safe for callers that ignore it.
  return (async () => {
    let guides = [];
    try {
      const res = await api.guides();
      guides = res.guides ?? [];
      renderIndex(guides);
    } catch (err) {
      showOverview(`Could not load subject guides: ${err.message}`);
      return;
    }

    // CORE renders immediately on mount so the tab opens with real content
    // rather than a blank panel. Transcripts follow once they resolve.
    const first = defaultGuideId(guides);
    if (first) await selectGuide(first);
    else showOverview('No subject guides are published yet.');

    // Dialogue is fetched once and cached; each selection filters locally
    // rather than refetching the whole set.
    await loadDialogues();
  })();
}

/* ------------------------------------------------------------ test seams -- */

/** Replaces the cached transcript set. Exported for the verification suite. */
export function __setDialogues(list) {
  allDialogues = list ?? [];
}

/** Exported so the suite can assert the landing card and default selection. */
export function __showOverview(note) {
  showOverview(note);
}

export function __defaultGuideId(guides) {
  return defaultGuideId(guides);
}

/** Element and function handles for the verification suite. */
export const __els = els;
export const __selectGuide = selectGuide;
export const __initGuides = initGuides;
