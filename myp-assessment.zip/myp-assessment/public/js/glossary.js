/**
 * Glossary search.
 *
 * Queries are debounced and the in-flight request is aborted when a newer
 * keystroke arrives, so the result list always reflects the latest input.
 * Related terms are clickable and re-run the search from that term.
 */
import { api, esc } from './api.js';

const els = {
  form: document.getElementById('glossary-form'),
  input: document.getElementById('glossary-input'),
  status: document.getElementById('glossary-status'),
  results: document.getElementById('glossary-results'),
};

const DEBOUNCE_MS = 220;
let timer = null;
let inFlight = null;

function card(term) {
  const related = (term.related_terms ?? [])
    .filter(Boolean)
    .slice(0, 6)
    .map(
      (r) =>
        `<button type="button" data-term="${esc(r)}">${esc(r)}</button>`,
    )
    .join('');

  return `
    <article class="term">
      <div class="term__head">
        <h3 class="term__name">${esc(term.term)}</h3>
        <span class="tag tag--muted">${esc(term.category)}</span>
        ${term.criterion_association ? `<span class="tag">Criterion ${esc(term.criterion_association)}</span>` : ''}
        ${term.subject_group ? `<span class="tag tag--muted">${esc(term.subject_group)}</span>` : ''}
      </div>
      <p class="term__definition">${esc(term.formal_definition)}</p>
      <p class="term__example"><strong>In MYP:</strong> ${esc(term.myp_context_example)}</p>
      ${related ? `<div class="term__related"><span>Related</span>${related}</div>` : ''}
    </article>`;
}

function render(results) {
  if (!results.length) {
    els.results.innerHTML =
      '<p class="empty">No glossary entries match that search. Try a command term such as Evaluate or a concept such as Homostasis.</p>';
    return;
  }
  els.results.innerHTML = results.map(card).join('');
}

async function run(query) {
  const term = query.trim();
  if (!term) {
    els.status.textContent = '';
    els.results.innerHTML = '';
    return;
  }

  inFlight?.abort();
  inFlight = new AbortController();

  try {
    const res = await api.searchTerms(term, inFlight.signal);
    render(res.results ?? []);
    els.status.textContent = `${res.count} match${
      res.count === 1 ? '' : 'es'
    } for "${term}".`;
  } catch (err) {
    if (err.name === 'AbortError') return;
    els.status.textContent = '';
    els.results.innerHTML = `<p class="error">${esc(err.message)}</p>`;
  }
}

function schedule(query) {
  clearTimeout(timer);
  timer = setTimeout(() => run(query), DEBOUNCE_MS);
}

let ready = false;
let pendingTerm = null;

/**
 * Runs a search and scrolls the exact match into view.
 *
 * Used both by the related-term chips and by cross-tab navigation, so a term
 * opened from a Subject Guide lands on the same highlighted entry the student
 * would have reached by searching for it here.
 */
export async function searchTerm(term, { focusInput = false } = {}) {
  els.input.value = term;
  clearTimeout(timer);
  await run(term);

  const target = els.results.querySelector('.term');
  if (target) {
    for (const node of els.results.querySelectorAll('.term')) {
      node.classList.remove('is-highlighted');
    }
    target.classList.add('is-highlighted');
    target.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
  if (focusInput) els.input.focus();
}

export function initGlossary() {
  if (ready) {
    // A term requested before this tab was initialised is honoured now.
    if (pendingTerm) {
      const term = pendingTerm;
      pendingTerm = null;
      searchTerm(term, { focusInput: true });
    }
    return;
  }
  ready = true;

  els.form.addEventListener('submit', (e) => {
    e.preventDefault();
    clearTimeout(timer);
    run(els.input.value);
  });

  els.input.addEventListener('input', (e) => schedule(e.target.value));

  els.results.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-term]');
    if (!btn) return;
    searchTerm(btn.dataset.term);
  });

  // Show a starting set so the panel is never blank on first open.
  run('command');
}
