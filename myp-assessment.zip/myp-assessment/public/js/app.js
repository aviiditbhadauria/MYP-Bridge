/**
 * Entry point: tab navigation and module bootstrap.
 *
 * Each panel is loaded once on activation rather than all at once, so the
 * initial page load stays light.
 */
import { loadStreak } from './streak.js';
import { initEquivalency } from './equivalency.js';
import { initPractice } from './practice.js';
import { initGlossary, searchTerm } from './glossary.js';
import { initGuides } from './guides.js';
import { initTermCard, setGlossaryNavigator } from './termcard.js';

const tabs = [...document.querySelectorAll('.tab')];
const panels = new Map(
  tabs.map((tab) => [tab.dataset.panel, document.getElementById(`panel-${tab.dataset.panel}`)]),
);

const started = new Set(['equivalency']);

function activate(name) {
  for (const tab of tabs) {
    const on = tab.dataset.panel === name;
    tab.setAttribute('aria-selected', String(on));
  }
  for (const [key, panel] of panels) {
    if (!panel) continue;
    const on = key === name;
    panel.hidden = !on;
    panel.classList.toggle('is-active', on);
  }

  if (!started.has(name)) {
    started.add(name);
    if (name === 'practice') initPractice();
    if (name === 'glossary') initGlossary();
    if (name === 'guides') initGuides();
  }
  if (window.location.hash.slice(1) !== name) {
    history.replaceState(null, '', `#${name}`);
  }
}

for (const tab of tabs) {
  tab.addEventListener('click', () => activate(tab.dataset.panel));
}

window.addEventListener('hashchange', () => {
  const name = window.location.hash.slice(1);
  if (panels.has(name)) activate(name);
});

/**
 * Hands a term over to the glossary tab and runs the search there.
 *
 * Called by the shared term dialog so a student can move from an inline
 * definition to the full entry, and its related-term chips, in one step.
 */
function showInGlossary(term) {
  activate('glossary');
  searchTerm(term, { focusInput: true });
}

async function bootstrap() {
  const requested = window.location.hash.slice(1);
  activate(panels.has(requested) ? requested : 'equivalency');

  initTermCard();
  setGlossaryNavigator(showInGlossary);

  // The streak panel is global, so it is requested up front alongside the
  // equivalency data.
  await Promise.all([loadStreak(), initEquivalency()]);
}

bootstrap().catch((err) => {
  console.error(err);
});
