/**
 * Thin fetch wrapper for the v1 API.
 *
 * Every response follows the `{ status, data, meta }` envelope, so a single
 * unwrap point keeps error handling out of the feature modules.
 */

const BASE = '/api/v1';

export class ApiError extends Error {
  constructor(message, status, payload) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.payload = payload;
  }
}

async function request(path, { method = 'GET', body, signal } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    signal,
    credentials: 'same-origin',
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });

  let payload = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }

  if (!res.ok || payload?.status === 'error') {
    throw new ApiError(
      payload?.message ?? `Request to ${path} failed with status ${res.status}.`,
      res.status,
      payload,
    );
  }
  return payload;
}

function toQuery(params = {}) {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '') continue;
    search.set(key, String(value));
  }
  const s = search.toString();
  return s ? `?${s}` : '';
}

/** Minutes east of UTC for the current device, used by the streak ledger. */
export function timezoneOffset() {
  return -new Date().getTimezoneOffset();
}

export const api = {
  health: () => request('/health'),
  session: () => request('/session'),
  subjects: () => request('/subjects'),

  boundaries: (subject) => request(`/boundaries/${encodeURIComponent(subject)}`),
  boundaryRow: (subject, grade) =>
    request(`/boundaries/${encodeURIComponent(subject)}?grade=${grade}`),
  slider: (subject, grade) =>
    request(`/boundaries/slider/${encodeURIComponent(subject)}?grade=${grade}`),

  questions: (filters, signal) => request(`/questions${toQuery(filters)}`, { signal }),
  questionStats: () => request('/questions/stats'),
  submitAttempt: (payload) => request('/questions/attempt', { method: 'POST', body: payload }),

  searchTerms: (q, signal) => request(`/terms/search${toQuery({ q })}`, { signal }),
  terms: (filters) => request(`/terms${toQuery(filters)}`),
  termCategories: () => request('/terms/categories'),

  guides: () => request('/guides'),
  guide: (id) => request(`/guides/${encodeURIComponent(id)}`),
  dialogues: () => request('/guides/dialogue'),
  dialogue: (id) => request(`/guides/dialogue/${encodeURIComponent(id)}`),
  term: (q, signal) => request(`/terms${toQuery({ q })}`, { signal }),

  streak: () => request(`/streak${toQuery({ timezone_offset: timezoneOffset() })}`),
  verifyStreak: () =>
    request('/streak/verify', {
      method: 'POST',
      body: { timezone_offset: timezoneOffset() },
    }),
};

/** Escapes text before it is inserted into innerHTML. */
export function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
